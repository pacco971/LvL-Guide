local NS = ForeverPath

function NS:GetEquipmentSummary()
  local average = 0
  if GetAverageItemLevel then
    local ok, equipped = pcall(GetAverageItemLevel)
    if ok and type(equipped) == "number" then average = equipped end
  end
  local level = self.GetPlayerLevel and self:GetPlayerLevel() or 1
  local signal = average > 0 and math.floor(average - level * 2.2) or 0
  local state = signal >= 3 and "stark" or signal <= -3 and "schwach" or "passend"
  return { average=average, signal=signal, state=state }
end

function NS:GetRewardAdvice()
  if not GetNumQuestLogRewards or not GetQuestLogRewardInfo then return nil end
  local ok, count = pcall(GetNumQuestLogRewards)
  if not ok or not count or count <= 0 then return nil end
  local best
  for index = 1, count do
    local success, name, texture, quantity, quality, usable, itemID = pcall(GetQuestLogRewardInfo, index)
    if success and name then
      local value = (usable and 20 or 0) + (quality or 0) * 4 + (quantity or 1)
      if not best or value > best.value then best = { index=index, name=name, itemID=itemID, quality=quality or 0, value=value } end
    end
  end
  if not best then return nil end
  return string.format("Belohnung prüfen: %s%s", best.name, best.quality and best.quality > 1 and " · höhere Qualität" or "")
end

function NS:GetGearAdvice()
  local gear = self:GetEquipmentSummary()
  if gear.average <= 0 then return "Ausrüstungswert wird vom Client noch geladen." end
  if gear.state == "schwach" then return string.format("Ausrüstung schwach (Ø %.0f): Belohnungs-Upgrades und Waffen priorisieren.", gear.average) end
  if gear.state == "stark" then return string.format("Ausrüstung stark (Ø %.0f): Quest-XP und kurze Wege höher gewichten.", gear.average) end
  return string.format("Ausrüstung passend (Ø %.0f).", gear.average)
end
