local NS = ForeverPath

local STAT_WEIGHTS = {
  WARRIOR={strength=1.00, stamina=0.55, agility=0.35}, PALADIN={strength=0.90, stamina=0.55, intellect=0.35},
  HUNTER={agility=1.00, stamina=0.45, intellect=0.20}, ROGUE={agility=1.00, stamina=0.40, strength=0.25},
  DRUID={agility=0.85, stamina=0.45, strength=0.30, intellect=0.25}, SHAMAN={strength=0.75, agility=0.45, intellect=0.45, stamina=0.35},
  MAGE={intellect=1.00, stamina=0.35, spirit=0.25}, PRIEST={intellect=1.00, spirit=0.35, stamina=0.30}, WARLOCK={intellect=1.00, stamina=0.35, spirit=0.20},
}

local ROLE_WEIGHTS = {
  DPS={strength=1.00, agility=1.00, intellect=1.00, spirit=0.25, stamina=0.45},
  TANK={strength=0.90, agility=0.75, intellect=0.30, spirit=0.20, stamina=1.00},
  HEALER={strength=0.30, agility=0.30, intellect=1.00, spirit=0.85, stamina=0.55},
}

function NS:GetGearRole()
  local selected = self.db and self.db.ui and self.db.ui.gearRole or "AUTO"
  if selected ~= "AUTO" then return selected end
  local assigned = UnitGroupRolesAssigned and UnitGroupRolesAssigned("player") or "NONE"
  if assigned == "TANK" then return "TANK" end
  if assigned == "HEALER" then return "HEALER" end
  return "DPS"
end

function NS:SetGearRole(role)
  if role ~= "AUTO" and not ROLE_WEIGHTS[role] then return end
  self:EnsureSettings(); self.db.ui.gearRole = role; self:Refresh(); self:Print("Gear-Profil: " .. (role == "AUTO" and "Auto" or role))
end

local function itemStats(itemLink)
  local getter = C_Item and C_Item.GetItemStats or GetItemStats
  if not getter or not itemLink then return {} end
  local ok, stats = pcall(getter, itemLink)
  return ok and type(stats) == "table" and stats or {}
end

local function statValue(stats, key)
  for statName, value in pairs(stats or {}) do
    local name = string.lower(statName)
    if string.find(name, key, 1, true) then return (value or 0) end
  end
  return 0
end

function NS:ScoreItemLink(itemLink)
  if not itemLink or not GetItemInfo then return 0, nil end
  local name, link, quality, itemLevel, _, _, _, _, equipLoc = GetItemInfo(itemLink)
  if not name then return 0, nil end
  local classToken = "UNKNOWN"
  if UnitClass then local _, token = UnitClass("player"); classToken = token or "UNKNOWN" end
  local base = STAT_WEIGHTS[classToken] or STAT_WEIGHTS.WARRIOR
  local role = self:GetGearRole(); local roleWeights = ROLE_WEIGHTS[role] or ROLE_WEIGHTS.DPS; local weights = {}
  for stat, value in pairs(base) do weights[stat] = value end
  for stat, value in pairs(roleWeights) do weights[stat] = math.max(weights[stat] or 0, value * 0.55) end
  local stats = itemStats(itemLink)
  local score = (itemLevel or 0) * 0.75 + statValue(stats, "strength") * (weights.strength or 0) + statValue(stats, "agility") * (weights.agility or 0) + statValue(stats, "intellect") * (weights.intellect or 0) + statValue(stats, "spirit") * (weights.spirit or 0) + statValue(stats, "stamina") * (weights.stamina or 0)
  return score, { name=name, link=link or itemLink, quality=quality or 0, itemLevel=itemLevel or 0, equipLoc=equipLoc, stats=stats }
end

local function inventorySlotsFor(equipLoc)
  local slots = {
    INVTYPE_HEAD={1}, INVTYPE_NECK={2}, INVTYPE_SHOULDER={3}, INVTYPE_BODY={4}, INVTYPE_CHEST={5}, INVTYPE_ROBE={5},
    INVTYPE_WAIST={6}, INVTYPE_LEGS={7}, INVTYPE_FEET={8}, INVTYPE_WRIST={9}, INVTYPE_HAND={10}, INVTYPE_FINGER={11,12},
    INVTYPE_TRINKET={13,14}, INVTYPE_CLOAK={15}, INVTYPE_WEAPON={16,17}, INVTYPE_2HWEAPON={16}, INVTYPE_WEAPONMAINHAND={16},
    INVTYPE_WEAPONOFFHAND={17}, INVTYPE_SHIELD={17}, INVTYPE_HOLDABLE={17}, INVTYPE_RANGED={18,19}, INVTYPE_THROWN={18,19}, INVTYPE_RELIC={18,19},
  }
  return slots[equipLoc] or {}
end

function NS:GetEquipmentSummary()
  local average = 0
  if GetAverageItemLevel then
    local ok, equipped = pcall(GetAverageItemLevel)
    if ok and type(equipped) == "number" then average = equipped end
  end
  local level = self.GetPlayerLevel and self:GetPlayerLevel() or 1
  local signal = average > 0 and math.floor(average - level * 2.2) or 0
  local state = signal >= 3 and "stark" or signal <= -3 and "schwach" or "passend"
  local weakSlots = 0
  if GetInventoryItemLink then
    for slot = 1, 19 do if not GetInventoryItemLink("player", slot) then weakSlots = weakSlots + 1 end end
  end
  return { average=average, signal=signal, state=state, weakSlots=weakSlots }
end

function NS:GetRewardAdvice()
  if not GetNumQuestLogRewards or not GetQuestLogRewardInfo then return nil end
  local ok, count = pcall(GetNumQuestLogRewards)
  if not ok or not count or count <= 0 then return nil end
  local best
  for index = 1, count do
    local success, name, texture, quantity, quality, usable, itemID = pcall(GetQuestLogRewardInfo, index)
    if success and name then
      local link = GetQuestLogRewardLink and GetQuestLogRewardLink(index)
      local score, item = self:ScoreItemLink(link)
      local value = score + (usable and 20 or 0) + (quality or 0) * 4 + (quantity or 1)
      if not best or value > best.value then best = { index=index, name=name, itemID=itemID, quality=quality or 0, value=value, score=score, item=item } end
    end
  end
  if not best then return nil end
  local currentScore = 0
  if best.item and best.item.equipLoc and GetInventoryItemLink then
    for _, slot in ipairs(inventorySlotsFor(best.item.equipLoc)) do
      local equipped = GetInventoryItemLink("player", slot)
      local score = equipped and self:ScoreItemLink(equipped) or 0
      if score > currentScore then currentScore = score end
    end
  end
  local difference = best.score and best.score > 0 and best.score - currentScore or 0
  local upgrade = best.score and best.score > 0 and (difference > 0 and string.format(" · +%.0f Gear-Score", difference) or " · kein direktes Upgrade") or ""
  return string.format("Belohnung prüfen: %s%s%s · Profil %s", best.name, best.quality and best.quality > 1 and " · höhere Qualität" or "", upgrade, self:GetGearRole())
end

function NS:GetGearAdvice()
  local gear = self:GetEquipmentSummary()
  if gear.average <= 0 then return "Ausrüstungswert wird vom Client noch geladen." end
  if gear.state == "schwach" then return string.format("Ausrüstung schwach (Ø %.0f): %s-Gear, Belohnungs-Upgrades und Waffen priorisieren.", gear.average, self:GetGearRole()) end
  if gear.state == "stark" then return string.format("Ausrüstung stark (Ø %.0f): Quest-XP und kurze Wege höher gewichten.", gear.average) end
  return string.format("Ausrüstung passend (Ø %.0f).", gear.average)
end
