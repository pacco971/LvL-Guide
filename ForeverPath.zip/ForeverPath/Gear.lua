local NS=ForeverPath
local slots={{1,"Kopf"},{2,"Hals"},{3,"Schultern"},{5,"Brust"},{6,"Taille"},{7,"Beine"},{8,"Füße"},{9,"Handgelenke"},{10,"Hände"},{11,"Ring 1"},{12,"Ring 2"},{13,"Schmuck 1"},{14,"Schmuck 2"},{15,"Rücken"},{16,"Haupthand"},{17,"Nebenhand"},{18,"Distanz"}}
local locations={INVTYPE_HEAD={1},INVTYPE_NECK={2},INVTYPE_SHOULDER={3},INVTYPE_CHEST={5},INVTYPE_ROBE={5},INVTYPE_WAIST={6},INVTYPE_LEGS={7},INVTYPE_FEET={8},INVTYPE_WRIST={9},INVTYPE_HAND={10},INVTYPE_FINGER={11,12},INVTYPE_TRINKET={13,14},INVTYPE_CLOAK={15},INVTYPE_WEAPON={16},INVTYPE_WEAPONMAINHAND={16},INVTYPE_2HWEAPON={16,17},INVTYPE_WEAPONOFFHAND={17},INVTYPE_SHIELD={17},INVTYPE_HOLDABLE={17},INVTYPE_RANGED={18},INVTYPE_RANGEDRIGHT={18},INVTYPE_THROWN={18},INVTYPE_RELIC={18}}
function NS:GetGearRole()
  local role=self.db.ui.gearRole or "AUTO"
  if role=="AUTO" then local r=UnitGroupRolesAssigned and UnitGroupRolesAssigned("player"); return r=="TANK" and "TANK" or r=="HEALER" and "HEALER" or (IsInGroup and IsInGroup() and "DPS" or "SOLO") end
  return role
end
function NS:SetGearRole(role) self.db.ui.gearRole=role; self:InvalidateGearCache(); self:Refresh() end
function NS:InvalidateGearCache() self.gearCache={}; self.rewardCache=nil end
function NS:ScoreItemLink(link)
  if not link then return nil end
  self.gearCache=self.gearCache or {}; if self.gearCache[link] then return unpack(self.gearCache[link]) end
  local getter=C_Item and C_Item.GetItemInfo or GetItemInfo
  if not getter then return nil end
  local ok,name,_,quality,ilvl,required,_,_,_,loc,icon,_,class,subclass=pcall(getter,link)
  if not ok then return nil end
  if not name then
    if C_Item and C_Item.RequestLoadItemDataByID then local id=tonumber(tostring(link):match("item:(%d+)")) or tonumber(link); if id then C_Item.RequestLoadItemDataByID(id) end end
    return nil
  end
  -- Item stats are not exposed consistently by the Forever client.  Keep the
  -- item usable with an item-level fallback instead of making the whole Gear
  -- tab look empty while the optional stat API is unavailable.
  local statsFn=C_Item and C_Item.GetItemStats or GetItemStats
  local ok,stats=statsFn and pcall(statsFn,link)
  if not ok or type(stats)~="table" then stats={} end
  local role=self:GetGearRole(); local token=self:GetClassToken()
  local caster=token=="MAGE" or token=="PRIEST" or token=="WARLOCK" or role=="HEALER"
  local agile=token=="HUNTER" or token=="ROGUE" or token=="DRUID"
  local weights={ITEM_MOD_STAMINA_SHORT=role=="TANK" and 1.4 or role=="SOLO" and 0.55 or 0.3,RESISTANCE0_NAME=role=="TANK" and 0.025 or 0.003}
  weights[caster and "ITEM_MOD_INTELLECT_SHORT" or agile and "ITEM_MOD_AGILITY_SHORT" or "ITEM_MOD_STRENGTH_SHORT"]=1
  weights.ITEM_MOD_SPIRIT_SHORT=role=="HEALER" and 0.8 or caster and 0.25 or 0
  weights.ITEM_MOD_DAMAGE_PER_SECOND_SHORT=caster and 0.1 or 3
  weights.ITEM_MOD_ATTACK_POWER_SHORT=not caster and 0.4 or 0
  weights.ITEM_MOD_SPELL_POWER_SHORT=caster and 1.3 or 0
  weights.ITEM_MOD_CRIT_RATING_SHORT=role=="DPS" and 0.35 or 0.18
  weights.ITEM_MOD_HASTE_RATING_SHORT=role=="DPS" and 0.30 or 0.12
  weights.ITEM_MOD_HIT_RATING_SHORT=role=="DPS" and 0.28 or 0.10
  local score=0; local hasStats=false
  for stat,w in pairs(weights) do
    local value=tonumber(stats[stat]) or 0
    if value~=0 then hasStats=true end
    score=score+value*w
  end
  if not hasStats then score=tonumber(ilvl) or 0 end
  local item={name=name,link=link,quality=quality,itemLevel=ilvl,equipLoc=loc,icon=icon,requiredLevel=required,stats=stats,classID=class,subclassID=subclass}
  self.gearCache[link]={score,item}; return score,item
end
function NS:GetEquipmentRows()
  local rows={}
  for _,s in ipairs(slots) do
    local link=GetInventoryItemLink and GetInventoryItemLink("player",s[1])
    local score,item=self:ScoreItemLink(link)
    rows[#rows+1]={slot=s[1],label=s[2],link=link,score=score,item=item,status=not link and (s[1]==17 and "leer / ggf. Zweihand" or "leer") or not item and "lädt" or "geladen"}
  end
  return rows
end
function NS:GetEquipmentSummary()
  local sum,count,missing,pending=0,0,0,0
  for _,r in ipairs(self:GetEquipmentRows()) do if r.item then sum=sum+(r.item.itemLevel or 0); count=count+1 elseif r.link then pending=pending+1 else missing=missing+1 end end
  return {average=count>0 and sum/count or 0,state=pending>0 and "lädt" or "erfasst",weakSlots=missing,pending=pending}
end
local function canEquip(item)
  local c=NS:GetClassToken()
  if not locations[item.equipLoc] then return false end
  if (item.requiredLevel or 0)>NS:GetPlayerLevel() then return false end
  -- Conservative armor restrictions; weapon skills may require trainer verification.
  local armor={MAGE=1,PRIEST=1,WARLOCK=1,ROGUE=2,DRUID=2,HUNTER=NS:GetPlayerLevel()>=40 and 3 or 2,SHAMAN=NS:GetPlayerLevel()>=40 and 3 or 2,PALADIN=NS:GetPlayerLevel()>=40 and 4 or 3,WARRIOR=NS:GetPlayerLevel()>=40 and 4 or 3}
  if item.classID==4 and item.subclassID and item.subclassID<=4 and item.subclassID>(armor[c] or 1) then return false end
  return true
end
function NS:GetReplacementScore(item)
  if not item then return nil,true end
  local candidate=locations[item.equipLoc] or {}; local total=0; local pending=false; local found=false
  local function read(slot)
    local link=GetInventoryItemLink and GetInventoryItemLink("player",slot)
    if not link then return 0 end
    local score,old=self:ScoreItemLink(link); if link and not old then pending=true end
    return score or 0
  end
  if item.equipLoc=="INVTYPE_2HWEAPON" then
    total=read(16)+read(17); found=true
  elseif item.equipLoc=="INVTYPE_WEAPONOFFHAND" or item.equipLoc=="INVTYPE_SHIELD" or item.equipLoc=="INVTYPE_HOLDABLE" then
    total=read(17); found=true
  elseif item.equipLoc=="INVTYPE_FINGER" or item.equipLoc=="INVTYPE_TRINKET" then
    local a,b=read(candidate[1]),read(candidate[2]); total=math.min(a,b); found=true
  elseif candidate[1] then
    total=read(candidate[1]); found=true
  end
  return found and total or 0,pending
end
function NS:GetRewardApiStatus()
  local choiceCount = type(GetNumQuestChoices) == "function" or type(GetNumQuestLogChoices) == "function"
  local choiceInfo = type(GetQuestItemInfo) == "function" or type(GetQuestLogChoiceInfo) == "function"
  local choiceLink = type(GetQuestItemLink) == "function" or type(GetQuestLogItemLink) == "function"
  if choiceCount and choiceInfo and choiceLink then return "Item-Belohnungs-API verfügbar" end
  if C_QuestInfoSystem and type(C_QuestInfoSystem.GetQuestRewardCurrencies) == "function" then
    return "Währungs-API verfügbar; Item-Belohnungen brauchen Client-Test"
  end
  return "Item-Belohnungs-API im Forever-Client noch nicht bestätigt"
end
function NS:GetRewardComparison()
  local activeStep=self.GetCurrentStep and self:GetCurrentStep(); local cacheKey=tostring(self.rewardWindow and 1 or 0)..":"..tostring(activeStep and activeStep.id or "none")
  if self.rewardCache and self.rewardCache.key==cacheKey then return self.rewardCache.value end
  local rows,pending={},false
  local countFn=self.rewardWindow and GetNumQuestChoices or GetNumQuestLogChoices
  local infoFn=self.rewardWindow and GetQuestItemInfo or GetQuestLogChoiceInfo
  local linkFn=self.rewardWindow and GetQuestItemLink or GetQuestLogItemLink
  if not countFn or not infoFn or not linkFn then
    local value={rows={},advice="Belohnungsdaten in diesem Client nicht verfügbar. "..self:GetRewardApiStatus()}
    self.rewardCache={key=cacheKey,value=value}; return value
  end
  local okCount,count=pcall(countFn); if not okCount or not count then count=0 end
  for i=1,count do
    local name,texture,quantity,quality,usable
    local okInfo
    if self.rewardWindow then okInfo,name,texture,quantity,quality,usable=pcall(infoFn,"choice",i) else okInfo,name,texture,quantity,quality,usable=pcall(infoFn,i) end
    if not okInfo or not name then
      if self.rewardWindow then okInfo,name,texture,quantity,quality,usable=pcall(infoFn,"reward",i) else okInfo,name,texture,quantity,quality,usable=pcall(infoFn,i) end
    end
    local okLink,link
    if self.rewardWindow then okLink,link=pcall(linkFn,"choice",i) else okLink,link=pcall(linkFn,i) end
    if not okLink then link=nil end
    local score,item=self:ScoreItemLink(link)
    local row={name=name or "Item lädt",link=link,item=item,score=score}
    if not item then pending=true; row.status="lädt"
    elseif usable==false or not canEquip(item) then row.status="nicht geeignet"
    else
      local current,waiting=self:GetReplacementScore(item); if waiting then pending=true end
      row.currentScore=current or 0
      row.delta=score-(current or 0)
      row.percent=current and current>0 and row.delta/current*100 or nil
      row.status=item.classID==2 and "Waffenfertigkeit prüfen" or "vergleichbar"
    end
    rows[#rows+1]=row
  end
  local best
  if not pending then for _,r in ipairs(rows) do if r.delta and r.delta>0 and (not best or r.delta>best.delta) then best=r end end end
  local value={rows=rows,pending=pending,role=self:GetGearRole(),advice=pending and "Vergleich wartet auf vollständige Itemdaten." or best and string.format("Empfehlung prüfen: %s (+%.1f Gear-Score, %+.1f%%, %s)",best.name,best.delta,best.percent or 0,self:GetGearRole()) or "Kein belegtes Upgrade aus den verfügbaren Auswahlbelohnungen."}
  self.rewardCache={key=cacheKey,value=value}; return value
end
function NS:GetRewardAdvice() return self:GetRewardComparison().advice end
function NS:GetGearAdvice() local g=self:GetEquipmentSummary(); return string.format("Gear-Profil %s · %d leere Plätze · %d Items laden. Score ist eine Stat-Heuristik.",self:GetGearRole(),g.weakSlots,g.pending) end
