local NS=ForeverPath
function NS:ObserveStop(kind)
  self.db.stops=self.db.stops or {}
  local name=UnitName and UnitName("npc"); if not name then return end
  local map=C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player"); local x,y
  if map and self.GetSafeMapPosition then x,y=self:GetSafeMapPosition(map,"player") end
  local record={name=name,kind=kind,mapID=map,x=x and x*100,y=y and y*100,at=time(),class=self:GetClassToken()}
  if kind=="trainer" and GetNumTrainerServices and GetTrainerServiceInfo then
    record.available=0; record.skills={}
    for i=1,GetNumTrainerServices() do local skill,_,status=GetTrainerServiceInfo(i); if status=="available" then record.available=record.available+1; record.skills[#record.skills+1]=skill end end
  end
  self.db.stops[name..":"..kind]=record
end
function NS:GetKnownProfessions()
  local out={}
  if GetProfessions and GetProfessionInfo then for _,i in pairs({GetProfessions()}) do local name=GetProfessionInfo(i); if name then out[#out+1]=name end end
  elseif GetNumSkillLines and GetSkillLineInfo then for i=1,GetNumSkillLines() do local name,header=GetSkillLineInfo(i); if not header then out[#out+1]=name end end end
  return out
end
function NS:GetNextPlannedStop()
  local map=C_Map and C_Map.GetBestMapForUnit("player"); local low=false
  if GetInventoryItemDurability then for i=1,18 do local current,max=GetInventoryItemDurability(i); if max and max>0 and current/max<0.3 then low=true end end end
  local best
  for _,s in pairs(self.db.stops or {}) do
    local useful=s.kind=="trainer" and (s.available or 0)>0 or s.kind=="merchant" and low
    if useful and s.mapID==map and (not best or s.at>best.at) then best=s end
  end
  return best
end
function NS:GetStopAdvice()
  local s=self:GetNextPlannedStop()
  return s and ("Stopp: "..s.name.." · "..s.kind.." (bei Besuch beobachtet; Position in NPC-Nähe)") or "Kein belegter Pflichtstopp. Trainer-/Berufsdaten werden beim Besuch erfasst."
end
function NS:GetStopDetails()
  local lines={self:GetStopAdvice(),"Berufe / Fertigkeiten: "..table.concat(self:GetKnownProfessions(),", ")}
  for _,s in pairs(self.db.stops or {}) do lines[#lines+1]=string.format("%s · %s · %s · Angebote %s",s.name,s.kind,s.mapID and tostring(s.mapID) or "Karte unbekannt",s.available or "unbekannt") end
  lines[#lines+1]="Hauptstadtumwege werden ohne belegten Nutzen nicht automatisch eingeplant."
  return table.concat(lines,"\n")
end
function NS:GetTrainerSummary()
  local lines={}
  for _, stop in pairs(self.db.stops or {}) do
    if stop.kind=="trainer" then
      local skills=stop.skills and #stop.skills>0 and table.concat(stop.skills,", ") or (self.L and self:L("keine verfügbaren Fähigkeiten erfasst") or "keine verfügbaren Fähigkeiten erfasst")
      lines[#lines+1]=string.format("%s · %s",stop.name or "Trainer",skills)
    end
  end
  if #lines==0 then return self.L and self:L("Noch kein Trainerfenster besucht. Beim Öffnen werden verfügbare Fähigkeiten automatisch erfasst.") or "Noch kein Trainerfenster besucht. Beim Öffnen werden verfügbare Fähigkeiten automatisch erfasst." end
  return table.concat(lines,"\n")
end
