local NS = ForeverPath

local function professionNames()
  local result = {}
  if not GetProfessions or not GetProfessionInfo then return result end
  local p1, p2, p3, p4, p5, p6 = GetProfessions()
  for _, index in pairs({p1, p2, p3, p4, p5, p6}) do
    if index then
      local ok, name = pcall(GetProfessionInfo, index)
      if ok and name then result[#result + 1] = name end
    end
  end
  return result
end

function NS:GetKnownProfessions()
  self.professionCache = self.professionCache or professionNames()
  return self.professionCache
end

function NS:GetNextPlannedStop()
  local level = self.GetPlayerLevel and self:GetPlayerLevel() or 1
  local gear = self.GetEquipmentSummary and self:GetEquipmentSummary() or { state="unbekannt" }
  local professions = self:GetKnownProfessions()
  local profile = self.GetClassProfile and self:GetClassProfile() or { name="Klasse", role="flexibel" }
  local nextTrainer = math.min(60, (math.floor(level / 2) + 1) * 2)
  if level >= 60 then nextTrainer = 60 end
  if gear.state == "schwach" then
    return { kind="capital", title="Hauptstadt-/Ausrüstungsstopp", reason="Ausrüstung prüfen, reparieren und Waffen-/Rüstungsupgrade suchen." }
  end
  if #professions == 0 and level >= 5 then
    return { kind="profession", title="Berufs- und Erste-Hilfe-Stopp", reason="Berufstrainer, Erste Hilfe, Gasthof und Flugpunkt bündeln." }
  end
  if level >= nextTrainer - 1 then
    return { kind="trainer", title="Klassenlehrer für " .. profile.name, reason="Neue Fähigkeiten trainieren und Klassenquest prüfen." }
  end
  if self.GetQuestState then
    local quests = self:GetQuestState()
    if quests and quests.active and quests.active >= 20 then return { kind="capital", title="Abgabe- und Leerräumstopp", reason="Questlog ist fast voll; Abgaben, Verkauf und Reparatur bündeln." } end
  end
  return { kind="route", title="Nächster Questhub", reason="Aktuelle Questkette weiterführen und die nächste Zone nicht vorzeitig anfahren." }
end

function NS:GetStopAdvice()
  local stop = self:GetNextPlannedStop()
  if not stop then return "" end
  return string.format("Planstopp: %s · %s", stop.title, stop.reason)
end
