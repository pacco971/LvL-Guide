local NS = ForeverPath

-- Own quest-objective markers.  This deliberately does not depend on Questie:
-- it consumes the live quest log, ForeverDB/QuestieDB records and the local
-- open route data already shipped with ForeverPath.
local ICONS = {
  objective = "Interface\\Icons\\INV_Misc_Map_01",
  item = "Interface\\Icons\\INV_Misc_QuestionMark",
  turnin = "Interface\\Icons\\INV_Misc_Note_02",
}

local COLORS = {
  objective = {0.25, 0.70, 1.00, 1},
  item = {0.98, 0.72, 0.18, 1},
  turnin = {0.35, 1.00, 0.62, 1},
}

local function tr(text)
  return NS.L and NS:L(text) or text
end

local function safeString(value)
  if value == nil then return "" end
  return tostring(value)
end

local function titleKey(value)
  value = string.lower(safeString(value))
  value = value:gsub("[%p%c]", " "):gsub("%s+", " ")
  return value:gsub("^%s*(.-)%s*$", "%1")
end

local function validPoint(point)
  return type(point) == "table"
    and tonumber(point.mapID) ~= nil
    and tonumber(point.x) ~= nil
    and tonumber(point.y) ~= nil
    and tonumber(point.x) >= 0 and tonumber(point.x) <= 100
    and tonumber(point.y) >= 0 and tonumber(point.y) <= 100
end

local function objectiveLooksLikeItem(name)
  name = string.lower(safeString(name))
  -- These words cover the localized and English route descriptions without
  -- pretending that the client exposes a reliable item-vs-NPC flag.
  return name:find("item", 1, true) ~= nil
    or name:find("loot", 1, true) ~= nil
    or name:find("collect", 1, true) ~= nil
    or name:find("sammel", 1, true) ~= nil
    or name:find("beute", 1, true) ~= nil
    or name:find("drop", 1, true) ~= nil
    or name:find("lootbar", 1, true) ~= nil
end

local function trimLabel(value, limit)
  value = safeString(value):gsub("\n", " "):gsub("%s+", " ")
  limit = limit or 22
  if #value > limit then return value:sub(1, limit - 3) .. "..." end
  return value
end

local function mapDistance(px, py, x, y)
  local dx, dy = x / 100 - px, y / 100 - py
  return math.sqrt(dx * dx + dy * dy), dx, dy
end

local function getPlayerMapID()
  if C_Map and C_Map.GetBestMapForUnit then
    local ok, mapID = pcall(C_Map.GetBestMapForUnit, "player")
    if ok and type(mapID) == "number" and mapID > 0 then return mapID end
  end
  if GetCurrentMapAreaID then
    local ok, mapID = pcall(GetCurrentMapAreaID)
    if ok and type(mapID) == "number" and mapID > 0 then return mapID end
  end
  if GetCurrentMap then
    local ok, mapID = pcall(GetCurrentMap)
    if ok and type(mapID) == "number" and mapID > 0 then return mapID end
  end
  return nil
end

local function hideMarker(marker)
  if marker then marker:Hide() end
end

function NS:GetQuestMarkerRoute(quest)
  if not quest then return nil end
  self.questMarkerRouteCache = self.questMarkerRouteCache or {}
  local cacheKey = tonumber(quest.id) or ("title:" .. titleKey(quest.record and quest.record.title or quest.title))
  if self.questMarkerRouteCache[cacheKey] ~= nil then
    return self.questMarkerRouteCache[cacheKey] or nil
  end
  local byQuest = self.externalRoutesByQuest or {}
  local byTitle = self.externalRoutesByTitle or {}
  local id = tonumber(quest.id)
  if id and byQuest[id] and byQuest[id][1] then
    self.questMarkerRouteCache[cacheKey] = byQuest[id][1]
    return byQuest[id][1]
  end

  local candidates = {
    quest.title,
    quest.record and quest.record.title,
  }
  for _, title in ipairs(candidates) do
    local rows = title and byTitle[title]
    if rows and rows[1] then self.questMarkerRouteCache[cacheKey] = rows[1]; return rows[1] end
    local key = titleKey(title)
    if key ~= "" then
      for routeTitle, routeRows in pairs(byTitle) do
        local routeKey = titleKey(routeTitle)
        if routeKey == key or (#key > 8 and (routeKey:find(key, 1, true) or key:find(routeKey, 1, true))) then
          if routeRows[1] then self.questMarkerRouteCache[cacheKey] = routeRows[1]; return routeRows[1] end
        end
      end
    end
  end
  self.questMarkerRouteCache[cacheKey] = false
  return nil
end

function NS:GetQuestMarkerEntries()
  local entries = {}
  if not self.GetLiveQuestList then return entries end
  local quests = self:GetLiveQuestList() or {}
  for _, quest in ipairs(quests) do
    local route = self:GetQuestMarkerRoute(quest)
    local point, kind, name
    local rows = self.GetQuestObjectiveRows and self:GetQuestObjectiveRows(quest) or {}
    local allDone = quest.isComplete == true
    if #rows > 0 then
      allDone = true
      for _, row in ipairs(rows) do
        if not row.finished then allDone = false; break end
      end
    end

    -- The live POI is the most precise source when this Forever build exposes
    -- it.  Otherwise use the imported objective route point.
    if not allDone and quest.logWaypoint and validPoint(quest.logWaypoint) then
      point = quest.logWaypoint
      kind = objectiveLooksLikeItem(quest.title) and "item" or "objective"
      name = quest.logWaypoint.name or quest.title
    elseif not allDone and route and validPoint(route.objective) then
      point, kind, name = route.objective, objectiveLooksLikeItem(route.objective.name) and "item" or "objective", route.objective.name
    elseif allDone and route and validPoint(route.turnin) then
      point, kind, name = route.turnin, "turnin", route.turnin.name
    elseif allDone and quest.record and validPoint(quest.record.turnInPoint) then
      point, kind, name = quest.record.turnInPoint, "turnin", quest.record.turnInPoint.name
    end

    if point and validPoint(point) then
      entries[#entries + 1] = {
        mapID=tonumber(point.mapID), x=tonumber(point.x), y=tonumber(point.y),
        kind=kind or "objective", name=name or quest.title, quest=quest,
        title=quest.title, complete=allDone,
      }
    end
  end
  return entries
end

function NS:CreateQuestMarkers()
  if self.questMarkerFrame then return end
  local frame = CreateFrame("Frame", "ForeverPathQuestMarkers", Minimap)
  frame:SetAllPoints(Minimap)
  frame:SetFrameLevel((Minimap:GetFrameLevel() or 0) + 5)
  frame.markers = {}
  frame.elapsed = 0
  frame:SetScript("OnUpdate", function(_, elapsed)
    frame.elapsed = frame.elapsed + (elapsed or 0)
    if frame.elapsed >= 0.20 then
      frame.elapsed = 0
      NS:RefreshQuestMarkers()
    end
  end)
  self.questMarkerFrame = frame
  self:RefreshQuestMarkers()
end

local function ensureMarker(frame, index)
  local marker = frame.markers[index]
  if marker then return marker end
  marker = CreateFrame("Button", nil, frame)
  marker:SetSize(18, 18)
  marker:SetFrameLevel(frame:GetFrameLevel() + 2)
  marker.icon = marker:CreateTexture(nil, "OVERLAY")
  marker.icon:SetAllPoints()
  marker.label = marker:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  marker.label:SetPoint("LEFT", marker, "RIGHT", 3, 0)
  marker.label:SetWidth(110); marker.label:SetHeight(14); marker.label:SetJustifyH("LEFT")
  marker:EnableMouse(true)
  marker:SetScript("OnEnter", function(button)
    if not GameTooltip or not button.entry then return end
    local entry = button.entry
    GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
    GameTooltip:AddLine(tr("Questmarker"), 0.98, 0.72, 0.18)
    GameTooltip:AddLine(entry.name or entry.title or tr("Questziel"), 1, 1, 1, true)
    if entry.title and entry.title ~= entry.name then GameTooltip:AddLine(entry.title, 0.72, 0.82, 0.96, true) end
    GameTooltip:AddLine(entry.complete and tr("Quest bereit zur Abgabe") or tr("Benötigtes Questziel"), 0.55, 0.78, 0.62, true)
    if entry.distance then GameTooltip:AddLine(string.format(tr("Entfernung: %.0f m Kartenstrecke"), entry.distance * 1000), 0.72, 0.82, 0.96) end
    GameTooltip:AddLine(tr("Quelle: ForeverPath-Daten + Questlog"), 0.55, 0.60, 0.70, true)
    GameTooltip:Show()
  end)
  marker:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
  frame.markers[index] = marker
  return marker
end

function NS:RefreshQuestMarkers()
  local frame = self.questMarkerFrame
  if not frame or not Minimap then return end
  self:EnsureSettings()
  local ui = self.db and self.db.ui or {}
  if ui.questMarkers == false then
    for _, marker in ipairs(frame.markers) do hideMarker(marker) end
    return
  end
  local mapID = getPlayerMapID()
  if not mapID then
    for _, marker in ipairs(frame.markers) do hideMarker(marker) end
    return
  end
  local px, py
  if self.GetSafeMapPosition then px, py = self:GetSafeMapPosition(mapID, "player") end
  if not px or not py then
    for _, marker in ipairs(frame.markers) do hideMarker(marker) end
    return
  end

  local radius = math.max(0.04, math.min(0.75, tonumber(ui.questMarkerRadius) or 0.22))
  local limit = math.max(1, math.min(12, math.floor(tonumber(ui.questMarkerLimit) or 6)))
  local candidates = {}
  for _, entry in ipairs(self:GetQuestMarkerEntries()) do
    local allowed = entry.kind == "item" and ui.questMarkerItems ~= false
      or entry.kind == "objective" and ui.questMarkerObjectives ~= false
      or entry.kind == "turnin" and ui.questMarkerTurnins ~= false
    if allowed and entry.mapID == mapID then
      local distance, dx, dy = mapDistance(px, py, entry.x, entry.y)
      if distance <= radius then
        entry.distance, entry.dx, entry.dy = distance, dx, dy
        candidates[#candidates + 1] = entry
      end
    end
  end
  table.sort(candidates, function(a, b)
    if a.complete ~= b.complete then return a.complete end
    return (a.distance or 999) < (b.distance or 999)
  end)

  local width, height = Minimap:GetWidth(), Minimap:GetHeight()
  local maxRadius = math.min(width, height) * 0.43
  for index = 1, limit do
    local entry = candidates[index]
    local marker = ensureMarker(frame, index)
    if not entry then marker:Hide() else
      local sx, sy = entry.dx * width * 2.0, -entry.dy * height * 2.0
      local length = math.sqrt(sx * sx + sy * sy)
      if length > maxRadius and length > 0 then sx, sy = sx / length * maxRadius, sy / length * maxRadius end
      marker:ClearAllPoints(); marker:SetPoint("CENTER", frame, "CENTER", sx, sy)
      marker.entry = entry
      marker.icon:SetTexture(ICONS[entry.kind] or ICONS.objective)
      local color = COLORS[entry.kind] or COLORS.objective
      marker.icon:SetVertexColor(color[1], color[2], color[3], 1)
      marker.label:SetText(ui.questMarkerLabels and trimLabel(entry.name or entry.title) or "")
      marker:Show()
    end
  end
  for index = limit + 1, #frame.markers do frame.markers[index]:Hide() end
end

function NS:SetQuestMarkersEnabled(enabled)
  self:EnsureSettings(); self.db.ui.questMarkers = enabled ~= false
  self:RefreshQuestMarkers(); self:RefreshSettings()
  self:Print(self.db.ui.questMarkers and tr("Questmarker aktiviert") or tr("Questmarker deaktiviert"))
end

function NS:SetQuestMarkerItemsEnabled(enabled)
  self:EnsureSettings(); self.db.ui.questMarkerItems = enabled ~= false; self:RefreshQuestMarkers(); self:RefreshSettings()
end

function NS:SetQuestMarkerRadius(delta)
  self:EnsureSettings()
  self.db.ui.questMarkerRadius = math.max(0.04, math.min(0.75, (self.db.ui.questMarkerRadius or 0.22) + delta))
  self:RefreshQuestMarkers(); self:RefreshSettings()
end

function NS:CycleQuestMarkerRadius()
  self:EnsureSettings()
  local values = {0.10, 0.18, 0.26, 0.36, 0.50}
  local current, nextValue = self.db.ui.questMarkerRadius or 0.22, values[1]
  for index, value in ipairs(values) do
    if math.abs(current - value) < 0.025 then nextValue = values[index % #values + 1]; break end
  end
  self.db.ui.questMarkerRadius = nextValue
  self:RefreshQuestMarkers(); self:RefreshSettings()
end

function NS:SetQuestMarkerLimit(delta)
  self:EnsureSettings()
  self.db.ui.questMarkerLimit = math.max(1, math.min(12, (self.db.ui.questMarkerLimit or 6) + delta))
  self:RefreshQuestMarkers(); self:RefreshSettings()
end

function NS:CycleQuestMarkerLimit()
  self:EnsureSettings()
  local values = {3, 6, 9, 12}
  local current, nextValue = self.db.ui.questMarkerLimit or 6, values[1]
  for index, value in ipairs(values) do
    if current == value then nextValue = values[index % #values + 1]; break end
  end
  self.db.ui.questMarkerLimit = nextValue
  self:RefreshQuestMarkers(); self:RefreshSettings()
end

function NS:ToggleQuestMarkerLabels()
  self:EnsureSettings(); self.db.ui.questMarkerLabels = not self.db.ui.questMarkerLabels
  self:RefreshQuestMarkers(); self:RefreshSettings()
end
