local NS = ForeverPath

-- Kleine, eigene Routing-Datenbank. Sie beschreibt Levelbänder, Reiseaufwand
-- und Dungeonfenster; Questdetails werden live aus dem Client gelesen.
NS.questDB = {
  ["Zephras Isle / Allianz-Startgebiet"] = { min=1, max=12, travel=1.0, faction="alliance" },
  ["Zephras Isle / Horde-Startgebiet"] = { min=1, max=12, travel=1.0, faction="horde" },
  ["Westfall"] = { min=10, max=20, travel=1.0, faction="alliance" },
  ["Loch Modan"] = { min=10, max=20, travel=1.1, faction="alliance" },
  ["Darkshore"] = { min=10, max=25, travel=1.2, faction="alliance" },
  ["Silverpine Forest"] = { min=10, max=20, travel=1.0, faction="horde" },
  ["The Barrens"] = { min=10, max=25, travel=1.1, faction="horde" },
  ["Stonetalon Mountains"] = { min=15, max=27, travel=1.2, faction="horde" },
  ["Redridge Mountains"] = { min=15, max=25, travel=1.0, faction="alliance" },
  ["Duskwood"] = { min=18, max=30, travel=1.1, faction="alliance" },
  ["Wetlands"] = { min=20, max=30, travel=1.3, faction="alliance" },
  ["Ashenvale"] = { min=18, max=30, travel=1.2, faction="neutral" },
  ["Hillsbrad Foothills"] = { min=20, max=30, travel=1.0, faction="horde" },
  ["Thousand Needles"] = { min=25, max=35, travel=1.1, faction="horde" },
  ["Stranglethorn Vale"] = { min=30, max=45, travel=1.0, faction="neutral" },
  ["Desolace"] = { min=30, max=40, travel=1.2, faction="neutral" },
  ["Riverglades"] = { min=35, max=45, travel=1.0, faction="neutral", forever=true },
  ["Dustwallow Marsh"] = { min=35, max=45, travel=1.1, faction="neutral" },
  ["Tanaris"] = { min=40, max=50, travel=1.0, faction="neutral" },
  ["Feralas"] = { min=40, max=50, travel=1.2, faction="neutral" },
  ["The Hinterlands"] = { min=40, max=50, travel=1.2, faction="neutral" },
  ["Searing Gorge"] = { min=43, max=50, travel=1.0, faction="neutral" },
  ["Un'Goro Crater"] = { min=48, max=55, travel=1.1, faction="neutral" },
  ["Felwood"] = { min=48, max=55, travel=1.2, faction="neutral" },
  ["Burning Steppes"] = { min=50, max=58, travel=1.0, faction="neutral" },
  ["Western Plaguelands"] = { min=51, max=58, travel=1.0, faction="neutral" },
  ["Eastern Plaguelands"] = { min=53, max=60, travel=1.1, faction="neutral" },
  ["Winterspring"] = { min=53, max=60, travel=1.2, faction="neutral" },
  ["Silithus"] = { min=55, max=60, travel=1.1, faction="neutral" },
}

NS.dungeonDB = {
  { name="The Deadmines", min=17, max=22, questXP=1.0 }, { name="Wailing Caverns", min=16, max=26, questXP=1.0 },
  { name="Blackfathom Deeps", min=22, max=30, questXP=1.0 }, { name="Razorfen Kraul", min=26, max=34, questXP=1.0 },
  { name="Gnomeregan", min=26, max=35, questXP=1.0 }, { name="Scarlet Monastery", min=30, max=42, questXP=1.0 },
  { name="Maraudon", min=42, max=51, questXP=1.0 }, { name="Krol'Dok Stronghold", min=35, max=45, questXP=1.0, forever=true },
  { name="Zul'Farrak", min=45, max=50, questXP=1.0 }, { name="Blackrock Depths", min=52, max=60, questXP=1.0 },
  { name="Lower Blackrock Spire", min=55, max=60, questXP=1.0 }, { name="Scholomance", min=58, max=60, questXP=1.0 },
  { name="Stratholme", min=58, max=60, questXP=1.0 },
}
