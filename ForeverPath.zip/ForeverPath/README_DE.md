# ForeverPath

Eigenständiges, kleines Guide-Addon für World of Warcraft: Forever. Es ist kein RestedXP-Klon und enthält keine RestedXP-Quelltexte, Grafiken, Texte oder geschützten Routen. Die mitgelieferten Schritte sind neu formulierte Beispielinhalte und dienen als funktionsfähige Basis für eigene Routen.

## Funktionen

- interaktives Guide-Fenster mit gespeichertem Fortschritt
- zusammenhängende 1–60-Planung in 15 Zonenabschnitten pro Fraktion
- pro Abschnitt Ankunft, Hauptziele und Abschluss/Weiterreise
- Speedrun-, Dungeon-, Discovery- und Legacy-Modus
- Allianz-/Horde-Routenumschalter (Horde nutzt zunächst dieselbe neutrale Vorlage)
- Zurück, erledigt/weiter, Reset und optionale Karten-Wegpunkte
- automatische Klassenerkennung mit eigenen Leveling-Hinweisen für alle neun Forever-Klassen
- Geschwindigkeitsprofile für Solo-, Dungeon- und Hybridklassen
- eigene Routing-Datenbank für Zonen-/Dungeon-Levelbänder und Reiseaufwand
- Live-Questlog-Scan und Score-Empfehlung mit XP/Minute, Reisezeit, Risiko, Gruppenwartezeit, Klassen-, Dungeon- und Ausrüstungsbonus
- Minimap-Icon: Linksklick öffnet das Menü, Rechtsklick analysiert die Route, Ziehen verschiebt das Icon; ein Chatbefehl ist zum Öffnen nicht nötig
- Die Bedienung läuft vollständig über Minimap-Icon, Tracker-Buttons und das Ingame-Menü; es sind keine Chatbefehle nötig
- automatische Analyse 2 Sekunden nach dem Login und anschließend alle 5 Minuten
- zusätzlicher Button „Jetzt analysieren“ im Tab „Einstellungen"
- kleiner, verschiebbarer Ingame-Tracker mit aktuellem Schritt, Gebiet, Aufgabe, Fortschritt und Score
- eigener verschiebbarer Navigations-HUD mit Richtungsanzeige, Distanz, ETA-Schätzung und dynamischem Questziel
- dynamische Ziel-Linie und Zielpunkt auf der Minimap
- geglättete Pfeilrotation relativ zur Spielerblickrichtung und bis zu drei kommende Ziele als Minimap-Punkte
- Weltkarten-Overlay mit Linie vom Spieler zum aktuellen Ziel und kommenden Routenpunkten
- Navigation lässt sich im Einstellungen-Tab ein- und ausschalten
- dynamische Route-Recovery: passende spätere Schritte werden nach aktueller Zone und Score gesucht
- Session-Tracker mit XP/h, Sessionzeit und Todesfällen
- Ausrüstungszustand, Klassenstat-Gewichtung und mögliche Questbelohnungs-Upgrades im Live-Ratschlag
- Dungeon-Empfehlung abhängig von Level, Gruppe, Rolle, ForeverDB-Status, Dungeonart und heuristischem Loot-/Gear-Bedarf
- zusätzliche lokale ForeverDB-Daten für Dungeons, Klassen, Berufe und Zonen
- automatische Klassen-/Trainerstopps und Berufsdaten-Hinweise als route-sichere Empfehlungen
- automatische Questbeobachtung: angenommene, laufende und abgegebene Quests werden mit ID, Titel, Level und Objektiven erfasst
- Lernmetriken für Todesfälle, XP-Ereignisse, Schrittzeiten und beobachtete Questdaten
- offene Questmarker-Daten aus QuestieDB-Forever sowie normalisierte Klassen-/Routenhinweise aus Evergreen for WoW Forever

## Öffentliche Daten und Lizenzen

Die eingebundenen Daten stammen aus öffentlichen Community-Repositories und werden nicht als RestedXP-Daten beworben:

- `ExternalData/QuestieForeverQuests.lua` und Metadaten: [Forever Quest Pins](https://github.com/TylerAkins/forever-quest-markers), QuestieDB-Forever, GPL-3.0
- `ExternalData/ForeverDBQuests.lua`: importierte Questdaten der [ForeverDB API](https://foreverdb.net/developers), mit sichtbarer Attribution `Data from ForeverDB.net (https://foreverdb.net)`
- `ExternalData/ForeverDBSupplemental.lua`: lokaler ForeverDB-Import für Dungeons, Klassen, Berufe und Zonen; der Buildstand wird im Einstellungen-Tab angezeigt
- `ExternalData/EvergreenRoutes.lua`: aus den öffentlichen Routendateien von [Evergreen for WoW Forever](https://github.com/Dj2Swagittarius/evergreen-wow-forever), GPL-2.0-or-later
- Lizenztexte, Attribution und Import-Hinweise liegen vollständig unter `ExternalData/`

Bei Weitergabe müssen die Hinweise, Lizenztexte, ForeverDB-Attribution und der zugehörige Quelltext erhalten bleiben. Die importierten ForeverDB-Daten sind ein fester Build-Stand und werden im Spiel nicht live abgefragt. Nicht verifizierte oder fehlende Daten werden nicht als sicher ausgegeben.

Die Fortschritts- und Routenbewertung ist bewusst transparent: tatsächliche XP/h, Reisezeit und Todesfälle kommen aus deiner Session; fehlende Loot-, Questketten- oder Laufzeitwerte bleiben Schätzungen und werden als solche bezeichnet.

## ForeverDB-Import für neue Datenstände

Einen API-Schlüssel bekommst du auf der [ForeverDB-Developer-Seite](https://foreverdb.net/developers):

1. Mit Battle.net einloggen.
2. Auf derselben Seite kurz beschreiben, was du baust, eine E-Mail-Adresse angeben und der sichtbaren Nennung von `ForeverDB.net` zustimmen.
3. Nach der Freischaltung dort bis zu drei persönliche Schlüssel erstellen.

Der Schlüssel gehört nicht in eine veröffentlichte Addon-ZIP. WoW-Addons können keine beliebigen HTTP-Anfragen ausführen; außerdem wäre ein eingebauter Schlüssel für jeden lesbar. Neue API-Daten werden außerhalb des Spiels lokal geladen und anschließend als dokumentierter Datenimport in das Addon gepackt. Die sichtbare Quellenangabe `https://foreverdb.net` steht im Einstellungen-Tab und im Questtracker.

Für reproduzierbare Datenupdates liegt im Repository zusätzlich `DATA-UPDATE.md` mit dem lokalen Importer `tools/import_foreverdb.py`. Der Importer nutzt ausschließlich `FOREVERDB_API_KEY` aus der lokalen Umgebung und schreibt den Schlüssel nicht in den Build.

## Installation

1. Auf GitHub **Code → Download ZIP** auswählen. Die Datei heißt danach `LvL-Guide-main.zip`.
2. `LvL-Guide-main.zip` entpacken. Darin liegt `ForeverPath.zip`.
3. Auch `ForeverPath.zip` entpacken. Der darin enthaltene Ordner `ForeverPath` ist der Addon-Ordner.
4. Den Ordner `ForeverPath` nach `<WoW-Forever>/_forever_/Interface/AddOns/` kopieren.
5. Im Spiel die Addon-Liste öffnen und ForeverPath aktivieren.
6. Das verschiebbare Minimap-Icon anklicken. Alle Funktionen sind über die sichtbaren Buttons erreichbar.

Am Ende muss die Datei direkt hier liegen:

```text
<WoW-Forever>/_forever_/Interface/AddOns/ForeverPath/ForeverPath.toc
```

Nicht richtig sind `AddOns/ForeverPath.zip/ForeverPath` oder `AddOns/ForeverPath/ForeverPath/ForeverPath.toc`.

## Kompatibilität

Zielstand ist `## Interface: 16001`, wie er für den derzeit dokumentierten Forever-Beta-Stand beschrieben wird. Der Client-Build muss vor einem Release im Spiel geprüft werden; bei abweichender Interface-Nummer die TOC-Zeile anpassen. Das Addon nutzt sichere UI-/Kartenfunktionen, liest keine geheimen Kampfwerte und automatisiert keine Entscheidungen.

Die enthaltenen Routen sind eine eigene 1–60-Planung mit Forever-Zonen und Dungeonfenstern. Die Klassenprofile sind eine heuristische Geschwindigkeitsoptimierung, kein gemessener Weltrekord: Gruppensuche, Serverpopulation, Ausrüstung und XP-Tuning verändern das Ergebnis. Es werden bewusst keine kopierten RestedXP-Questtexte oder geschützten Schrittlisten verwendet.
