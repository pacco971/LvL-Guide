# ForeverPath

Eigenständiges, kleines Guide-Addon für World of Warcraft: Forever. Es ist kein RestedXP-Klon und enthält keine RestedXP-Quelltexte, Grafiken, Texte oder geschützten Routen. Die mitgelieferten Schritte sind neu formulierte Beispielinhalte und dienen als funktionsfähige Basis für eigene Routen.

## Funktionen

- interaktives Guide-Fenster mit gespeichertem Fortschritt
- zusammenhängende 1–60-Planung in 15 Zonenabschnitten pro Fraktion
- pro Abschnitt Ankunft, Hauptziele und Abschluss/Weiterreise
- Speedrun-, Dungeon-, Discovery- und Legacy-Modus
- Allianz-/Horde-Routenumschalter (Horde nutzt zunächst dieselbe neutrale Vorlage)
- Zurück, erledigt/weiter, Reset und optionale Karten-Wegpunkte
- automatische Klassenerkennung mit eigenen Leveling-Hinweisen für alle neun Forever-Klassen
- Geschwindigkeitsprofile für Solo-, Dungeon- und Hybridklassen
- eigene Routing-Datenbank für Zonen-/Dungeon-Levelbänder und Reiseaufwand
- Live-Questlog-Scan und Score-Empfehlung mit XP/Minute, Reisezeit, Risiko, Gruppenwartezeit, Klassen-, Dungeon- und Ausrüstungsbonus
- Minimap-Icon: Linksklick öffnet das Menü, Rechtsklick analysiert die Route, Ziehen verschiebt das Icon; ein Chatbefehl ist zum Öffnen nicht nötig
- Befehle bleiben optional: `/fp`, `/fp next`, `/fp prev`, `/fp mode speed|dungeon|discovery|legacy`, `/fp route alliance|horde`, `/fp reset`, `/fp help`; `/fp scan` zeigt die aktuelle Score-Aufschlüsselung
- automatische Analyse 2 Sekunden nach dem Login und anschließend alle 5 Minuten
- zusätzlicher Button „Jetzt analysieren“ im Tab „Einstellungen"
- kleiner, verschiebbarer Ingame-Tracker mit aktuellem Schritt, Gebiet, Aufgabe, Fortschritt und Score
- automatische Questbeobachtung: angenommene, laufende und abgegebene Quests werden mit ID, Titel, Level und Objektiven erfasst
- Lernmetriken für Todesfälle, XP-Ereignisse, Schrittzeiten und beobachtete Questdaten
- offene Questmarker-Daten aus QuestieDB-Forever sowie normalisierte Klassen-/Routenhinweise aus Evergreen for WoW Forever

## Öffentliche Daten und Lizenzen

Die eingebundenen Daten stammen aus öffentlichen Community-Repositories und werden nicht als RestedXP-Daten beworben:

- `ExternalData/QuestieForeverQuests.lua` und Metadaten: [Forever Quest Pins](https://github.com/TylerAkins/forever-quest-markers), QuestieDB-Forever, GPL-3.0
- `ExternalData/ForeverDBQuests.lua`: importierte Questdaten der [ForeverDB API](https://foreverdb.net/developers), mit sichtbarer Attribution `Data from ForeverDB.net (https://foreverdb.net)`
- `ExternalData/EvergreenRoutes.lua`: aus den öffentlichen Routendateien von [Evergreen for WoW Forever](https://github.com/Dj2Swagittarius/evergreen-wow-forever), GPL-2.0-or-later
- Lizenztexte, Attribution und Import-Hinweise liegen vollständig unter `ExternalData/`

Bei Weitergabe müssen die Hinweise, Lizenztexte, ForeverDB-Attribution und der zugehörige Quelltext erhalten bleiben. Die importierten ForeverDB-Daten sind ein fester Build-Stand und werden im Spiel nicht live abgefragt. Nicht verifizierte oder fehlende Daten werden nicht als sicher ausgegeben.

## ForeverDB-Import für neue Datenstände

Einen API-Schlüssel bekommst du auf der [ForeverDB-Developer-Seite](https://foreverdb.net/developers):

1. Mit Battle.net einloggen.
2. Auf derselben Seite kurz beschreiben, was du baust, eine E-Mail-Adresse angeben und der sichtbaren Nennung von `ForeverDB.net` zustimmen.
3. Nach der Freischaltung dort bis zu drei persönliche Schlüssel erstellen.

Der Schlüssel gehört nicht in eine veröffentlichte Addon-ZIP. WoW-Addons können keine beliebigen HTTP-Anfragen ausführen; außerdem wäre ein eingebauter Schlüssel für jeden lesbar. Neue API-Daten werden außerhalb des Spiels lokal geladen und anschließend als dokumentierter Datenimport in das Addon gepackt. Die sichtbare Quellenangabe `https://foreverdb.net` steht im Einstellungen-Tab und im Questtracker.

## Installation

1. Den Ordner `ForeverPath` nach `<WoW-Forever>/_classic_beta_/Interface/AddOns/ForeverPath/` kopieren.
2. Im Spiel die Addon-Liste öffnen und ForeverPath aktivieren.
3. Das verschiebbare Minimap-Icon anklicken. `/fp` bleibt als optionaler Fallback verfügbar.

## Kompatibilität

Zielstand ist `## Interface: 16001`, wie er für den derzeit dokumentierten Forever-Beta-Stand beschrieben wird. Der Client-Build muss vor einem Release im Spiel geprüft werden; bei abweichender Interface-Nummer die TOC-Zeile anpassen. Das Addon nutzt sichere UI-/Kartenfunktionen, liest keine geheimen Kampfwerte und automatisiert keine Entscheidungen.

Die enthaltenen Routen sind eine eigene 1–60-Planung mit Forever-Zonen und Dungeonfenstern. Die Klassenprofile sind eine heuristische Geschwindigkeitsoptimierung, kein gemessener Weltrekord: Gruppensuche, Serverpopulation, Ausrüstung und XP-Tuning verändern das Ergebnis. Es werden bewusst keine kopierten RestedXP-Questtexte oder geschützten Schrittlisten verwendet.
