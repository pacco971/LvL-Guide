local NS = ForeverPath

local BUILTIN_SERVER_HOTFIXES = {
  dungeonKillXP = {
    multiplier = 1.5,
    effectiveDate = "2026-11-08",
    source = "https://foreverdb.net/article/dungeon-kill-xp-increased-november-8",
    scope = "dungeon enemy kill XP only; dungeon quest XP is unchanged",
  },
}

-- Small adapter for the optional ForeverDB build/hotfix snapshot.  The addon
-- never contacts the API at runtime; this only reads the generated, static
-- data file and turns it into honest UI text.
local function countRows(value)
  if type(value) ~= "table" then return 0 end
  if type(value.data) == "table" then return #value.data end
  return 0
end

local function buildOf(value)
  if type(value) ~= "table" then return nil end
  local meta = value.meta
  if type(meta) == "table" then
    return meta.build or meta.dataBuild or meta.clientBuild
  end
  return value.build or value.dataBuild or value.clientBuild
end

function NS:GetForeverDBHotfixStatus()
  local supplemental = self.foreverDBSupplemental or {}
  local hotfixes = supplemental.hotfixes
  local serverHotfixes = supplemental.serverHotfixes or BUILTIN_SERVER_HOTFIXES
  local metadata = self.ForeverDBMetadata or {}
  local build = metadata.build or buildOf(supplemental.dungeons) or "lokal"
  if type(hotfixes) ~= "table" then
    local dungeonKillXP = serverHotfixes.dungeonKillXP or BUILTIN_SERVER_HOTFIXES.dungeonKillXP
    return {
      build = build,
      imported = false,
      text = "Server-Hotfix bekannt; optionaler API-Snapshot fehlt",
      counts = {},
      dungeonKillXPMultiplier=tonumber(dungeonKillXP and dungeonKillXP.multiplier) or 1,
      dungeonKillXPSource=dungeonKillXP and dungeonKillXP.source,
    }
  end
  local counts = {
    builds = countRows(hotfixes.builds),
    buffsNerfs = countRows(hotfixes.buffsNerfs),
    merchantsFavor = countRows(hotfixes.merchantsFavor),
  }
  local dungeonKillXP = serverHotfixes.dungeonKillXP or BUILTIN_SERVER_HOTFIXES.dungeonKillXP
  local latest = hotfixes.latestBuild
  local latestBuild = buildOf(latest)
  if type(latest) == "table" and type(latest.data) == "table" and latest.data[1] then
    latestBuild = latest.data[1].build or latest.data[1].id or latestBuild
  end
  local warning = hotfixes.meta and hotfixes.meta.warning
  local text
  if warning then
    text = "Hotfix-Snapshot teilweise nicht verfügbar"
  elseif latestBuild and tostring(latestBuild) ~= tostring(build) then
    text = string.format("Neuere ForeverDB-Buildinfo: %s (Paket: %s)", tostring(latestBuild), tostring(build))
  else
    text = string.format("ForeverDB-Hotfixdaten aktuell zum Paket-Build %s", tostring(build))
  end
  return {
    build=build,
    latestBuild=latestBuild,
    imported=true,
    text=text,
    counts=counts,
    refreshedAt=supplemental.meta and supplemental.meta.refreshedAtUtc,
    dungeonKillXPMultiplier=tonumber(dungeonKillXP and dungeonKillXP.multiplier) or 1,
    dungeonKillXPSource=dungeonKillXP and dungeonKillXP.source,
  }
end

local function safeNumber(value)
  if issecretvalue and issecretvalue(value) then return nil end
  if type(value) == "number" then return value end
  return tonumber(value)
end

local function safeUnitLevel(unit)
  if not UnitLevel then return nil end
  local ok, level = pcall(UnitLevel, unit)
  if not ok then return nil end
  return safeNumber(level)
end

function NS:GetConfiguredDungeonKillXPMultiplier()
  local supplemental = self.foreverDBSupplemental or {}
  local hotfix = (supplemental.serverHotfixes and supplemental.serverHotfixes.dungeonKillXP) or BUILTIN_SERVER_HOTFIXES.dungeonKillXP
  local multiplier = tonumber(hotfix and hotfix.multiplier)
  if multiplier and multiplier > 0 then return multiplier end
  return 1
end

function NS:GetGroupLevelCeiling()
  local highest = safeUnitLevel("player")
  if IsInGroup and not IsInGroup() then return highest end
  local units = {}
  local inRaid = IsInRaid and IsInRaid()
  local count = GetNumGroupMembers and safeNumber(GetNumGroupMembers()) or 0
  if inRaid then
    for index = 1, count do units[#units + 1] = "raid" .. index end
  else
    units[#units + 1] = "player"
    for index = 1, math.max(0, count - 1) do units[#units + 1] = "party" .. index end
  end
  for _, unit in ipairs(units) do
    local level = safeUnitLevel(unit)
    if level and (not highest or level > highest) then highest = level end
  end
  return highest
end

function NS:GetDungeonKillXPState(step)
  local multiplier = self:GetConfiguredDungeonKillXPMultiplier()
  local state = { multiplier = multiplier, trivial = false, reason = "Hotfix-Multiplikator aktiv" }
  local groupLevel = self:GetGroupLevelCeiling()
  local targetLevel = safeUnitLevel("target")

  -- Use the live target when available.  UnitIsTrivial is optional on Forever
  -- builds, so every call is guarded and taint-safe.
  if UnitExists and UnitExists("target") and UnitCanAttack and UnitCanAttack("player", "target") then
    if UnitIsTrivial then
      local ok, trivial = pcall(UnitIsTrivial, "target")
      if ok and trivial == true then
        state.trivial = true
        state.reason = "Ziel ist für die Gruppe trivial"
      end
    end
    if not state.trivial and targetLevel and groupLevel and targetLevel + 5 <= groupLevel then
      state.trivial = true
      state.reason = string.format("Zielstufe %d liegt mindestens 5 unter Gruppenstufe %d", targetLevel, groupLevel)
    end
  end

  -- During route scoring there may be no target.  Only use the dungeon range
  -- when the whole range is safely trivial; this avoids zeroing normal runs.
  if not state.trivial and groupLevel then
    local record = step and step.record or nil
    local dungeon = record and record.dungeon or nil
    local maxLevel = record and (record.enemyMaxLevel or record.dungeonMaxLevel or record.maxLevel)
    maxLevel = safeNumber(maxLevel) or (dungeon and safeNumber(dungeon.max))
    if maxLevel and groupLevel >= maxLevel + 5 then
      state.trivial = true
      state.reason = string.format("Dungeon-Maximalstufe %d liegt mindestens 5 unter Gruppenstufe %d", maxLevel, groupLevel)
    end
  end

  if state.trivial then state.multiplier = 0 end
  return state
end

function NS:GetDungeonKillXPMultiplier(step)
  return self:GetDungeonKillXPState(step).multiplier
end

function NS:GetForeverDBHotfixSummary()
  local status = self:GetForeverDBHotfixStatus()
  local c = status.counts or {}
  local refreshed = status.refreshedAt and (" · " .. tostring(status.refreshedAt)) or ""
  local dungeon = status.dungeonKillXPMultiplier and status.dungeonKillXPMultiplier ~= 1
    and string.format(" · Dungeon-Mob-XP %.1fx", status.dungeonKillXPMultiplier) or ""
  return string.format("%s · Builds %d · Buffs/Nerfs %d · Händler %d%s%s", status.text, c.builds or 0, c.buffsNerfs or 0, c.merchantsFavor or 0, dungeon, refreshed)
end

