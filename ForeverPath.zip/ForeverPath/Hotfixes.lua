local NS = ForeverPath

-- Small adapter for the optional ForeverDB build/hotfix snapshot.  The addon
-- never contacts the API at runtime; this only reads the generated, static
-- data file and turns it into honest UI text.
local function countRows(value)
  if type(value) ~= "table" then return 0 end
  if type(value.data) == "table" then return #value.data end
  return 0
end

local function buildOf(value)
  if type(value) ~= "table" then return nil end
  local meta = value.meta
  if type(meta) == "table" then
    return meta.build or meta.dataBuild or meta.clientBuild
  end
  return value.build or value.dataBuild or value.clientBuild
end

function NS:GetForeverDBHotfixStatus()
  local supplemental = self.foreverDBSupplemental or {}
  local hotfixes = supplemental.hotfixes
  local metadata = self.ForeverDBMetadata or {}
  local build = metadata.build or buildOf(supplemental.dungeons) or "lokal"
  if type(hotfixes) ~= "table" then
    return {
      build = build,
      imported = false,
      text = "Hotfix-Snapshot nicht im Datenpaket vorhanden",
      counts = {},
    }
  end
  local counts = {
    builds = countRows(hotfixes.builds),
    buffsNerfs = countRows(hotfixes.buffsNerfs),
    merchantsFavor = countRows(hotfixes.merchantsFavor),
  }
  local latest = hotfixes.latestBuild
  local latestBuild = buildOf(latest)
  if type(latest) == "table" and type(latest.data) == "table" and latest.data[1] then
    latestBuild = latest.data[1].build or latest.data[1].id or latestBuild
  end
  local warning = hotfixes.meta and hotfixes.meta.warning
  local text
  if warning then
    text = "Hotfix-Snapshot teilweise nicht verfügbar"
  elseif latestBuild and tostring(latestBuild) ~= tostring(build) then
    text = string.format("Neuere ForeverDB-Buildinfo: %s (Paket: %s)", tostring(latestBuild), tostring(build))
  else
    text = string.format("ForeverDB-Hotfixdaten aktuell zum Paket-Build %s", tostring(build))
  end
  return {build=build, latestBuild=latestBuild, imported=true, text=text, counts=counts, refreshedAt= supplemental.meta and supplemental.meta.refreshedAtUtc}
end

function NS:GetForeverDBHotfixSummary()
  local status = self:GetForeverDBHotfixStatus()
  local c = status.counts or {}
  local refreshed = status.refreshedAt and (" · " .. tostring(status.refreshedAt)) or ""
  return string.format("%s · Builds %d · Buffs/Nerfs %d · Händler %d%s", status.text, c.builds or 0, c.buffsNerfs or 0, c.merchantsFavor or 0, refreshed)
end

