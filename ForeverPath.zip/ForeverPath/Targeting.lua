local NS = ForeverPath

local function safe(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, value = pcall(fn, ...)
  return ok and value or nil
end

local function numeric(value)
  if type(value) ~= "number" then return nil end
  if issecretvalue then
    local ok, secret = pcall(issecretvalue, value)
    if ok and secret then return nil end
  end
  return value
end

local function zoneMatch(a, b)
  if not a or not b then return false end
  a, b = string.lower(tostring(a)), string.lower(tostring(b))
  return a == b or string.find(a, b, 1, true) or string.find(b, a, 1, true)
end

function NS:GetEfficientMobWaypoint()
  local step = self.GetCurrentStep and self:GetCurrentStep()
  local objective = step and self.GetTrackedObjective and self:GetTrackedObjective(step)
  local route = objective and objective.route
  if route and route.objective and route.objective.mapID and route.objective.x and route.objective.y then
    return { mapID=route.objective.mapID, x=route.objective.x, y=route.objective.y, hint=route.objective.name, title=route.title, kind="enemy", source="Questziel" }
  end

  local zone = self.GetPlayerZone and self:GetPlayerZone() or step and step.zone
  local level = self.GetPlayerLevel and self:GetPlayerLevel() or UnitLevel and UnitLevel("player") or 1
  local currentMap = C_Map and C_Map.GetBestMapForUnit and safe(C_Map.GetBestMapForUnit, "player")
  local px, py = currentMap and self.GetSafeMapPosition and self:GetSafeMapPosition(currentMap, "player")
  local best, bestScore
  for _, candidate in ipairs(self.externalRoutes or {}) do
    local point = candidate.objective
    if point and point.mapID and point.x and point.y and zoneMatch(candidate.zone or candidate.title, zone) then
      local classOK = not candidate.class or candidate.class == self:GetClassToken()
      local mapBonus = currentMap and point.mapID == currentMap and 30 or 0
      local distancePenalty = 0
      if px and py and point.mapID == currentMap then distancePenalty = math.sqrt((point.x-px*100)^2+(point.y-py*100)^2) / 10 end
      local score = mapBonus - distancePenalty + (classOK and 10 or -60)
      if candidate.level then score = score - math.abs(level - candidate.level) * 2 end
      if not bestScore or score > bestScore then
        bestScore = score
        best = { mapID=point.mapID, x=point.x, y=point.y, hint=point.name or candidate.title, title=candidate.title, kind="enemy", source="Evergreen/ForeverPath" }
      end
    end
  end
  return best
end

function NS:GetMobXPEstimate(unit)
  unit = unit or "target"
  if not UnitExists or not UnitExists(unit) or (UnitIsPlayer and UnitIsPlayer(unit)) then return nil end
  local level = numeric(safe(UnitLevel, unit))
  if not level or level <= 0 then return nil end
  local playerLevel = numeric(safe(UnitLevel, "player")) or level
  local db = self.db or {}
  db.mobXPByLevel = db.mobXPByLevel or {}
  local row = db.mobXPByLevel[level]
  local base = row and row.average or nil
  local estimated = false
  if not base or base <= 0 then
    local delta = level - playerLevel
    if delta <= -5 then base = 0 else base = math.max(1, 45 + level * 6 + delta * 12) end
    estimated = true
  end
  local classification = safe(UnitClassification, unit)
  if classification == "elite" then base = base * 2; estimated = true
  elseif classification == "rareelite" then base = base * 2.5; estimated = true end
  local multipliers = self.GetXPMultipliers and self:GetXPMultipliers() or {kill=1}
  local final = base * (multipliers.kill or 1)
  local maximum = numeric(safe(UnitXPMax, "player")) or 0
  local percent = maximum > 0 and final / maximum * 100 or 0
  return {unit=unit, level=level, base=base, xp=final, percent=percent, kills=final > 0 and math.ceil((numeric(safe(UnitXPMax, "player")) or 1) / final) or 0, estimated=estimated, multipliers=multipliers}
end

function NS:RecordMobXPObservation(gain)
  gain = numeric(gain)
  if not gain or gain <= 0 or not UnitExists or not UnitExists("target") or (UnitIsPlayer and UnitIsPlayer("target")) then return end
  local level = numeric(safe(UnitLevel, "target"))
  if not level or level <= 0 then return end
  self.db.mobXPByLevel = self.db.mobXPByLevel or {}
  local row = self.db.mobXPByLevel[level] or {average=0, samples=0}
  row.samples = math.min(100, (row.samples or 0) + 1)
  row.average = ((row.average or gain) * (row.samples - 1) + gain) / row.samples
  self.db.mobXPByLevel[level] = row
end

function NS:AddMobTooltip(tooltip, unit)
  if not tooltip or not unit or not UnitExists or not UnitExists(unit) then return end
  local estimate = self:GetMobXPEstimate(unit)
  if not estimate or tooltip.foreverPathMobLine then return end
  tooltip.foreverPathMobLine = true
  local label = estimate.estimated and "Mob-XP (Schätzung)" or "Mob-XP"
  tooltip:AddLine(string.format("%s: %d XP · %.2f%% des Levels", label, estimate.xp, estimate.percent), 0.55, 0.78, 0.95)
  tooltip:AddLine(string.format("Kills bis Level-Up: %d · Faktor %.2fx", estimate.kills, estimate.multipliers and estimate.multipliers.kill or 1), 0.65, 0.70, 0.82)
  if estimate.multipliers and estimate.multipliers.labels and #estimate.multipliers.labels > 0 then
    tooltip:AddLine("XP-Status: " .. table.concat(estimate.multipliers.labels, ", "), 0.55, 0.78, 0.62)
  end
  tooltip:Show()
end

function NS:CreateTargeting()
  if self.targetingReady then return end
  local function addUnitTooltip(tooltip)
    if not tooltip then return end
    local okUnit, _, unit = pcall(tooltip.GetUnit, tooltip)
    if not okUnit then unit = nil end
    if not unit and UnitExists and UnitExists("mouseover") then unit = "mouseover" end
    NS:AddMobTooltip(tooltip, unit)
  end
  local hooked = false
  -- Newer clients expose the post-call tooltip processor. It avoids hooking
  -- protected GameTooltip scripts on Forever builds that reject HookScript.
  if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Unit then
    local ok = pcall(TooltipDataProcessor.AddTooltipPostCall, Enum.TooltipDataType.Unit, addUnitTooltip)
    hooked = ok
  end
  if not hooked and GameTooltip and type(GameTooltip.HookScript) == "function" then
    local ok = pcall(function()
      GameTooltip:HookScript("OnTooltipSetUnit", function(tooltip)
        tooltip.foreverPathMobLine = nil
        addUnitTooltip(tooltip)
      end)
    end)
    hooked = ok
  end
  -- A tooltip hook is optional. Never retry a rejected client hook and never
  -- let it prevent the rest of ForeverPath from initializing.
  self.targetingReady = true
end
