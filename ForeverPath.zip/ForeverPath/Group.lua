local NS=ForeverPath
function NS:GetGroupState()
  local grouped=IsInGroup and IsInGroup() or false
  return grouped,UnitGroupRolesAssigned and UnitGroupRolesAssigned("player") or "NONE"
end
function NS:BeginGroupWait() self.groupWaitStart=GetTime(); self:Refresh() end
function NS:EndGroupWait()
  if self.groupWaitStart then self.db.lastGroupWait=GetTime()-self.groupWaitStart; self.groupWaitStart=nil end
end
function NS:UpdateGroup()
  local grouped=self:GetGroupState()
  if grouped then self:EndGroupWait()
  elseif self.db.mode=="dungeon" and self.db.autoSolo then self.db.preferredMode="dungeon"; self.db.mode="speed"; self:InvalidateQuestPlan() end
end
function NS:GetGroupAdvice()
  local grouped,role=self:GetGroupState(); local tank,heal=0,0
  for i=1,(GetNumGroupMembers and GetNumGroupMembers() or 0) do
    local unit=(IsInRaid and IsInRaid()) and "raid"..i or i==1 and "player" or "party"..(i-1)
    local r=UnitGroupRolesAssigned and UnitGroupRolesAssigned(unit)
    if r=="TANK" then tank=tank+1 elseif r=="HEALER" then heal=heal+1 end
  end
  local quests=0; for id in pairs(self:GetQuestState().quests) do if self.questDB[id] and self.questDB[id].isInstanceQuest then quests=quests+1 end end
  local wait=self.groupWaitStart and GetTime()-self.groupWaitStart or self.db.lastGroupWait or 0
  return string.format("%s · Rolle %s\nTank: %d · Heiler: %d · aktive Dungeonquests: %d\nGemessene Wartezeit: %.1f Min.\nLoot-Ertrag und Dungeon-XP/h: ohne abgeschlossene Messung unbekannt.",grouped and "Gruppe vorhanden" or "Solo-Route",role,tank,heal,quests,wait/60)
end
