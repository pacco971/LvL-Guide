local NS = ForeverPath

-- UI language only. Quest names and objective text are kept in the language
-- returned by the Forever client/quest log instead of being machine-translated.
local EN = {
  ["Horde"] = "Horde",
  ["Allianz"] = "Alliance",
  ["Deine Route. Dein Tempo. Deine Entscheidung."] = "Your route. Your pace. Your decision.",
  ["Schnell leveln"] = "Fast leveling",
  ["Klasse"] = "Class",
  ["Einstellungen"] = "Settings",
  ["Route konfigurieren"] = "Configure route",
  ["Modus und Fraktion ändern den aktiven Guide. Der Fortschritt des aktuellen Modus wird auf Schritt 1 gesetzt."] = "Mode and faction change the active guide. The selected mode starts again at step 1.",
  ["Die Route läuft automatisch. Hier bleiben nur die Schalter, die du im Spiel wirklich brauchst."] = "The route runs automatically. Only the controls you actually need in-game are shown here.",
  ["ROUTE"] = "ROUTE",
  ["Solo / Quests"] = "Solo / Quests",
  ["Jetzt analysieren"] = "Analyze now",
  ["Fortschritt zurücksetzen"] = "Reset progress",
  ["Questlog-Scan: beim Login und automatisch alle 5 Minuten."] = "Quest log scan: on login and automatically every 5 minutes.",
  ["HUD"] = "HUD",
  ["Questtracker"] = "Quest tracker",
  ["Tracker einklappen"] = "Collapse tracker",
  ["Tracker −"] = "Tracker −",
  ["Tracker +"] = "Tracker +",
  ["Pfeil −"] = "Arrow −",
  ["Pfeil +"] = "Arrow +",
  ["Transparenz"] = "Opacity",
  ["UI sperren"] = "Lock UI",
  ["Schriftgröße"] = "Font size",
  ["Pfeilfarbe"] = "Arrow color",
  ["Pfeilstil"] = "Arrow style",
  ["Minimap −"] = "Minimap −",
  ["Minimap +"] = "Minimap +",
  ["Minimap-Icon: 1.0x"] = "Minimap icon: 1.0x",
  ["STATUS & SUPPORT"] = "STATUS & SUPPORT",
  ["Fehlerbericht"] = "Error report",
  ["Datenstatus"] = "Data status",
  ["Offene Daten werden geladen."] = "Open data is loading.",
  ["ForeverDB-Zusatzdaten werden geladen."] = "ForeverDB supplemental data is loading.",
  ["Quellen: ForeverDB.net · QuestieDB-Forever · Evergreen for WoW Forever\nDer ForeverDB-API-Schlüssel ist nicht im Addon enthalten."] = "Sources: ForeverDB.net · QuestieDB-Forever · Evergreen for WoW Forever\nThe ForeverDB API key is not included in the addon.",
  ["Navigation: AN"] = "Navigation: ON",
  ["Navigation: AUS"] = "Navigation: OFF",
  ["UI entsperren"] = "Unlock UI",
  ["UI sperren"] = "Lock UI",
  ["Minimap-Icon: %.1fx"] = "Minimap icon: %.1fx",
  ["Tracker-Skalierung: %.2fx"] = "Tracker scale: %.2fx",
  ["Pfeil-Skalierung: %.2fx"] = "Arrow scale: %.2fx",
  ["Minimap-Icon: %.2fx"] = "Minimap icon: %.2fx",
  ["Pfeil folgt deiner Blickrichtung"] = "Arrow follows your facing",
  ["Gebietsrichtung wird berechnet"] = "Zone direction is being calculated",
  ["Zielkoordinaten werden geprüft"] = "Checking target coordinates",
  ["Route-Recovery aktiv"] = "Route recovery active",
  ["Minimap-Linie und Folgeziele live"] = "Live minimap line and upcoming targets",
  ["Für dieses Ziel fehlen Koordinaten"] = "This target has no coordinates",
  ["Ziele aus dem Questlog werden automatisch gelesen"] = "Objectives are read from the quest log automatically",
  ["Fortschritt wird aus dem Client gelesen"] = "Progress is read from the client",
  ["Quest annehmen"] = "Accept quest",
  ["Quest abgeben"] = "Turn in quest",
  ["Aktuelles Questziel"] = "Current quest objective",
  ["Quest kann abgegeben werden"] = "Quest ready to turn in",
  ["Questziel wird automatisch aus dem Client gelesen"] = "Quest objective is read from the client automatically",
  ["Questziel"] = "Quest objective",
  ["Kein Wegpunkt"] = "No waypoint",
  ["Schritt ohne Zielkoordinaten"] = "Step has no target coordinates",
  ["Zielkoordinaten fehlen"] = "Target coordinates missing",
  ["Gebietswechsel"] = "Zone change",
  ["Gebietswechsel erforderlich"] = "Zone change required",
  ["Gebietsrichtung"] = "Zone direction",
  ["Wegpunkt auf der Weltkarte gesetzt"] = "Waypoint set on the world map",
  ["Dynamischer Quest-Wegpunkt"] = "Dynamic quest waypoint",
  ["EP-Mob priorisiert · "] = "XP mob prioritized · ",
  ["%d Sek."] = "%d sec",
  ["%d:%02d Min."] = "%d:%02d min",
  ["FOREVERPATH · NAVIGATION"] = "FOREVERPATH · NAVIGATION",
  ["FOREVERPATH · NÄCHSTER SCHRITT"] = "FOREVERPATH · NEXT STEP",
  ["QUEST ANNEHMEN"] = "ACCEPT QUEST",
  ["QUEST ABGEBEN"] = "TURN IN QUEST",
  ["Gebiet: "] = "Zone: ",
  ["unbekannt"] = "unknown",
  ["abgeschlossen"] = "complete",
  ["Alle Schritte erledigt"] = "All steps complete",
  ["Beste Route: "] = "Best route: ",
  ["Noch %d Ziel%s offen · %d/%d"] = "%d objective%s remaining · %d/%d",
  ["Annehmen"] = "Accept",
  ["Abgabe öffnen"] = "Open turn-in",
  ["Questaktion"] = "Quest action",
  ["Sprache: Deutsch"] = "Language: German",
  ["Alpha %.0f%%"] = "Opacity %.0f%%",
  ["Schrift %.1fx"] = "Font %.1fx",
  ["Aktive Route"] = "Active route",
  ["Route abgeschlossen"] = "Route complete",
  ["Wähle einen anderen Modus oder setze den Fortschritt zurück."] = "Choose another mode or reset your progress.",
  ["Schritt"] = "Step",
  ["Gebiet"] = "Zone",
  ["Quelle"] = "Source",
  ["Quest-ID"] = "Quest ID",
  ["Phase"] = "Phase",
  ["Questkette: keine Zusatzdaten"] = "Quest chain: no supplemental data",
  ["Questkette: "] = "Quest chain: ",
  ["Zone: %s · Fortschritt %d/%d · Alternativen und Folgequests werden dynamisch bewertet"] = "Zone: %s · Progress %d/%d · Alternatives and follow-up quests are scored dynamically",
  ["Schritt %d/%d"] = "Step %d/%d",
  ["SCHNELLROUTE"] = "FAST ROUTE",
  ["Quest-Vorschau: %d XP (%d Quest%s) · Abgabe bereit: %d XP (%d fertig) · Vorschau %.0f%% · %s"] = "Quest preview: %d XP (%d quest%s) · Ready to turn in: %d XP (%d complete) · Preview %.0f%% · %s",
  ["noch offen"] = "still open",
  ["LEVEL UP READY!"] = "LEVEL UP READY!",
  ["TTG wird gemessen"] = "TTG is being measured",
  ["XP/h %.0f · %s · Reise %.1f Min."] = "XP/h %.0f · %s · Travel %.1f min",
  ["Questlog %d XP · %d Quest%s"] = "Quest log %d XP · %d quest%s",
  ["Layer: "] = "Layer: ",
  [" · Automatischer Wechsel nur über vorhandene ForeverGuild-Funktionen"] = " · Automatic switching only through available ForeverGuild functions",
  ["ForeverDB · Questlog · Livewerte"] = "ForeverDB · Quest log · Live values",
  ["Datenstand verfügbar"] = "Data version available",
  ["Zielmarker: "] = "Target marker: ",
  ["aktiv"] = "active",
  ["prüfen"] = "check",
  ["Fortschritt %d/%d"] = "Progress %d/%d",
  ["+ %d weitere Schritte – Tracker zeigt das aktuelle Ziel"] = "+ %d more steps – tracker shows the current target",
  ["Stufe %s · %s"] = "Level %s · %s",
  ["Gebiet: %s"] = "Zone: %s",
  ["Schnellste Solo-Vorschau · Stufe %d · %s · %d Questlog-Schritt%s"] = "Fastest solo preview · Level %d · %s · %d quest-log step%s",
  ["Aktiv: der Haupttracker priorisiert diese Solo-Bewertung."] = "Active: the main tracker prioritizes this solo score.",
  ["Vorschau: der Haupttracker bleibt ausgewogen, bis du den Schnellmodus aktivierst."] = "Preview: the main tracker stays balanced until fast mode is activated.",
  ["Schnellmodus deaktivieren"] = "Disable fast mode",
  ["Schnellmodus aktivieren"] = "Enable fast mode",
  ["Keine passende Soloquest gefunden"] = "No matching solo quest found",
  ["Questlog öffnen oder Datenstatus prüfen. Sobald verfügbare Quests erkannt werden, wird hier die Reihenfolge nachgerechnet."] = "Open the quest log or check data status. Once available quests are detected, the order is recalculated here.",
  ["Berechnete Solo-Route"] = "Calculated solo route",
  ["Wähle links einen Schritt."] = "Choose a step on the left.",
  ["Gear & Rewards"] = "Gear & Rewards",
  ["Itemdaten neu laden"] = "Reload item data",
  ["Der Vergleich wartet auf vollständig geladene Itemdaten und bleibt eine Stat-Heuristik."] = "The comparison waits for fully loaded item data and remains a stat heuristic.",
  ["Dungeon-Route"] = "Dungeon route",
  ["Klassenprofil"] = "Class profile",
  ["Pfeil folgt deiner Blickrichtung"] = "Arrow follows your facing",
  ["Sprache: Deutsch"] = "Language: German",
  ["Language: English"] = "Language: English",
  ["Deutsch"] = "German",
  ["English"] = "English",
  ["Sprache geändert: Deutsch"] = "Language changed: German",
  ["Sprache geändert: Englisch"] = "Language changed: English",
  ["Willkommen bei ForeverPath"] = "Welcome to ForeverPath",
  ["ForeverPath liest Questlog, Zone, Level und Spielereignisse automatisch.\n\nErkannt: %s · %s\n\nDer Tracker, Richtungspfeil und die Minimap-Route starten mit sicheren Standardpositionen. Datenstand:\n%s"] = "ForeverPath automatically reads your quest log, zone, level and game events.\n\nDetected: %s · %s\n\nThe tracker, direction arrow and minimap route start with safe default positions. Data status:\n%s",
  ["Klasse unbekannt"] = "Class unknown",
  ["Erste Route starten"] = "Start first route",
  ["Später"] = "Later",
}

function NS:L(key, ...)
  local language = self.db and self.db.ui and self.db.ui.language or "de"
  local text = language == "en" and EN[key] or key
  if select("#", ...) > 0 then
    local ok, formatted = pcall(string.format, text, ...)
    if ok then text = formatted end
  end
  return text
end

function NS:RefreshLocalizedWidgets()
  for _, entry in ipairs(self._localizedWidgets or {}) do
    if entry.widget and entry.widget.SetText then entry.widget:SetText(self:L(entry.key)) end
  end
  if self.tracker and self.tracker.title then self.tracker.title:SetText(self:L("FOREVERPATH · NÄCHSTER SCHRITT")) end
  if self.navigationFrame and self.navigationFrame.title then self.navigationFrame.title:SetText(self:L("FOREVERPATH · NAVIGATION")) end
  if self.navigationArrowFrame and self.navigationArrowFrame.title then self.navigationArrowFrame.title:SetText(self:L("FOREVERPATH · NAVIGATION")) end
end

function NS:GetModeLabel(mode)
  local labels = {speed="Solo / Quests", dungeon="Dungeon", discovery="Entdeckung", legacy="Legacy"}
  return self:L(labels[mode] or tostring(mode or ""))
end

function NS:SetLanguage(language)
  self:EnsureSettings()
  self.db.ui.language = language == "en" and "en" or "de"
  self:RefreshLocalizedWidgets()
  if self.Refresh then self:Refresh() end
  self:Print(self:L(self.db.ui.language == "en" and "Sprache geändert: Englisch" or "Sprache geändert: Deutsch"))
end

function NS:ToggleLanguage()
  self:EnsureSettings()
  self:SetLanguage(self.db.ui.language == "en" and "de" or "en")
end
