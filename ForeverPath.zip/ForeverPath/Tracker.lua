local NS = ForeverPath
local function tr(text) return NS.L and NS:L(text) or text end
local GOLD = {0.84, 0.66, 0.29}

local function trackerButton(parent, text, width)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetText(text); b:SetSize(width or 80, 22); return b
end

local function plainQuestTitle(value)
  if type(value) ~= "string" then return "" end
  return string.lower(value:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("%s+", " "):gsub("^%s*(.-)%s*$", "%1"))
end

function NS:SetAutoQuestActions(enabled)
  self:EnsureSettings(); self.db.ui.autoQuestActions = enabled ~= false; self:Refresh()
  self:Print(self.db.ui.autoQuestActions and tr("Auto-Quest: AN") or tr("Auto-Quest: AUS"))
end

function NS:TryAutoQuestAction(event)
  if not self.db or not self.db.ui or self.db.ui.autoQuestActions == false then return false end
  if event ~= "QUEST_DETAIL" and event ~= "QUEST_COMPLETE" and event ~= "QUEST_GREETING" and event ~= "GOSSIP_SHOW" then return false end
  local step = self.GetCurrentStep and self:GetCurrentStep()
  if not step or (step.phase ~= "accept" and step.phase ~= "turnin") then return false end

  -- Never touch an unrelated quest window. If the client exposes a title,
  -- require it to match the route quest; this is the safety gate for auto mode.
  local dialogTitle
  if type(GetTitleText) == "function" then pcall(function() dialogTitle = GetTitleText() end) end
  local expected = step.liveTitle or (step.record and step.record.title) or step.title
  if dialogTitle and dialogTitle ~= "" and expected and not string.find(plainQuestTitle(dialogTitle), plainQuestTitle(expected), 1, true) and not string.find(plainQuestTitle(expected), plainQuestTitle(dialogTitle), 1, true) then return false end

  local clicked = false
  if step.phase == "accept" and event == "QUEST_DETAIL" then
    if QuestFrameAcceptButton and QuestFrameAcceptButton:IsShown() and QuestFrameAcceptButton:IsEnabled() and QuestFrameAcceptButton.Click then
      clicked = pcall(QuestFrameAcceptButton.Click, QuestFrameAcceptButton)
    elseif type(AcceptQuest) == "function" then
      clicked = pcall(AcceptQuest)
    end
    if clicked then self:Print(tr("Quest automatisch angenommen: ") .. tostring(step.liveTitle or step.record and step.record.title or step.title)) end
  elseif step.phase == "turnin" and event == "QUEST_COMPLETE" then
    -- Clicking Complete opens the reward page. No reward button is ever
    -- selected automatically; the player still confirms the actual reward.
    if QuestFrameCompleteQuestButton and QuestFrameCompleteQuestButton:IsShown() and QuestFrameCompleteQuestButton:IsEnabled() and QuestFrameCompleteQuestButton.Click then
      clicked = pcall(QuestFrameCompleteQuestButton.Click, QuestFrameCompleteQuestButton)
    end
    if clicked then self:Print(tr("Abgabe geöffnet – Belohnung bitte manuell bestätigen.")) end
  end
  if clicked and C_Timer and C_Timer.After then C_Timer.After(0.25, function() if NS.AutoScan then NS:AutoScan(false) end end) end
  return clicked
end

function NS:CreateTracker()
  if self.tracker then return end
  local f = CreateFrame("Frame", "ForeverPathTracker", UIParent, "BackdropTemplate")
  f:SetSize(380, 380); f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
  f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=12, insets={left=3,right=3,top=3,bottom=3}})
  f:SetBackdropColor(0.035, 0.045, 0.07, 0.96); f:SetBackdropBorderColor(0.60, 0.44, 0.20, 1)
  local header = CreateFrame("Button", nil, f); header:SetPoint("TOPLEFT", 6, -6); header:SetPoint("TOPRIGHT", -6, -6); header:SetHeight(22); header:RegisterForDrag("LeftButton")
  header:SetScript("OnDragStart", function() if not (NS.db and NS.db.ui and NS.db.ui.lockFrames) then f:StartMoving() end end); header:SetScript("OnDragStop", function() f:StopMovingOrSizing(); NS:SaveFramePosition(f, "tracker") end)
  f.title = header:CreateFontString(nil, "OVERLAY", "GameFontNormal"); f.title:SetPoint("LEFT", 6, 0); f.title:SetTextColor(0.84, 0.66, 0.29); f.title:SetText(tr("FOREVERPATH · NÄCHSTER SCHRITT"))
  local collapse = trackerButton(f, "–", 22); collapse:SetPoint("TOPRIGHT", -34, -7); collapse:SetScript("OnClick", function() NS:ToggleTrackerCollapsed() end); f.collapse = collapse
  local close = trackerButton(f, "×", 22); close:SetPoint("TOPRIGHT", -8, -7); close:SetScript("OnClick", function() f:Hide() end)
  f.step = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.step:SetPoint("TOPLEFT", 14, -38); f.step:SetWidth(350); f.step:SetJustifyH("LEFT"); f.step:SetWordWrap(false)
  f.zone = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.zone:SetPoint("TOPLEFT", 14, -59); f.zone:SetWidth(350); f.zone:SetTextColor(0.60, 0.66, 0.76)
  f.body = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.body:SetPoint("TOPLEFT", 14, -78); f.body:SetWidth(350); f.body:SetHeight(25); f.body:SetJustifyH("LEFT"); f.body:SetWordWrap(false)
  f.objectiveRows = {}
  f.scrollFrame = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
  f.scrollFrame:SetPoint("TOPLEFT", 14, -104); f.scrollFrame:SetPoint("TOPRIGHT", -28, -104); f.scrollFrame:SetHeight(166)
  f.scrollChild = CreateFrame("Frame", nil, f.scrollFrame); f.scrollChild:SetWidth(350); f.scrollChild:SetHeight(1); f.scrollFrame:SetScrollChild(f.scrollChild)
  f.scrollFrame:EnableMouseWheel(true)
  f.scrollFrame:SetScript("OnMouseWheel", function(_, delta)
    local maxScroll=math.max(0,(f.scrollChild:GetHeight() or 1)-f.scrollFrame:GetHeight())
    local current=f.scrollFrame:GetVerticalScroll() or 0
    f.scrollFrame:SetVerticalScroll(math.max(0,math.min(maxScroll,current-delta*40)))
  end)
  f.questBar = CreateFrame("StatusBar", nil, f, "BackdropTemplate"); f.questBar:SetSize(350, 8); f.questBar:SetPoint("TOPLEFT", 14, -280); f.questBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); f.questBar:SetStatusBarColor(0.30, 0.62, 0.88, 1); f.questBar:SetMinMaxValues(0, 1)
  f.questProgress = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.questProgress:SetPoint("TOPLEFT", 14, -292); f.questProgress:SetWidth(350); f.questProgress:SetTextColor(0.48, 0.78, 0.60)
  f.progress = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.progress:SetPoint("BOTTOMLEFT", 14, 48); f.progress:SetWidth(350); f.progress:SetJustifyH("LEFT"); f.progress:SetWordWrap(false); f.progress:SetTextColor(0.48, 0.78, 0.60)
  f.session = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.session:SetPoint("BOTTOMLEFT", 14, 32); f.session:SetWidth(350); f.session:SetJustifyH("LEFT"); f.session:SetWordWrap(false); f.session:SetTextColor(0.55, 0.65, 0.78)
  local action = trackerButton(f, "Questaktion", 92); action:SetPoint("BOTTOMRIGHT", -270, 9); action:SetScript("OnClick", function()
    local step=NS:GetCurrentStep()
    if not step or not step.phase then return end
    if step.kind and step.kind ~= "quest" then
      NS:CompleteCurrent()
      return
    end
    local clicked=false
    if step.phase=="accept" then
      if QuestFrameAcceptButton and QuestFrameAcceptButton:IsShown() and QuestFrameAcceptButton.Click then QuestFrameAcceptButton:Click(); clicked=true
      elseif AcceptQuest then local ok=pcall(AcceptQuest); clicked=ok end
      if clicked then NS:Print("Quest angenommen: "..tostring(step.liveTitle or step.title)) else NS:Print("Öffne zuerst das Questfenster beim markierten NPC.") end
    elseif step.phase=="turnin" then
      if QuestFrameCompleteQuestButton and QuestFrameCompleteQuestButton:IsShown() and QuestFrameCompleteQuestButton.Click then QuestFrameCompleteQuestButton:Click(); clicked=true
      elseif CompleteQuest then local ok=pcall(CompleteQuest); clicked=ok end
      if clicked then NS:Print("Abgabe geöffnet – Belohnung im Questfenster auswählen.") else NS:Print("Öffne zuerst das Questfenster beim markierten NPC.") end
    end
    if clicked and C_Timer and C_Timer.After then C_Timer.After(0.2,function() NS:AutoScan(false) end) end
  end); f.action=action
  local recover = trackerButton(f, "Route sync", 82); recover:SetPoint("BOTTOMRIGHT", -168, 9); recover:SetScript("OnClick", function() if NS.ApplyRouteRecovery then NS:ApplyRouteRecovery() end end); f.recover = recover
  local waypoint = trackerButton(f, "Wegpunkt", 78); waypoint:SetPoint("BOTTOMRIGHT", -10, 9); waypoint:SetScript("OnClick", function() if not NS:SetBestWaypoint(NS:GetCurrentStep()) then NS:Print("Für diesen Schritt sind noch keine Zielkoordinaten erfasst.") end end)
  self.tracker = f; self:RestoreFramePosition(f, "tracker", "TOPRIGHT", Minimap, 0, -12); self:ApplyTrackerSettings(); self:RefreshTracker()
end

function NS:ApplyTrackerSettings()
  if not self.tracker or not self.db then return end
  self:EnsureSettings(); local ui = self.db.ui; local f = self.tracker
  f:SetScale((ui.trackerScale or 1) * (ui.fontScale or 1)); f:SetAlpha(ui.opacity or 0.96); f:SetHeight(ui.trackerCollapsed and 42 or 380); f:SetShown(f:IsShown())
  local collapsed = ui.trackerCollapsed == true
  f.zone:SetShown(not collapsed); f.body:SetShown(not collapsed); f.scrollFrame:SetShown(not collapsed); f.questBar:SetShown(not collapsed); f.questProgress:SetShown(not collapsed); f.progress:SetShown(not collapsed); f.session:SetShown(not collapsed); f.action:SetShown(not collapsed and f.action.available ~= false); f.recover:SetShown(not collapsed and f.recover.available ~= false)
  for _, row in ipairs(f.objectiveRows or {}) do row:SetShown(not collapsed and row.available == true) end
  f.collapse:SetText(collapsed and "+" or "–")
end

function NS:ToggleTrackerCollapsed()
  self:EnsureSettings(); self.db.ui.trackerCollapsed = not self.db.ui.trackerCollapsed; self:ApplyTrackerSettings(); self:RefreshTracker()
end

local function trackerRow(frame, index)
  local row = frame.objectiveRows[index]
  if row then return row end
  row = CreateFrame("Button", nil, frame.scrollChild or frame)
  row:SetSize(350, 19)
  row.text = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  row.text:SetPoint("LEFT", 2, 0); row.text:SetWidth(346); row.text:SetJustifyH("LEFT"); row.text:SetWordWrap(false)
  row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
  frame.objectiveRows[index] = row
  return row
end

function NS:RefreshTrackerObjectiveRows(step, tracked)
  local frame=self.tracker; if not frame then return end
  for _, row in ipairs(frame.objectiveRows or {}) do row.available=false; row:Hide() end
  local entries={}
  local quest=tracked and tracked.quest
  local planned=self.GetPlannedWaypoint and self:GetPlannedWaypoint(step) or self.GetBestWaypoint and self:GetBestWaypoint(step) or nil
  local record=step.record or {}
  local guide=step.authored or step.guide or {}
  local function locationText(point, fallback)
    point=point or {}
    local name=point.name or fallback or tr("Wegpunkt")
    local coords=(point.x and point.y) and string.format(" (%.1f / %.1f)",point.x,point.y) or ""
    return tr("Ort: ")..tostring(name)..coords
  end
  local function add(text, finished, questID)
    entries[#entries+1]={text=text,finished=finished==true,questID=questID or step.questID}
  end
  local questTitle=step.liveTitle or (record and record.title) or tr("Questziel")
  local giver=record.startPoint or (planned and planned.kind=="giver" and planned) or nil
  local turnin=record.turnInPoint or (planned and planned.kind=="turnin" and planned) or nil
  if step.kind=="trainer" then
    add(tr("Trainer besuchen: ")..tostring(guide.zone or tr("Klassenlehrer")),false)
    add(guide.instruction or tr("Trainerfenster öffnen und verfügbare Fähigkeiten prüfen."),false)
    add(tr("Lernen: ")..(self.GetAuthoredAbilities and self:GetAuthoredAbilities() or tr("Fähigkeiten werden beim Trainerfenster erfasst.")),false)
  elseif step.kind=="travel" or step.kind=="route" then
    add(guide.body or step.body or tr("Reise- und Versorgungsstopp"),false)
    add(tr("Gebiet: ")..tostring(step.zone or tr("unbekannt")),false)
  else
    if step.phase=="accept" then
      add(tr("Quest annehmen: ")..tostring(questTitle),false)
      add(tr("Sprich mit ")..tostring(giver and giver.name or tr("Questgeber")).." · "..locationText(giver,record.zone),false)
    end
    if quest and self.GetQuestObjectiveRows and step.phase=="objective" then
      for _, objective in ipairs(self:GetQuestObjectiveRows(quest)) do objective.questID=quest.id; entries[#entries+1]=objective end
    elseif step.phase=="objective" then
      add(tr("Ziele erledigen").." · "..tostring(questTitle),false)
    end
    if step.phase=="objective" and planned then
      add(tr("Zielgebiet: ")..locationText(planned,record.zone),false)
    end
    if step.phase=="turnin" then
      add(tr("Quest abgeben: ")..tostring(questTitle),true)
      add(tr("Sprich mit ")..tostring(turnin and turnin.name or tr("Abgabe-NPC")).." · "..locationText(turnin,record.zone),false)
    end
    if guide.instruction then add(guide.instruction,false) end
    if guide.items then add(tr("Items: ")..table.concat(guide.items,", "),false) end
  end
  if self.GetClassTrainingHint then
    local training=self:GetClassTrainingHint()
    if training then add(training,false) end
  end
  local nextQuest=(record.chainNext and record.chainNext[1])
  if nextQuest then
    local nextID=type(nextQuest)=="table" and (nextQuest.questID or nextQuest.id) or nextQuest
    local nextRecord=tonumber(nextID) and self.questDB and self.questDB[tonumber(nextID)] or nil
    local nextTitle=type(nextQuest)=="table" and (nextQuest.name or nextQuest.title) or (nextRecord and nextRecord.title) or nextID
    local nextPoint=nextRecord and nextRecord.startPoint
    add(tr("Folgequest annehmen: ")..tostring(nextTitle)..(nextPoint and (" · "..locationText(nextPoint,nextRecord.zone)) or ""),false)
  end
  -- Keep the current instructions first, then expose the upcoming route in
  -- the same scrollable tracker. This mirrors a guide list without hiding the
  -- live quest-log state behind a fixed five-line limit.
  local steps=self.GetSteps and self:GetSteps() or {}
  local currentIndex=self.db and self.db.step or 1
  if steps[currentIndex+1] then
    entries[#entries+1]={header=true,text=tr("Nächste Schritte")}
    for index=currentIndex+1,math.min(#steps,currentIndex+8) do
      local upcoming=steps[index]
      local title=upcoming.liveTitle or upcoming.title or tr("Questziel")
      local zone=upcoming.zone and (" · "..tostring(upcoming.zone)) or ""
      entries[#entries+1]={future=true,stepIndex=index,text=string.format("%s · %s%s",string.format(tr("Schritt %d"),index),tostring(title),zone)}
    end
  end
  if #entries==0 then entries[1]={text=step.title or "Questziel",finished=false,questID=step.questID} end
  frame.scrollChild:SetHeight(math.max(1,#entries*20+4))
  if frame.scrollFrame.UpdateScrollChildRect then frame.scrollFrame:UpdateScrollChildRect() end
  for index=1,#entries do
    local entry=entries[index]
    local row=trackerRow(frame,index); local done=entry.finished or (entry.required and entry.required>0 and entry.done>=entry.required)
    local mark=entry.header and "" or entry.future and "|cff70b6ed→|r" or (done and "|cff50d090✓|r" or "|cfff0c45c•|r")
    local progress=(entry.required and entry.required>0) and string.format(" (%d/%d)",entry.done or 0,entry.required) or ""
    row.text:SetText(mark.." "..tostring(entry.text or "Questziel")..progress); row.text:SetTextColor(entry.header and GOLD[1] or entry.future and 0.62 or 0.86,entry.header and GOLD[2] or entry.future and 0.76 or 0.88,entry.header and GOLD[3] or entry.future and 0.96 or 0.92); row.available=true; row:Show(); row:ClearAllPoints(); row:SetPoint("TOPLEFT",0,-(index-1)*20)
    row:SetScript("OnMouseUp",function(_,button)
      if entry.header then return
      elseif entry.future and entry.stepIndex then
        if NS.SelectStep then NS:SelectStep(entry.stepIndex) end
      elseif button=="RightButton" then
        if entry.questID then NS:SetFocusQuest(entry.questID) end
      elseif entry.questID then
        NS:OpenQuestLogFor(entry.questID, quest and quest.index)
      end
    end)
    row:SetScript("OnEnter",function()
      if not GameTooltip then return end
      GameTooltip:SetOwner(row,"ANCHOR_RIGHT"); GameTooltip:AddLine(entry.text or "Questziel",0.84,0.66,0.29)
      if entry.future then GameTooltip:AddLine(tr("Klicken: Schritt anzeigen"),0.55,0.78,0.62)
      elseif entry.questID then GameTooltip:AddLine("Quest-ID: "..tostring(entry.questID),0.78,0.80,0.86); GameTooltip:AddLine("Linksklick: Questlog · Rechtsklick: Fokus",0.55,0.78,0.62) end
      GameTooltip:Show()
    end)
    row:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
  end
end

function NS:SetTrackerScale(delta)
  self:EnsureSettings(); self.db.ui.trackerScale = math.max(0.75, math.min(1.35, (self.db.ui.trackerScale or 1) + delta)); self:ApplyTrackerSettings(); self:Print(string.format("Tracker-Skalierung: %.2fx", self.db.ui.trackerScale))
end

function NS:RefreshTracker()
  if not self.tracker or not self.db then return end
  self:ApplyTrackerSettings()
  local f, step, steps = self.tracker, self:GetCurrentStep(), self:GetSteps()
  if not step then f.step:SetText(tr("Route abgeschlossen")); f.zone:SetText(""); f.body:SetText(tr("Wähle im Menü eine andere Route oder setze den Fortschritt zurück.")); f.progress:SetText("100% " .. tr("abgeschlossen")); f.session:SetText(NS.GetSessionDetail and NS:GetSessionDetail() or (NS.GetSessionText and NS:GetSessionText() or "")); f.questBar:SetValue(1); f.questProgress:SetText(tr("Alle Schritte erledigt")); f.recover.available = false; f.action.available = false; self:ApplyTrackerSettings(); return end
  local advice = self.GetRecommendations and self:GetRecommendations(1)[1]
  f.step:SetText(string.format("%d/%d · Stufe %s · %s", self.db.step, #steps, step.level or "–", step.liveTitle or step.title))
  f.zone:SetText(tr("Gebiet: ") .. (step.zone or tr("unbekannt")))
  local objective = NS.GetTrackedObjective and NS:GetTrackedObjective(step) or nil
  local phase=step.kind=="trainer" and tr("TRAINER / FÄHIGKEITEN") or (step.kind=="travel" or step.kind=="route") and tr("REISESTOPP") or step.phase=="accept" and tr("QUEST ANNEHMEN") or step.phase=="turnin" and tr("QUEST ABGEBEN") or tr("Aktuelles Questziel")
  local body=(objective and objective.quest and objective.quest.title) or step.liveTitle or step.title or tr("Questziel")
  if step.kind and step.kind ~= "quest" and step.body then body=step.body end
  f.body:SetText(phase.." · "..body)
  self:RefreshTrackerObjectiveRows(step,objective)
  if objective and objective.required and objective.required > 0 then
    local done, required = objective.done or 0, objective.required or 1; f.questBar:SetMinMaxValues(0, required); f.questBar:SetValue(math.min(done, required)); local remaining = math.max(0, required - done)
    f.questProgress:SetText(remaining > 0 and string.format(tr("Noch %d Ziel%s offen · %d/%d"), remaining, remaining == 1 and "" or "s", done, required) or tr("Quest kann abgegeben werden"))
  else
    f.questBar:SetMinMaxValues(0, 1); f.questBar:SetValue(0); f.questProgress:SetText(tr("Questziel wird automatisch aus dem Client gelesen"))
  end
  local distance = NS.GetWaypointDistance and NS:GetWaypointDistance(step)
  f.progress:SetText(string.format("Fortschritt: %d/%d · Score: %s%s", math.max(0, self.db.step-1), #steps, advice and string.format("%.0f", advice.score) or "–", distance and (" · " .. distance) or ""))
  local sessionText=NS.GetSessionDetail and NS:GetSessionDetail() or (NS.GetSessionText and NS:GetSessionText() or ""); f.session:SetText(tostring(sessionText):gsub("\n"," · "))
  f.action.available = step.kind and step.kind ~= "quest" or step.phase=="accept" or step.phase=="turnin"; f.action:SetText(step.kind=="trainer" and tr("Trainer erledigt") or (step.kind=="travel" or step.kind=="route") and tr("Stopp erledigt") or step.phase=="accept" and tr("Annehmen") or step.phase=="turnin" and tr("Abgabe öffnen") or tr("Questaktion"))
  local recovery = NS.GetRouteRecovery and NS:GetRouteRecovery() or nil; f.recover.available = recovery ~= nil; f.recover:SetShown(not self.db.ui.trackerCollapsed and recovery ~= nil); self:ApplyTrackerSettings()
end
