local NS = ForeverPath

local function trackerButton(parent, text, width)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetText(text); b:SetSize(width or 80, 22); return b
end

function NS:CreateTracker()
  if self.tracker then return end
  local f = CreateFrame("Frame", "ForeverPathTracker", UIParent, "BackdropTemplate")
  f:SetSize(310, 184); f:SetPoint("TOPRIGHT", Minimap, "BOTTOMRIGHT", 0, -12); f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
  f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=12, insets={left=3,right=3,top=3,bottom=3}})
  f:SetBackdropColor(0.035, 0.045, 0.07, 0.96); f:SetBackdropBorderColor(0.60, 0.44, 0.20, 1)
  local header = CreateFrame("Button", nil, f); header:SetPoint("TOPLEFT", 6, -6); header:SetPoint("TOPRIGHT", -6, -6); header:SetHeight(22); header:RegisterForDrag("LeftButton")
  header:SetScript("OnDragStart", function() f:StartMoving() end); header:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)
  f.title = header:CreateFontString(nil, "OVERLAY", "GameFontNormal"); f.title:SetPoint("LEFT", 6, 0); f.title:SetTextColor(0.84, 0.66, 0.29); f.title:SetText("FOREVERPATH · NÄCHSTER SCHRITT")
  local close = trackerButton(f, "×", 22); close:SetPoint("TOPRIGHT", -8, -7); close:SetScript("OnClick", function() f:Hide() end)
  f.step = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.step:SetPoint("TOPLEFT", 14, -38); f.step:SetWidth(280); f.step:SetJustifyH("LEFT")
  f.zone = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.zone:SetPoint("TOPLEFT", 14, -59); f.zone:SetTextColor(0.60, 0.66, 0.76)
  f.body = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.body:SetPoint("TOPLEFT", 14, -78); f.body:SetWidth(280); f.body:SetHeight(50); f.body:SetJustifyH("LEFT"); f.body:SetWordWrap(true)
  f.progress = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.progress:SetPoint("BOTTOMLEFT", 14, 31); f.progress:SetWidth(180); f.progress:SetTextColor(0.48, 0.78, 0.60)
  f.session = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.session:SetPoint("BOTTOMLEFT", 14, 13); f.session:SetWidth(180); f.session:SetTextColor(0.55, 0.65, 0.78)
  local recover = trackerButton(f, "Route sync", 82); recover:SetPoint("BOTTOMRIGHT", -94, 9); recover:SetScript("OnClick", function() if NS.ApplyRouteRecovery then NS:ApplyRouteRecovery() end end); f.recover = recover
  local waypoint = trackerButton(f, "Wegpunkt", 78); waypoint:SetPoint("BOTTOMRIGHT", -10, 9); waypoint:SetScript("OnClick", function() if not NS:SetBestWaypoint(NS:GetCurrentStep()) then NS:Print("Für diesen Schritt sind noch keine Zielkoordinaten erfasst.") end end)
  self.tracker = f; self:RefreshTracker()
end

function NS:RefreshTracker()
  if not self.tracker or not self.db then return end
  local f, step, steps = self.tracker, self:GetCurrentStep(), self:GetSteps()
  if not step then f.step:SetText("Route abgeschlossen"); f.zone:SetText(""); f.body:SetText("Wähle im Menü eine andere Route oder setze den Fortschritt zurück."); f.progress:SetText("100% abgeschlossen"); f.session:SetText(NS.GetSessionText and NS:GetSessionText() or ""); f.recover:Hide(); return end
  local advice = self.GetRecommendations and self:GetRecommendations(1)[1]
  f.step:SetText(string.format("%d/%d · Stufe %s · %s", self.db.step, #steps, step.level or "–", step.title))
  f.zone:SetText("Gebiet: " .. (step.zone or "unbekannt"))
  local body = NS.GetQuestTrackerText and NS:GetQuestTrackerText(step) or step.body or ""
  if advice and advice.step then body = body .. "\n\nBeste Route: " .. advice.step.title end
  f.body:SetText(body)
  local distance = NS.GetWaypointDistance and NS:GetWaypointDistance(step)
  f.progress:SetText(string.format("Fortschritt: %d/%d · Score: %s%s", math.max(0, self.db.step-1), #steps, advice and string.format("%.0f", advice.score) or "–", distance and (" · " .. distance) or ""))
  f.session:SetText(NS.GetSessionText and NS:GetSessionText() or "")
  f.recover:SetShown(NS.GetRouteRecovery and NS:GetRouteRecovery() ~= nil)
end
