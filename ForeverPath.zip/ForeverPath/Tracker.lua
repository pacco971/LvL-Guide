local NS = ForeverPath
local function tr(text) return NS.L and NS:L(text) or text end

local function trackerButton(parent, text, width)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetText(text); b:SetSize(width or 80, 22); return b
end

function NS:CreateTracker()
  if self.tracker then return end
  local f = CreateFrame("Frame", "ForeverPathTracker", UIParent, "BackdropTemplate")
  f:SetSize(330, 238); f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
  f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=12, insets={left=3,right=3,top=3,bottom=3}})
  f:SetBackdropColor(0.035, 0.045, 0.07, 0.96); f:SetBackdropBorderColor(0.60, 0.44, 0.20, 1)
  local header = CreateFrame("Button", nil, f); header:SetPoint("TOPLEFT", 6, -6); header:SetPoint("TOPRIGHT", -6, -6); header:SetHeight(22); header:RegisterForDrag("LeftButton")
  header:SetScript("OnDragStart", function() if not (NS.db and NS.db.ui and NS.db.ui.lockFrames) then f:StartMoving() end end); header:SetScript("OnDragStop", function() f:StopMovingOrSizing(); NS:SaveFramePosition(f, "tracker") end)
  f.title = header:CreateFontString(nil, "OVERLAY", "GameFontNormal"); f.title:SetPoint("LEFT", 6, 0); f.title:SetTextColor(0.84, 0.66, 0.29); f.title:SetText(tr("FOREVERPATH · NÄCHSTER SCHRITT"))
  local collapse = trackerButton(f, "–", 22); collapse:SetPoint("TOPRIGHT", -34, -7); collapse:SetScript("OnClick", function() NS:ToggleTrackerCollapsed() end); f.collapse = collapse
  local close = trackerButton(f, "×", 22); close:SetPoint("TOPRIGHT", -8, -7); close:SetScript("OnClick", function() f:Hide() end)
  f.step = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.step:SetPoint("TOPLEFT", 14, -38); f.step:SetWidth(300); f.step:SetJustifyH("LEFT"); f.step:SetWordWrap(false)
  f.zone = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.zone:SetPoint("TOPLEFT", 14, -59); f.zone:SetWidth(300); f.zone:SetTextColor(0.60, 0.66, 0.76)
  f.body = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.body:SetPoint("TOPLEFT", 14, -78); f.body:SetWidth(300); f.body:SetHeight(68); f.body:SetJustifyH("LEFT"); f.body:SetWordWrap(true)
  f.questBar = CreateFrame("StatusBar", nil, f, "BackdropTemplate"); f.questBar:SetSize(300, 8); f.questBar:SetPoint("TOPLEFT", 14, -153); f.questBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); f.questBar:SetStatusBarColor(0.30, 0.62, 0.88, 1); f.questBar:SetMinMaxValues(0, 1)
  f.questProgress = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.questProgress:SetPoint("TOPLEFT", 14, -165); f.questProgress:SetWidth(300); f.questProgress:SetTextColor(0.48, 0.78, 0.60)
  f.progress = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.progress:SetPoint("BOTTOMLEFT", 14, 42); f.progress:SetWidth(300); f.progress:SetJustifyH("LEFT"); f.progress:SetWordWrap(false); f.progress:SetTextColor(0.48, 0.78, 0.60)
  f.session = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.session:SetPoint("BOTTOMLEFT", 14, 25); f.session:SetWidth(300); f.session:SetJustifyH("LEFT"); f.session:SetWordWrap(false); f.session:SetTextColor(0.55, 0.65, 0.78)
  local action = trackerButton(f, "Questaktion", 92); action:SetPoint("BOTTOMRIGHT", -198, 9); action:SetScript("OnClick", function()
    local step=NS:GetCurrentStep()
    if not step or not step.phase then return end
    local clicked=false
    if step.phase=="accept" then
      if QuestFrameAcceptButton and QuestFrameAcceptButton:IsShown() and QuestFrameAcceptButton.Click then QuestFrameAcceptButton:Click(); clicked=true
      elseif AcceptQuest then local ok=pcall(AcceptQuest); clicked=ok end
      if clicked then NS:Print("Quest angenommen: "..tostring(step.liveTitle or step.title)) else NS:Print("Öffne zuerst das Questfenster beim markierten NPC.") end
    elseif step.phase=="turnin" then
      if QuestFrameCompleteQuestButton and QuestFrameCompleteQuestButton:IsShown() and QuestFrameCompleteQuestButton.Click then QuestFrameCompleteQuestButton:Click(); clicked=true
      elseif CompleteQuest then local ok=pcall(CompleteQuest); clicked=ok end
      if clicked then NS:Print("Abgabe geöffnet – Belohnung im Questfenster auswählen.") else NS:Print("Öffne zuerst das Questfenster beim markierten NPC.") end
    end
    if clicked and C_Timer and C_Timer.After then C_Timer.After(0.2,function() NS:AutoScan(false) end) end
  end); f.action=action
  local recover = trackerButton(f, "Route sync", 82); recover:SetPoint("BOTTOMRIGHT", -94, 9); recover:SetScript("OnClick", function() if NS.ApplyRouteRecovery then NS:ApplyRouteRecovery() end end); f.recover = recover
  local waypoint = trackerButton(f, "Wegpunkt", 78); waypoint:SetPoint("BOTTOMRIGHT", -10, 9); waypoint:SetScript("OnClick", function() if not NS:SetBestWaypoint(NS:GetCurrentStep()) then NS:Print("Für diesen Schritt sind noch keine Zielkoordinaten erfasst.") end end)
  self.tracker = f; self:RestoreFramePosition(f, "tracker", "TOPRIGHT", Minimap, 0, -12); self:ApplyTrackerSettings(); self:RefreshTracker()
end

function NS:ApplyTrackerSettings()
  if not self.tracker or not self.db then return end
  self:EnsureSettings(); local ui = self.db.ui; local f = self.tracker
  f:SetScale((ui.trackerScale or 1) * (ui.fontScale or 1)); f:SetAlpha(ui.opacity or 0.96); f:SetHeight(ui.trackerCollapsed and 42 or 238); f:SetShown(f:IsShown())
  local collapsed = ui.trackerCollapsed == true
  f.zone:SetShown(not collapsed); f.body:SetShown(not collapsed); f.questBar:SetShown(not collapsed); f.questProgress:SetShown(not collapsed); f.progress:SetShown(not collapsed); f.session:SetShown(not collapsed); f.action:SetShown(not collapsed and f.action.available ~= false); f.recover:SetShown(not collapsed and f.recover.available ~= false)
  f.collapse:SetText(collapsed and "+" or "–")
end

function NS:ToggleTrackerCollapsed()
  self:EnsureSettings(); self.db.ui.trackerCollapsed = not self.db.ui.trackerCollapsed; self:ApplyTrackerSettings(); self:RefreshTracker()
end

function NS:SetTrackerScale(delta)
  self:EnsureSettings(); self.db.ui.trackerScale = math.max(0.75, math.min(1.35, (self.db.ui.trackerScale or 1) + delta)); self:ApplyTrackerSettings(); self:Print(string.format("Tracker-Skalierung: %.2fx", self.db.ui.trackerScale))
end

function NS:RefreshTracker()
  if not self.tracker or not self.db then return end
  self:ApplyTrackerSettings()
  local f, step, steps = self.tracker, self:GetCurrentStep(), self:GetSteps()
  if not step then f.step:SetText(tr("Route abgeschlossen")); f.zone:SetText(""); f.body:SetText(tr("Wähle im Menü eine andere Route oder setze den Fortschritt zurück.")); f.progress:SetText("100% " .. tr("abgeschlossen")); f.session:SetText(NS.GetSessionDetail and NS:GetSessionDetail() or (NS.GetSessionText and NS:GetSessionText() or "")); f.questBar:SetValue(1); f.questProgress:SetText(tr("Alle Schritte erledigt")); f.recover.available = false; f.action.available = false; self:ApplyTrackerSettings(); return end
  local advice = self.GetRecommendations and self:GetRecommendations(1)[1]
  f.step:SetText(string.format("%d/%d · Stufe %s · %s", self.db.step, #steps, step.level or "–", step.title))
  f.zone:SetText(tr("Gebiet: ") .. (step.zone or tr("unbekannt")))
  local objective = NS.GetTrackedObjective and NS:GetTrackedObjective(step) or nil
  local body = NS.GetQuestTrackerText and NS:GetQuestTrackerText(step) or step.body or ""
  if step.phase=="accept" then body=tr("QUEST ANNEHMEN").."\n"..body elseif step.phase=="turnin" then body=tr("QUEST ABGEBEN").."\n"..body end
  if self.db.ui.minimal then body = objective and objective.text or step.title end
  if advice and advice.step then body = body .. "\n\n" .. tr("Beste Route: ") .. advice.step.title end
  f.body:SetText(body)
  if objective and objective.required and objective.required > 0 then
    local done, required = objective.done or 0, objective.required or 1; f.questBar:SetMinMaxValues(0, required); f.questBar:SetValue(math.min(done, required)); local remaining = math.max(0, required - done)
    f.questProgress:SetText(remaining > 0 and string.format(tr("Noch %d Ziel%s offen · %d/%d"), remaining, remaining == 1 and "" or "s", done, required) or tr("Quest kann abgegeben werden"))
  else
    f.questBar:SetMinMaxValues(0, 1); f.questBar:SetValue(0); f.questProgress:SetText(tr("Questziel wird automatisch aus dem Client gelesen"))
  end
  local distance = NS.GetWaypointDistance and NS:GetWaypointDistance(step)
  f.progress:SetText(string.format("Fortschritt: %d/%d · Score: %s%s", math.max(0, self.db.step-1), #steps, advice and string.format("%.0f", advice.score) or "–", distance and (" · " .. distance) or ""))
  local sessionText=NS.GetSessionDetail and NS:GetSessionDetail() or (NS.GetSessionText and NS:GetSessionText() or ""); f.session:SetText(tostring(sessionText):gsub("\n"," · "))
  f.action.available = step.phase=="accept" or step.phase=="turnin"; f.action:SetText(step.phase=="accept" and tr("Annehmen") or step.phase=="turnin" and tr("Abgabe öffnen") or tr("Questaktion"))
  local recovery = NS.GetRouteRecovery and NS:GetRouteRecovery() or nil; f.recover.available = recovery ~= nil; f.recover:SetShown(not self.db.ui.trackerCollapsed and recovery ~= nil); self:ApplyTrackerSettings()
end
