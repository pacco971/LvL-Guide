local NS = ForeverPath

-- A detailed, clean-room presentation layer.  It combines the player's live
-- quest log with the locally imported ForeverDB giver/turn-in/chain records;
-- it does not copy a third-party route or guide text.
local function tr(text) return NS.L and NS:L(text) or text end

local function pointText(point, fallback)
  point = point or {}
  local name = point.name or fallback or tr("Wegpunkt")
  if point.x and point.y then
    return string.format("%s (%.1f / %.1f)", tostring(name), point.x, point.y)
  end
  return tostring(name)
end

local function objectiveText(objective)
  local done = tonumber(objective.numFulfilled or objective.fulfilled or 0) or 0
  local required = tonumber(objective.numRequired or objective.required or 0) or 0
  local progress = required > 0 and string.format(" (%d/%d)", done, required) or ""
  local marker = (objective.finished or (required > 0 and done >= required)) and "OK " or "- "
  return marker .. tostring(objective.text or tr("Questziel")) .. progress
end

local function nextQuestText(self, record)
  local nextQuest = record and record.chainNext and record.chainNext[1]
  if not nextQuest then return nil end
  local nextID = type(nextQuest) == "table" and (nextQuest.questID or nextQuest.id) or nextQuest
  local nextRecord = tonumber(nextID) and self.questDB and self.questDB[tonumber(nextID)] or nil
  local title = type(nextQuest) == "table" and (nextQuest.name or nextQuest.title) or (nextRecord and nextRecord.title) or nextID
  local giver = nextRecord and nextRecord.startPoint
  return tr("Folgequest annehmen: ") .. tostring(title) .. (giver and (" · " .. pointText(giver, nextRecord.zone)) or "")
end

function NS:GetDetailedStepLines(step)
  if not step then return {tr("Kein aktiver Guide-Schritt.")} end
  local lines = {}
  local record = step.record or (step.questID and self.questDB and self.questDB[step.questID]) or {}
  local live = step.questID and self.GetLiveQuest and self:GetLiveQuest(step.questID) or nil
  local title = step.liveTitle or (live and live.title) or record.title or step.title or tr("Guide-Schritt")

  if step.kind == "trainer" then
    lines[#lines + 1] = tr("1. Klassenlehrer besuchen: ") .. tostring(step.zone or tr("aktuelles Gebiet"))
    lines[#lines + 1] = tr("2. Trainerfenster öffnen und verfügbare Fähigkeiten prüfen.")
    lines[#lines + 1] = tr("3. Lernen: ") .. tostring(self.GetAuthoredAbilities and self:GetAuthoredAbilities() or tr("Fähigkeiten werden beim Trainerfenster erfasst."))
    return lines
  end
  if step.kind == "travel" or step.kind == "route" then
    lines[#lines + 1] = tostring(step.body or step.instruction or step.title or tr("Routenstopp"))
    if step.zone then lines[#lines + 1] = tr("Gebiet: ") .. tostring(step.zone) end
    local plan = self.GetTravelPlan and self:GetTravelPlan(step)
    if plan and plan.best then lines[#lines + 1] = tr("Reise: ") .. tostring(plan.best.name) end
    return lines
  end

  local start = record.startPoint
  local turnIn = record.turnInPoint
  if step.phase == "accept" then
    lines[#lines + 1] = tr("1. Quest annehmen: ") .. tostring(title)
    lines[#lines + 1] = tr("2. Sprich mit ") .. pointText(start, tr("Questgeber"))
    lines[#lines + 1] = tr("3. Ziele aus dem Questlog verfolgen und erst danach weiterreisen.")
  elseif step.phase == "objective" then
    lines[#lines + 1] = tr("1. Questziel: ") .. tostring(title)
    local rows = live and self.GetQuestObjectiveRows and self:GetQuestObjectiveRows(live) or {}
    if #rows > 0 then
      for _, objective in ipairs(rows) do lines[#lines + 1] = objectiveText(objective) end
    else
      lines[#lines + 1] = tr("Ziele aus dem Questlog werden automatisch gelesen.")
    end
    local point = self.GetBestWaypoint and self:GetBestWaypoint(step)
    if point then lines[#lines + 1] = tr("Zielgebiet: ") .. pointText(point, record.zone) end
    lines[#lines + 1] = tr("Danach zur Abgabe zurückkehren: ") .. pointText(turnIn, tr("Abgabe-NPC wird aus den Daten ermittelt"))
  elseif step.phase == "turnin" then
    lines[#lines + 1] = tr("1. Quest abgeben: ") .. tostring(title)
    lines[#lines + 1] = tr("2. Sprich mit ") .. pointText(turnIn or start, tr("Abgabe-NPC"))
    lines[#lines + 1] = tr("3. Belohnung im Questfenster selbst auswählen und bestätigen.")
  else
    lines[#lines + 1] = tostring(step.body or step.instruction or title)
  end
  local followUp = nextQuestText(self, record)
  if followUp then lines[#lines + 1] = followUp end
  local reputation = self.GetQuestReputationText and step.questID and self:GetQuestReputationText(step.questID)
  if reputation then lines[#lines + 1] = tr("Rufbelohnung: ") .. reputation end
  lines[#lines + 1] = tr("Quelle: ") .. (record.foreverDB and "ForeverDB / Live-Questlog" or "Live-Questlog / lokale Daten")
  return lines
end

function NS:GetDetailedStepText(step)
  return table.concat(self:GetDetailedStepLines(step), "\n")
end

-- Compact, information-dense preview used by the in-game guide lists.  The
-- full text remains available in the detail panel; this preview keeps the
-- familiar "action + explanation" rhythm without copying another addon's UI.
function NS:GetGuidePreviewText(step, limit)
  limit = tonumber(limit) or 2
  local source = self:GetDetailedStepLines(step)
  local lines = {}
  for _, line in ipairs(source or {}) do
    line = tostring(line or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if line ~= "" and not line:match("^Quelle:%s*") and not line:match("^Source:%s*") then
      local icon = self.GetGuideIcon and self:GetGuideIcon(step) or "Interface\\Icons\\INV_Misc_Note_01"
      lines[#lines + 1] = string.format("|T%s:13:13:0:0|t %s", icon, line)
      if #lines >= limit then break end
    end
  end
  if #lines == 0 then
    lines[1] = tostring(step and (step.body or step.instruction or step.title) or tr("Nächster Schritt"))
  end
  return table.concat(lines, "\n")
end

function NS:GetGuidePointTooltipLines(step)
  local lines = self:GetDetailedStepLines(step)
  local out = {}
  for _, line in ipairs(lines or {}) do
    line = tostring(line or "")
    if line ~= "" and not line:match("^Quelle:%s*") and not line:match("^Source:%s*") then out[#out + 1] = line end
  end
  return out
end

function NS:GetTrackerSummary(step)
  local lines = self:GetDetailedStepLines(step)
  if #lines > 2 then return lines[1] .. "\n" .. lines[2] end
  return lines[1] or tr("Nächster Schritt")
end

local oldTrackerText = NS.GetQuestTrackerText
function NS:GetQuestTrackerText(step)
  if step and (step.phase or step.kind == "trainer" or step.kind == "travel" or step.kind == "route") then
    return self:GetDetailedStepText(step)
  end
  return oldTrackerText and oldTrackerText(self, step) or tr("Keine Questdetails im aktuellen Client gefunden.")
end

