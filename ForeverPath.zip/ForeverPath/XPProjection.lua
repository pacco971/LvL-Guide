local NS = ForeverPath

-- XP-Projektion und Buff-Erkennung. Alle APIs sind defensiv gekapselt, weil
-- WoW-Forever je nach Client-Build unterschiedliche Classic-APIs anbietet.
local function number(value)
  if type(value) ~= "number" then return nil end
  if issecretvalue then
    local ok, secret = pcall(issecretvalue, value)
    if ok and secret then return nil end
  end
  return value
end

local function safeCall(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, value = pcall(fn, ...)
  return ok and value or nil
end

local function safeQuestLogSelect(entry)
  if not entry then return false end
  if C_QuestLog and C_QuestLog.SetSelectedQuest and entry.id then
    local ok = pcall(C_QuestLog.SetSelectedQuest, entry.id)
    if ok then return true end
  end
  if SelectQuestLogEntry and entry.index then
    local ok = pcall(SelectQuestLogEntry, entry.index)
    if ok then return true end
  end
  return false
end

local function plainText(value)
  if type(value) ~= "string" then return "" end
  return string.lower(value:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end

function NS:GetXPState()
  local current = number(safeCall(UnitXP, "player")) or 0
  local maximum = number(safeCall(UnitXPMax, "player")) or 0
  local level = number(safeCall(UnitLevel, "player")) or 1
  return { current=current, maximum=maximum, level=level, remaining=math.max(0, maximum-current) }
end

function NS:GetXPMultipliers()
  local rested = number(safeCall(GetXPExhaustion, "player")) or number(safeCall(GetXPExhaustion)) or 0
  local result = { restedXP=math.max(0, rested), kill=1, quest=1, labels={} }
  if rested > 0 then result.labels[#result.labels+1] = "Erholt" end

  local function inspectAura(name, description)
    local text = plainText((name or "") .. " " .. (description or ""))
    if not string.find(text, "xp", 1, true) and not string.find(text, "experience", 1, true)
      and not string.find(text, "erfahrung", 1, true) then return end
    local percent = tonumber(string.match(text, "(%d+)%s*%%"))
    if percent and percent > 0 and percent < 500 then
      result.kill = result.kill * (1 + percent / 100)
      result.quest = result.quest * (1 + percent / 100)
      result.labels[#result.labels+1] = (name or "Event") .. " +" .. percent .. "%"
    else
      result.labels[#result.labels+1] = name or "XP-Event"
    end
  end

  if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
    for index=1,40 do
      local aura = safeCall(C_UnitAuras.GetAuraDataByIndex, "player", index, "HELPFUL")
      if not aura then break end
      -- Aura fields may be protected on some Forever builds.  Keep the
      -- optional multiplier scan isolated so it can never stop the route UI.
      pcall(function() inspectAura(aura.name, aura.description) end)
    end
  elseif UnitAura then
    for index=1,40 do
      local ok, name = pcall(UnitAura, "player", index, "HELPFUL")
      if not ok then break end
      if not name then break end
      pcall(function() inspectAura(name, "") end)
    end
  end
  return result
end

local function tooltipLines(tooltip)
  local lines = {}
  if not tooltip or not tooltip.GetName then return lines end
  local name = tooltip:GetName()
  for index=1,tooltip:NumLines() do
    local left = _G[name .. "TextLeft" .. index]
    local right = _G[name .. "TextRight" .. index]
    if left and left.GetText then lines[#lines+1] = left:GetText() or "" end
    if right and right.GetText then lines[#lines+1] = right:GetText() or "" end
  end
  return lines
end

local function parseXP(text)
  text = tostring(text or "")
  local clean = text:gsub(",", ""):gsub("%.", "")
  local value = string.match(clean, "(%d+)%s*[xX][pP]")
    or string.match(clean, "[eE]xperience[^%d]*(%d+)")
    or string.match(clean, "[eE]rfahrung[^%d]*(%d+)")
    or string.match(clean, "[xX][pP][^%d]*(%d+)")
    or string.match(clean, "(%d+)%s*[eE]rfahrung")
    or string.match(clean, "(%d+)%s*[eE]xperience")
  return tonumber(value)
end

function NS:ScanQuestRewardTooltip(questID, index)
  if not GameTooltip then return 0 end
  local tooltip = GameTooltip
  local owner = UIParent or tooltip
  local visible = safeCall(tooltip.IsShown, tooltip) == true
  pcall(tooltip.SetOwner, tooltip, owner, "ANCHOR_NONE")
  local shown = false
  if questID and tooltip.SetHyperlink then
    shown = pcall(tooltip.SetHyperlink, tooltip, "quest:" .. tostring(questID))
  end
  if not shown and tooltip.SetQuestLogItem and index then
    shown = pcall(tooltip.SetQuestLogItem, tooltip, "reward", index)
  end
  local xp = 0
  if shown then
    local ok, lines = pcall(tooltipLines, tooltip)
    if ok and lines then for _, line in ipairs(lines) do xp = parseXP(line) or xp end end
  end
  pcall(tooltip.Hide, tooltip)
  if visible then pcall(tooltip.Show, tooltip) end
  return xp or 0
end

function NS:GetQuestRewardXP(questID, index, entry)
  local value
  safeQuestLogSelect(entry or {id=questID,index=index})
  if C_QuestLog and C_QuestLog.GetQuestRewardXP and questID then
    value = number(safeCall(C_QuestLog.GetQuestRewardXP, questID))
  end
  if not value and GetQuestLogRewardXP then
    value = number(safeCall(GetQuestLogRewardXP))
  end
  if value and value > 0 then return value, "API" end
  local fallback = self:ScanQuestRewardTooltip(questID, index)
  if fallback and fallback > 0 then return fallback, "Tooltip" end
  return 0, "unbekannt"
end

local function questLogEntries()
  local entries = {}
  if C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo then
    local count = number(safeCall(C_QuestLog.GetNumQuestLogEntries)) or 0
    for index=1,count do
      local info = safeCall(C_QuestLog.GetInfo, index)
      local questID = info and number(info.questID)
      if info and not info.isHeader and questID and questID > 0 then
        entries[#entries+1] = {index=index, id=questID, complete=info.isComplete == true or info.isComplete == 1}
      end
    end
  end
  -- Some Forever builds expose the modern namespace but return no usable
  -- quest entries.  Always try the legacy API as a fallback in that case.
  if #entries == 0 and GetNumQuestLogEntries and GetQuestLogTitle then
    local count = number(safeCall(GetNumQuestLogEntries)) or 0
    for index=1,count do
      local ok, _, _, _, _, isHeader, _, complete, _, questID = pcall(GetQuestLogTitle, index)
      questID = number(questID)
      if ok and questID and questID > 0 and not isHeader then
        entries[#entries+1] = {index=index, id=questID, complete=complete == true or complete == 1}
      end
    end
  end
  return entries
end

function NS:ScanQuestLogXP()
  local completedTotal, completedCount = 0, 0
  local allTotal, allCount = 0, 0
  local reliable = true
  for _, entry in ipairs(questLogEntries()) do
    local value, source = self:GetQuestRewardXP(entry.id, entry.index, entry)
    if value and value > 0 then
      allTotal = allTotal + value
      allCount = allCount + 1
      if entry.complete then
        completedTotal = completedTotal + value
        completedCount = completedCount + 1
      end
    else
      reliable = false
    end
    if source == "Tooltip" then reliable = false end
  end
  return completedTotal, completedCount, reliable, allTotal, allCount
end

function NS:GetQuestLogProjection()
  local state = self:GetXPState()
  local questXP, questCount, reliable, questLogXP, questLogCount = self:ScanQuestLogXP()
  local multipliers = self:GetXPMultipliers()
  local projected = math.min(state.maximum, state.current + questXP)
  local questLogProjected = math.min(state.maximum, state.current + (questLogXP or 0))
  local rate, timeToLevel
  if self.GetSessionStats then
    local ok, stats = pcall(self.GetSessionStats, self)
    if ok and type(stats) == "table" then
      rate = number(stats.movingXPPerHour) or number(stats.xpPerHour) or 0
      timeToLevel = number(stats.ttg)
    end
  end
  if not timeToLevel and rate and rate > 0 and state.remaining > 0 then
    timeToLevel = state.remaining / rate * 3600
  end
  return {
    currentXP=state.current, maximumXP=state.maximum, remaining=state.remaining,
    completedQuestXP=questXP, questCount=questCount,
    questLogXP=questLogXP, questLogCount=questLogCount,
    projectedXP=projected,
    questLogProjectedXP=questLogProjected,
    projectedPercent=state.maximum > 0 and projected / state.maximum or 0,
    questLogProjectedPercent=state.maximum > 0 and questLogProjected / state.maximum or 0,
    currentPercent=state.maximum > 0 and state.current / state.maximum or 0,
    ready=questXP >= state.remaining and state.remaining > 0,
    xpPerHour=rate or 0, timeToLevel=timeToLevel,
    reliable=reliable, multipliers=multipliers,
  }
end

local function barParent()
  return _G.MainStatusTrackingBarContainer or _G.MainMenuExpBar or UIParent
end

local function formatDuration(seconds)
  seconds = number(seconds)
  if not seconds or seconds <= 0 then return "wird gemessen" end
  if seconds < 60 then return string.format("%d Sek.", math.floor(seconds)) end
  return string.format("%d:%02d Min.", math.floor(seconds / 60), math.floor(seconds % 60))
end

function NS:CreateXPProjection()
  if self.xpProjectionFrame then return end
  local parent = barParent()
  local frame = CreateFrame("Frame", "ForeverPathXPProjectionFrame", UIParent, "BackdropTemplate")
  frame:SetFrameStrata("HIGH"); frame:SetToplevel(true); frame:SetClampedToScreen(true); frame:SetMovable(true); frame:EnableMouse(true); frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart",function()
    local ui=NS.db and NS.db.ui or {}
    if not ui.xpProjectionLocked and not ui.lockFrames then frame:StartMoving() end
  end)
  frame:SetScript("OnDragStop",function() frame:StopMovingOrSizing(); if NS.SaveFramePosition then NS:SaveFramePosition(frame,"xpProjection") end end)
  frame.bg = frame:CreateTexture(nil, "BACKGROUND")
  frame.bg:SetAllPoints(); frame.bg:SetColorTexture(0.02, 0.03, 0.06, 0.72)
  frame.preview = CreateFrame("StatusBar", nil, frame)
  frame.preview:SetPoint("LEFT", 1, 0); frame.preview:SetPoint("RIGHT", -1, 0); frame.preview:SetHeight(7)
  frame.preview:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); frame.preview:SetStatusBarColor(0.92, 0.65, 0.16, 0.60)
  frame.current = CreateFrame("StatusBar", nil, frame)
  frame.current:SetPoint("LEFT", 1, 0); frame.current:SetPoint("RIGHT", -1, 0); frame.current:SetHeight(7)
  frame.current:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); frame.current:SetStatusBarColor(0.22, 0.55, 0.92, 0.92)
  frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  frame.text:SetPoint("TOP", 0, -2); frame.text:SetJustifyH("CENTER")
  frame.text:SetTextColor(0.94, 0.78, 0.30)
  self.xpProjectionFrame = frame
  if self.RestoreFramePosition then self:RestoreFramePosition(frame,"xpProjection","BOTTOM",parent,0,2) end
  self:ApplyXPProjectionSettings()
  self:RefreshXPProjection()
end

function NS:ApplyXPProjectionSettings()
  local f=self.xpProjectionFrame; if not f then return end
  self:EnsureSettings(); local ui=self.db.ui
  local width=math.max(220,math.min(900,ui.xpBarWidth or 420)); local height=math.max(16,math.min(64,ui.xpBarHeight or 28)); local scale=math.max(0.70,math.min(1.50,ui.xpBarScale or 1))
  f:SetSize(width,height); f:SetScale(scale); f:SetAlpha(ui.opacity or 0.96); f:EnableMouse(not ui.xpProjectionLocked and not ui.lockFrames); f:SetShown(ui.xpProjection ~= false)
  local barHeight=math.max(4,math.min(14,math.floor(height*0.30)))
  f.preview:ClearAllPoints(); f.preview:SetPoint("LEFT",1,0); f.preview:SetPoint("RIGHT",-1,0); f.preview:SetHeight(barHeight)
  f.current:ClearAllPoints(); f.current:SetPoint("LEFT",1,0); f.current:SetPoint("RIGHT",-1,0); f.current:SetHeight(barHeight)
  f.text:ClearAllPoints(); f.text:SetPoint("TOP",0,-2)
end
function NS:SetXPProjectionShown(shown)
  self:EnsureSettings(); self.db.ui.xpProjection=shown~=false; self:ApplyXPProjectionSettings(); self:Refresh()
end
function NS:CycleXPProjectionWidth()
  self:EnsureSettings(); local values={300,420,560,720}; local current=self.db.ui.xpBarWidth or 420; local nextValue=values[1]
  for i,v in ipairs(values) do if current==v then nextValue=values[i%#values+1]; break end end
  self.db.ui.xpBarWidth=nextValue; self:ApplyXPProjectionSettings(); self:Refresh()
end
function NS:CycleXPProjectionHeight()
  self:EnsureSettings(); local values={20,28,38,50}; local current=self.db.ui.xpBarHeight or 28; local nextValue=values[1]
  for i,v in ipairs(values) do if current==v then nextValue=values[i%#values+1]; break end end
  self.db.ui.xpBarHeight=nextValue; self:ApplyXPProjectionSettings(); self:Refresh()
end
function NS:CycleXPProjectionScale()
  self:EnsureSettings(); local values={0.80,1.00,1.20,1.40}; local current=self.db.ui.xpBarScale or 1; local nextValue=values[1]
  for i,v in ipairs(values) do if math.abs(current-v)<0.02 then nextValue=values[i%#values+1]; break end end
  self.db.ui.xpBarScale=nextValue; self:ApplyXPProjectionSettings(); self:Refresh()
end
function NS:ToggleXPProjectionLock()
  self:EnsureSettings(); self.db.ui.xpProjectionLocked=not self.db.ui.xpProjectionLocked; self:Refresh()
end

function NS:RefreshXPProjection()
  if not self.db then return end
  if not self.xpProjectionFrame then self:CreateXPProjection(); return end
  local projection = self:GetQuestLogProjection()
  local f = self.xpProjectionFrame
  self:ApplyXPProjectionSettings()
  local maxXP = math.max(1, projection.maximumXP)
  -- Gold preview represents the complete value of all known questlog
  -- rewards.  The text still separates rewards that are already turn-in
  -- ready, which is what drives LEVEL UP READY.
  f.preview:SetMinMaxValues(0, maxXP); f.preview:SetValue(projection.questLogProjectedXP or projection.projectedXP)
  f.current:SetMinMaxValues(0, maxXP); f.current:SetValue(projection.currentXP)
  if projection.ready then
    f.text:SetText("|cff69ff9aLEVEL UP READY!|r  Questlog: " .. tostring(projection.questLogXP or 0) .. " XP (" .. tostring(projection.questLogCount or 0) .. ") · Abgabe bereit: " .. tostring(projection.completedQuestXP or 0) .. " XP · " .. formatDuration(projection.timeToLevel))
    f.text:SetTextColor(0.40, 1, 0.60)
    f:SetAlpha(0.96)
  else
    local suffix = projection.reliable and "" or " · teils geschätzt"
    f.text:SetText(string.format("Quest-Vorschau: %d XP (%d Quest%s) · Abgabe bereit: %d XP (%d fertig) · %.0f%% · Level-Up in %s%s", projection.questLogXP or 0, projection.questLogCount or 0, (projection.questLogCount or 0) == 1 and "" or "s", projection.completedQuestXP or 0, projection.questCount or 0, (projection.questLogProjectedPercent or 0) * 100, formatDuration(projection.timeToLevel), suffix))
    f.text:SetTextColor(0.94, 0.78, 0.30)
    f:SetAlpha((self.db.ui and self.db.ui.opacity) or 0.96)
  end
  if self.frame and self.frame.views and self.frame.views.route and self.frame.views.route.xpProjection then
    local p = self.frame.views.route.xpProjection
    p:SetText(string.format("Quest-Vorschau: %d XP (%d Quest%s) · Abgabe bereit: %d XP (%d fertig) · Vorschau %.0f%% · Level-Up in %s · %s", projection.questLogXP or 0, projection.questLogCount or 0, (projection.questLogCount or 0) == 1 and "" or "s", projection.completedQuestXP or 0, projection.questCount or 0, (projection.questLogProjectedPercent or 0) * 100, formatDuration(projection.timeToLevel), projection.ready and "Level Up Ready!" or "noch offen"))
    p:SetTextColor(projection.ready and 0.40 or 0.94, projection.ready and 1 or 0.78, projection.ready and 0.60 or 0.30)
  end
end
