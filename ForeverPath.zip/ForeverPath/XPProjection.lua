local NS = ForeverPath
local function tr(text) return NS.L and NS:L(text) or text end

-- XP-Projektion und Buff-Erkennung. Alle APIs sind defensiv gekapselt, weil
-- WoW-Forever je nach Client-Build unterschiedliche Classic-APIs anbietet.
local function number(value)
  if type(value) ~= "number" then return nil end
  if issecretvalue then
    local ok, secret = pcall(issecretvalue, value)
    if ok and secret then return nil end
  end
  return value
end

local function safeCall(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, value = pcall(fn, ...)
  return ok and value or nil
end

local function safeQuestLogSelect(entry)
  if not entry then return false end
  if C_QuestLog and C_QuestLog.SetSelectedQuest and entry.id then
    local ok = pcall(C_QuestLog.SetSelectedQuest, entry.id)
    if ok then return true end
  end
  if SelectQuestLogEntry and entry.index then
    local ok = pcall(SelectQuestLogEntry, entry.index)
    if ok then return true end
  end
  return false
end

local function plainText(value)
  if type(value) ~= "string" then return "" end
  return string.lower(value:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end

local function formatNumber(value)
  value=math.floor(number(value) or 0)
  local text=tostring(value)
  local separator=(NS.db and NS.db.ui and NS.db.ui.language=="en") and "," or "."
  local changed
  repeat text,changed=text:gsub("^(%-?%d+)(%d%d%d)","%1"..separator.."%2") until changed==0
  return text
end

local function compactMinutes(seconds)
  seconds=number(seconds) or 0
  if seconds<=0 then return "0m" end
  local minutes=math.floor(seconds/60+0.5)
  return minutes<1 and "<1m" or tostring(minutes).."m"
end

function NS:GetXPState()
  local current = number(safeCall(UnitXP, "player")) or 0
  local maximum = number(safeCall(UnitXPMax, "player")) or 0
  local level = number(safeCall(UnitLevel, "player")) or 1
  return { current=current, maximum=maximum, level=level, remaining=math.max(0, maximum-current) }
end

function NS:GetXPMultipliers()
  local rested = number(safeCall(GetXPExhaustion, "player")) or number(safeCall(GetXPExhaustion)) or 0
  local result = { restedXP=math.max(0, rested), kill=1, quest=1, labels={} }
  if rested > 0 then result.labels[#result.labels+1] = "Erholt" end

  local function inspectAura(name, description)
    local text = plainText((name or "") .. " " .. (description or ""))
    if not string.find(text, "xp", 1, true) and not string.find(text, "experience", 1, true)
      and not string.find(text, "erfahrung", 1, true) then return end
    local percent = tonumber(string.match(text, "(%d+)%s*%%"))
    if percent and percent > 0 and percent < 500 then
      result.kill = result.kill * (1 + percent / 100)
      result.quest = result.quest * (1 + percent / 100)
      result.labels[#result.labels+1] = (name or "Event") .. " +" .. percent .. "%"
    else
      result.labels[#result.labels+1] = name or "XP-Event"
    end
  end

  if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
    for index=1,40 do
      local aura = safeCall(C_UnitAuras.GetAuraDataByIndex, "player", index, "HELPFUL")
      if not aura then break end
      -- Aura fields may be protected on some Forever builds.  Keep the
      -- optional multiplier scan isolated so it can never stop the route UI.
      pcall(function() inspectAura(aura.name, aura.description) end)
    end
  elseif UnitAura then
    for index=1,40 do
      local ok, name = pcall(UnitAura, "player", index, "HELPFUL")
      if not ok then break end
      if not name then break end
      pcall(function() inspectAura(name, "") end)
    end
  end
  return result
end

local function tooltipLines(tooltip)
  local lines = {}
  if not tooltip or not tooltip.GetName then return lines end
  local name = tooltip:GetName()
  for index=1,tooltip:NumLines() do
    local left = _G[name .. "TextLeft" .. index]
    local right = _G[name .. "TextRight" .. index]
    if left and left.GetText then lines[#lines+1] = left:GetText() or "" end
    if right and right.GetText then lines[#lines+1] = right:GetText() or "" end
  end
  return lines
end

local function parseXP(text)
  text = tostring(text or "")
  local clean = text:gsub(",", ""):gsub("%.", "")
  local value = string.match(clean, "(%d+)%s*[xX][pP]")
    or string.match(clean, "[eE]xperience[^%d]*(%d+)")
    or string.match(clean, "[eE]rfahrung[^%d]*(%d+)")
    or string.match(clean, "[xX][pP][^%d]*(%d+)")
    or string.match(clean, "(%d+)%s*[eE]rfahrung")
    or string.match(clean, "(%d+)%s*[eE]xperience")
  return tonumber(value)
end

function NS:ScanQuestRewardTooltip(questID, index)
  if not GameTooltip then return 0 end
  local tooltip = GameTooltip
  local owner = UIParent or tooltip
  local visible = safeCall(tooltip.IsShown, tooltip) == true
  pcall(tooltip.SetOwner, tooltip, owner, "ANCHOR_NONE")
  local shown = false
  if questID and tooltip.SetHyperlink then
    shown = pcall(tooltip.SetHyperlink, tooltip, "quest:" .. tostring(questID))
  end
  if not shown and tooltip.SetQuestLogItem and index then
    shown = pcall(tooltip.SetQuestLogItem, tooltip, "reward", index)
  end
  local xp = 0
  if shown then
    local ok, lines = pcall(tooltipLines, tooltip)
    if ok and lines then for _, line in ipairs(lines) do xp = parseXP(line) or xp end end
  end
  pcall(tooltip.Hide, tooltip)
  if visible then pcall(tooltip.Show, tooltip) end
  return xp or 0
end

function NS:GetQuestRewardXP(questID, index, entry)
  local value
  safeQuestLogSelect(entry or {id=questID,index=index})
  if C_QuestLog and C_QuestLog.GetQuestRewardXP and questID then
    value = number(safeCall(C_QuestLog.GetQuestRewardXP, questID))
  end
  if not value and GetQuestLogRewardXP then
    value = number(safeCall(GetQuestLogRewardXP))
  end
  if value and value > 0 then return value, "API" end
  local fallback = self:ScanQuestRewardTooltip(questID, index)
  if fallback and fallback > 0 then return fallback, "Tooltip" end
  return 0, "unbekannt"
end

local function moneyValue(value)
  local direct = number(value)
  if direct then return math.max(0, direct) end
  if type(value) ~= "table" then return nil end
  for _, key in ipairs({"money", "rewardMoney", "moneyReward", "copper", "amount"}) do
    local amount = number(value[key])
    if amount then return math.max(0, amount) end
  end
  return nil
end

function NS:FormatQuestMoney(copper)
  copper = math.floor(number(copper) or 0)
  if copper <= 0 then return tr("Kein Questgold bekannt") end
  local gold = math.floor(copper / 10000)
  local silver = math.floor((copper % 10000) / 100)
  local bronze = copper % 100
  local parts = {}
  if gold > 0 then parts[#parts + 1] = tostring(gold) .. "g" end
  if silver > 0 or gold > 0 then parts[#parts + 1] = tostring(silver) .. "s" end
  if bronze > 0 or #parts == 0 then parts[#parts + 1] = tostring(bronze) .. "c" end
  return table.concat(parts, " ")
end

function NS:GetQuestRewardMoney(questID, index, entry, record)
  questID = number(questID)
  if not questID or questID <= 0 then return 0, "unbekannt" end
  self.questRewardMoneyCache = self.questRewardMoneyCache or {}
  local key = tostring(questID) .. ":" .. tostring(index or 0) .. ":" .. tostring(self.rewardWindow and 1 or 0)
  local cached = self.questRewardMoneyCache[key]
  if cached then return cached.value, cached.source end

  local value, source
  local live = entry or (self.GetLiveQuest and self:GetLiveQuest(questID))
  -- Never select an arbitrary current quest for a route-only record. Without
  -- a live quest-log entry the client reward APIs may describe another quest.
  if live or index then
    safeQuestLogSelect(live or {id=questID, index=index})
    if self.rewardWindow and type(GetRewardMoney) == "function" then
      value = moneyValue(safeCall(GetRewardMoney)); source = value and "API" or nil
    end
    if not value and C_QuestLog and type(C_QuestLog.GetQuestRewardMoney) == "function" then
      value = moneyValue(safeCall(C_QuestLog.GetQuestRewardMoney, questID))
      source = value and "API" or nil
    end
    if not value and type(GetQuestLogRewardMoney) == "function" then
      value = moneyValue(safeCall(GetQuestLogRewardMoney)); source = value and "API" or nil
    end
  end

  record = record or (live and live.record) or (self.questDB and self.questDB[questID])
  if not value and record then
    value = moneyValue(record.rewardMoney or record.moneyReward or record.goldReward)
    source = value and "ForeverDB" or nil
  end
  value = value or 0
  source = source or "unbekannt"
  self.questRewardMoneyCache[key] = {value=value, source=source}
  return value, source
end

function NS:GetQuestGoldForStep(step)
  if not step or not step.questID then return 0, "unbekannt", 0 end
  local live = self.GetLiveQuest and self:GetLiveQuest(step.questID) or nil
  local copper, source = self:GetQuestRewardMoney(step.questID, live and live.index, live, step.record)
  return (number(copper) or 0) / 10000, source, copper
end

local function questLogEntries()
  local entries = {}
  if C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo then
    local count = number(safeCall(C_QuestLog.GetNumQuestLogEntries)) or 0
    for index=1,count do
      local info = safeCall(C_QuestLog.GetInfo, index)
      local questID = info and number(info.questID)
      if info and not info.isHeader and questID and questID > 0 then
        entries[#entries+1] = {index=index, id=questID, complete=info.isComplete == true or info.isComplete == 1}
      end
    end
  end
  -- Some Forever builds expose the modern namespace but return no usable
  -- quest entries.  Always try the legacy API as a fallback in that case.
  if #entries == 0 and GetNumQuestLogEntries and GetQuestLogTitle then
    local count = number(safeCall(GetNumQuestLogEntries)) or 0
    for index=1,count do
      local ok, _, _, _, _, isHeader, _, complete, _, questID = pcall(GetQuestLogTitle, index)
      questID = number(questID)
      if ok and questID and questID > 0 and not isHeader then
        entries[#entries+1] = {index=index, id=questID, complete=complete == true or complete == 1}
      end
    end
  end
  return entries
end

function NS:ScanQuestLogXP()
  local completedTotal, completedCount = 0, 0
  local allTotal, allCount = 0, 0
  local completedMoney, allMoney = 0, 0
  local reliable = true
  for _, entry in ipairs(questLogEntries()) do
    local value, source = self:GetQuestRewardXP(entry.id, entry.index, entry)
    local money = self:GetQuestRewardMoney(entry.id, entry.index, entry)
    allMoney = allMoney + (number(money) or 0)
    if entry.complete then completedMoney = completedMoney + (number(money) or 0) end
    if value and value > 0 then
      allTotal = allTotal + value
      allCount = allCount + 1
      if entry.complete then
        completedTotal = completedTotal + value
        completedCount = completedCount + 1
      end
    else
      reliable = false
    end
    if source == "Tooltip" then reliable = false end
  end
  return completedTotal, completedCount, reliable, allTotal, allCount, completedMoney, allMoney
end

function NS:GetQuestLogProjection()
  local state = self:GetXPState()
  local questXP, questCount, reliable, questLogXP, questLogCount, completedQuestMoney, questLogMoney = self:ScanQuestLogXP()
  local multipliers = self:GetXPMultipliers()
  local projected = math.min(state.maximum, state.current + questXP)
  local questLogProjected = math.min(state.maximum, state.current + (questLogXP or 0))
  local rate, timeToLevel, sessionSeconds
  if self.GetSessionStats then
    local ok, stats = pcall(self.GetSessionStats, self)
    if ok and type(stats) == "table" then
      rate = number(stats.movingXPPerHour) or number(stats.xpPerHour) or 0
      timeToLevel = number(stats.ttg)
      sessionSeconds = number(stats.elapsed) or 0
    end
  end
  if not timeToLevel and rate and rate > 0 and state.remaining > 0 then
    timeToLevel = state.remaining / rate * 3600
  end
  return {
    level=state.level, currentXP=state.current, maximumXP=state.maximum, remaining=state.remaining,
    completedQuestXP=questXP, questCount=questCount,
    questLogXP=questLogXP, questLogCount=questLogCount,
    projectedXP=projected,
    questLogProjectedXP=questLogProjected,
    projectedPercent=state.maximum > 0 and projected / state.maximum or 0,
    questLogProjectedPercent=state.maximum > 0 and questLogProjected / state.maximum or 0,
    completedQuestMoney=completedQuestMoney or 0,
    questLogMoney=questLogMoney or 0,
    completedQuestGold=(completedQuestMoney or 0) / 10000,
    questLogGold=(questLogMoney or 0) / 10000,
    currentPercent=state.maximum > 0 and state.current / state.maximum or 0,
    ready=questXP >= state.remaining and state.remaining > 0,
    xpPerHour=rate or 0, timeToLevel=timeToLevel,
    sessionSeconds=sessionSeconds or 0,
    levelSeconds=(self.db and self.db.levelTimes and number(self.db.levelTimes[state.level])) or 0,
    restedPercent=state.maximum > 0 and math.min(100,(multipliers.restedXP or 0)/state.maximum*100) or 0,
    reliable=reliable, multipliers=multipliers,
  }
end

local function barParent()
  return _G.MainStatusTrackingBarContainer or _G.MainMenuExpBar or UIParent
end

local function formatDuration(seconds)
  seconds = number(seconds)
  if not seconds or seconds <= 0 then return "wird gemessen" end
  if seconds < 60 then return string.format("%d Sek.", math.floor(seconds)) end
  return string.format("%d:%02d Min.", math.floor(seconds / 60), math.floor(seconds % 60))
end

function NS:CreateXPProjection()
  if self.xpProjectionFrame then return end
  local parent = barParent()
  local frame = CreateFrame("Frame", "ForeverPathXPProjectionFrame", UIParent, "BackdropTemplate")
  frame:SetFrameStrata("HIGH"); frame:SetToplevel(true); frame:SetClampedToScreen(true); frame:SetMovable(true); frame:EnableMouse(true); frame:RegisterForDrag("LeftButton")
  frame:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=8,insets={left=2,right=2,top=2,bottom=2}})
  frame:SetBackdropColor(0.01,0.015,0.03,0.82); frame:SetBackdropBorderColor(0.24,0.33,0.52,0.90)
  frame:SetScript("OnDragStart",function()
    local ui=NS.db and NS.db.ui or {}
    if not ui.xpProjectionLocked and not ui.lockFrames then frame:StartMoving() end
  end)
  frame:SetScript("OnDragStop",function() frame:StopMovingOrSizing(); if NS.SaveFramePosition then NS:SaveFramePosition(frame,"xpProjection") end end)
  frame.bg = frame:CreateTexture(nil, "BACKGROUND")
  frame.bg:SetPoint("TOPLEFT",3,-3); frame.bg:SetPoint("BOTTOMRIGHT",-3,3); frame.bg:SetColorTexture(0.02, 0.03, 0.06, 0.42)
  frame.preview = CreateFrame("StatusBar", nil, frame)
  frame.preview:SetPoint("LEFT", 2, 0); frame.preview:SetPoint("RIGHT", -2, 0); frame.preview:SetHeight(14)
  frame.preview:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); frame.preview:SetStatusBarColor(0.92, 0.65, 0.16, 0.60)
  frame.current = CreateFrame("StatusBar", nil, frame)
  frame.current:SetPoint("LEFT", 2, 0); frame.current:SetPoint("RIGHT", -2, 0); frame.current:SetHeight(14)
  frame.current:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); frame.current:SetStatusBarColor(0.34, 0.22, 0.78, 0.96)
  frame.timeLevel=frame:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); frame.timeLevel:SetJustifyH("LEFT"); frame.timeLevel:SetTextColor(0.78,0.82,0.92)
  frame.sessionTime=frame:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); frame.sessionTime:SetJustifyH("RIGHT"); frame.sessionTime:SetTextColor(0.78,0.82,0.92)
  frame.progressText=frame:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); frame.progressText:SetJustifyH("CENTER"); frame.progressText:SetTextColor(0.96,0.96,1.00)
  frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  frame.text:SetJustifyH("LEFT"); frame.text:SetWordWrap(false); frame.text:SetTextColor(0.94, 0.78, 0.30)
  frame.questText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  frame.questText:SetJustifyH("LEFT"); frame.questText:SetWordWrap(false); frame.questText:SetTextColor(0.80, 0.84, 0.94)
  self.xpProjectionFrame = frame
  if self.RestoreFramePosition then self:RestoreFramePosition(frame,"xpProjection","BOTTOM",parent,0,2) end
  self:ApplyXPProjectionSettings()
  self:RefreshXPProjection()
end

function NS:ApplyXPProjectionSettings()
  local f=self.xpProjectionFrame; if not f then return end
  self:EnsureSettings(); local ui=self.db.ui
  local width=math.max(320,math.min(900,ui.xpBarWidth or 560)); local height=math.max(64,math.min(96,ui.xpBarHeight or 64)); local scale=math.max(0.70,math.min(1.50,ui.xpBarScale or 1))
  f:SetSize(width,height); f:SetScale(scale); f:SetAlpha(ui.opacity or 0.96); f:EnableMouse(not ui.xpProjectionLocked and not ui.lockFrames); f:SetShown(ui.xpProjection ~= false)
  local barHeight=math.max(10,math.min(18,math.floor(height*0.25)))
  f.preview:ClearAllPoints(); f.preview:SetPoint("TOPLEFT",2,-18); f.preview:SetPoint("TOPRIGHT",-2,-18); f.preview:SetHeight(barHeight)
  f.current:ClearAllPoints(); f.current:SetPoint("TOPLEFT",2,-18); f.current:SetPoint("TOPRIGHT",-2,-18); f.current:SetHeight(barHeight)
  f.timeLevel:ClearAllPoints(); f.timeLevel:SetPoint("TOPLEFT",7,-5); f.timeLevel:SetWidth(width*0.48); f.timeLevel:SetHeight(14)
  f.sessionTime:ClearAllPoints(); f.sessionTime:SetPoint("TOPRIGHT",-7,-5); f.sessionTime:SetWidth(width*0.48); f.sessionTime:SetHeight(14)
  f.progressText:ClearAllPoints(); f.progressText:SetPoint("CENTER",0,-18); f.progressText:SetWidth(width-12); f.progressText:SetHeight(barHeight); f.progressText:SetShadowOffset(1,-1)
  f.text:ClearAllPoints(); f.text:SetPoint("BOTTOMLEFT",7,18); f.text:SetWidth(width-14); f.text:SetHeight(14)
  f.questText:ClearAllPoints(); f.questText:SetPoint("BOTTOMLEFT",7,4); f.questText:SetWidth(width-14); f.questText:SetHeight(14)
end
function NS:SetXPProjectionShown(shown)
  self:EnsureSettings(); self.db.ui.xpProjection=shown~=false; self:ApplyXPProjectionSettings(); self:Refresh()
end
function NS:CycleXPProjectionWidth()
  self:EnsureSettings(); local values={420,560,680,820}; local current=self.db.ui.xpBarWidth or 560; local nextValue=values[1]
  for i,v in ipairs(values) do if current==v then nextValue=values[i%#values+1]; break end end
  self.db.ui.xpBarWidth=nextValue; self:ApplyXPProjectionSettings(); self:Refresh()
end
function NS:CycleXPProjectionHeight()
  self:EnsureSettings(); local values={64,72,84,96}; local current=self.db.ui.xpBarHeight or 64; local nextValue=values[1]
  for i,v in ipairs(values) do if current==v then nextValue=values[i%#values+1]; break end end
  self.db.ui.xpBarHeight=nextValue; self:ApplyXPProjectionSettings(); self:Refresh()
end
function NS:CycleXPProjectionScale()
  self:EnsureSettings(); local values={0.80,1.00,1.20,1.40}; local current=self.db.ui.xpBarScale or 1; local nextValue=values[1]
  for i,v in ipairs(values) do if math.abs(current-v)<0.02 then nextValue=values[i%#values+1]; break end end
  self.db.ui.xpBarScale=nextValue; self:ApplyXPProjectionSettings(); self:Refresh()
end
function NS:ToggleXPProjectionLock()
  self:EnsureSettings(); self.db.ui.xpProjectionLocked=not self.db.ui.xpProjectionLocked; self:Refresh()
end

function NS:RefreshXPProjection()
  if not self.db then return end
  if not self.xpProjectionFrame then self:CreateXPProjection(); return end
  local projection = self:GetQuestLogProjection()
  local f = self.xpProjectionFrame
  self:ApplyXPProjectionSettings()
  local maxXP = math.max(1, projection.maximumXP)
  -- Gold preview represents the complete value of all known questlog
  -- rewards.  The text still separates rewards that are already turn-in
  -- ready, which is what drives LEVEL UP READY.
  f.preview:SetMinMaxValues(0, maxXP); f.preview:SetValue(projection.questLogProjectedXP or projection.projectedXP)
  f.current:SetMinMaxValues(0, maxXP); f.current:SetValue(projection.currentXP)
  local currentPercent=projection.currentPercent or 0
  local completedPercent=maxXP>0 and math.min(100,(projection.completedQuestXP or 0)/maxXP*100) or 0
  f.timeLevel:SetText(tr("Zeit auf diesem Level: ")..compactMinutes(projection.levelSeconds))
  f.sessionTime:SetText(tr("Zeit in dieser Sitzung: ")..compactMinutes(projection.sessionSeconds))
  f.progressText:SetText(string.format("Level %d    %s / %s (%.1f%%)",projection.level or 1,formatNumber(projection.currentXP),formatNumber(projection.maximumXP),currentPercent*100))
  local eta=projection.timeToLevel and formatDuration(projection.timeToLevel) or tr("XP/h wird gemessen")
  local rate=projection.xpPerHour and projection.xpPerHour>0 and string.format("%.0f XP/h",projection.xpPerHour) or tr("XP/h wird gemessen")
  local bottom=tr("Level-Up in: ")..eta.." · "..rate
  local questLine=tr("Abgeschlossen: ")..string.format("%.1f%%",completedPercent).." · "..tr("Erholt: ")..string.format("%.0f%%",projection.restedPercent or 0)
  if (projection.questLogCount or 0)>0 then
    questLine=questLine.." · "..tr("Questlog: ")..formatNumber(projection.questLogXP or 0).." XP"
    if (projection.questLogMoney or 0) > 0 then questLine=questLine.." · Gold: "..self:FormatQuestMoney(projection.questLogMoney) end
  end
  if projection.ready then f.text:SetText("|cff69ff9a"..tr("LEVEL UP READY!").."|r · "..bottom); f.text:SetTextColor(0.40,1,0.60) else f.text:SetText(bottom); f.text:SetTextColor(0.94,0.78,0.30) end
  f.questText:SetText(questLine)
  f:SetAlpha((self.db.ui and self.db.ui.opacity) or 0.96)
  if self.frame and self.frame.views and self.frame.views.route and self.frame.views.route.xpProjection then
    local p = self.frame.views.route.xpProjection
    p:SetText(string.format("Quest-Vorschau: %d XP (%d Quest%s) · Abgabe bereit: %d XP (%d fertig) · Vorschau %.0f%% · Level-Up in %s · %s", projection.questLogXP or 0, projection.questLogCount or 0, (projection.questLogCount or 0) == 1 and "" or "s", projection.completedQuestXP or 0, projection.questCount or 0, (projection.questLogProjectedPercent or 0) * 100, formatDuration(projection.timeToLevel), projection.ready and "Level Up Ready!" or "noch offen"))
    p:SetTextColor(projection.ready and 0.40 or 0.94, projection.ready and 1 or 0.78, projection.ready and 0.60 or 0.30)
  end
end
