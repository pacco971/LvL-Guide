local NS = ForeverPath

-- XP-Projektion und Buff-Erkennung. Alle APIs sind defensiv gekapselt, weil
-- WoW-Forever je nach Client-Build unterschiedliche Classic-APIs anbietet.
local function number(value)
  if type(value) ~= "number" then return nil end
  if issecretvalue then
    local ok, secret = pcall(issecretvalue, value)
    if ok and secret then return nil end
  end
  return value
end

local function safeCall(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, value = pcall(fn, ...)
  return ok and value or nil
end

local function plainText(value)
  if type(value) ~= "string" then return "" end
  return string.lower(value:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end

function NS:GetXPState()
  local current = number(safeCall(UnitXP, "player")) or 0
  local maximum = number(safeCall(UnitXPMax, "player")) or 0
  local level = number(safeCall(UnitLevel, "player")) or 1
  return { current=current, maximum=maximum, level=level, remaining=math.max(0, maximum-current) }
end

function NS:GetXPMultipliers()
  local rested = number(safeCall(GetXPExhaustion, "player")) or number(safeCall(GetXPExhaustion)) or 0
  local result = { restedXP=math.max(0, rested), kill=1, quest=1, labels={} }
  if rested > 0 then result.labels[#result.labels+1] = "Erholt" end

  local function inspectAura(name, description)
    local text = plainText((name or "") .. " " .. (description or ""))
    if not string.find(text, "xp", 1, true) and not string.find(text, "experience", 1, true)
      and not string.find(text, "erfahrung", 1, true) then return end
    local percent = tonumber(string.match(text, "(%d+)%s*%%"))
    if percent and percent > 0 and percent < 500 then
      result.kill = result.kill * (1 + percent / 100)
      result.quest = result.quest * (1 + percent / 100)
      result.labels[#result.labels+1] = (name or "Event") .. " +" .. percent .. "%"
    else
      result.labels[#result.labels+1] = name or "XP-Event"
    end
  end

  if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
    for index=1,40 do
      local aura = safeCall(C_UnitAuras.GetAuraDataByIndex, "player", index, "HELPFUL")
      if not aura then break end
      inspectAura(aura.name, aura.description)
    end
  elseif UnitAura then
    for index=1,40 do
      local name, _, _, _, _, _, _, _, _, spellID = UnitAura("player", index, "HELPFUL")
      if not name then break end
      inspectAura(name, "")
    end
  end
  return result
end

local function tooltipLines(tooltip)
  local lines = {}
  if not tooltip or not tooltip.GetName then return lines end
  local name = tooltip:GetName()
  for index=1,tooltip:NumLines() do
    local left = _G[name .. "TextLeft" .. index]
    local right = _G[name .. "TextRight" .. index]
    if left and left.GetText then lines[#lines+1] = left:GetText() or "" end
    if right and right.GetText then lines[#lines+1] = right:GetText() or "" end
  end
  return lines
end

local function parseXP(text)
  local clean = text:gsub(",", ""):gsub("%.", "")
  local value = string.match(clean, "(%d+)%s*[xX][pP]")
    or string.match(clean, "[eE]xperience[^%d]*(%d+)")
    or string.match(clean, "[eE]rfahrung[^%d]*(%d+)")
  return tonumber(value)
end

function NS:ScanQuestRewardTooltip(questID, index)
  if not GameTooltip then return 0 end
  local tooltip = GameTooltip
  local owner = UIParent or tooltip
  local visible = tooltip:IsShown()
  tooltip:SetOwner(owner, "ANCHOR_NONE")
  local shown = false
  if questID and tooltip.SetHyperlink then
    shown = pcall(tooltip.SetHyperlink, tooltip, "quest:" .. tostring(questID))
  end
  if not shown and tooltip.SetQuestLogItem and index then
    shown = pcall(tooltip.SetQuestLogItem, tooltip, "reward", index)
  end
  local xp = 0
  if shown then
    for _, line in ipairs(tooltipLines(tooltip)) do xp = parseXP(line) or xp end
  end
  tooltip:Hide()
  if visible then tooltip:Show() end
  return xp or 0
end

function NS:GetQuestRewardXP(questID, index)
  local value
  if C_QuestLog and C_QuestLog.GetQuestRewardXP and questID then
    value = number(safeCall(C_QuestLog.GetQuestRewardXP, questID))
  end
  if not value and GetQuestLogRewardXP then
    value = number(safeCall(GetQuestLogRewardXP))
  end
  if value and value > 0 then return value, "API" end
  local fallback = self:ScanQuestRewardTooltip(questID, index)
  if fallback and fallback > 0 then return fallback, "Tooltip" end
  return 0, "unbekannt"
end

local function questLogEntries()
  local entries = {}
  if C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo then
    local count = safeCall(C_QuestLog.GetNumQuestLogEntries) or 0
    for index=1,count do
      local info = safeCall(C_QuestLog.GetInfo, index)
      if info and not info.isHeader and info.questID and info.questID > 0 then
        entries[#entries+1] = {index=index, id=info.questID, complete=info.isComplete == true}
      end
    end
  elseif GetNumQuestLogEntries and GetQuestLogTitle then
    for index=1,GetNumQuestLogEntries() do
      local _, _, _, _, isHeader, _, complete, _, questID = GetQuestLogTitle(index)
      if questID and questID > 0 and not isHeader then entries[#entries+1] = {index=index, id=questID, complete=complete == 1} end
    end
  end
  return entries
end

function NS:ScanQuestLogXP()
  local total, count, reliable = 0, 0, true
  for _, entry in ipairs(questLogEntries()) do
    if entry.complete then
      local value, source = self:GetQuestRewardXP(entry.id, entry.index)
      if value and value > 0 then
        total = total + value
        count = count + 1
      else
        reliable = false
      end
      if source == "Tooltip" then reliable = false end
    end
  end
  return total, count, reliable
end

function NS:GetQuestLogProjection()
  local state = self:GetXPState()
  local questXP, questCount, reliable = self:ScanQuestLogXP()
  local multipliers = self:GetXPMultipliers()
  local projected = math.min(state.maximum, state.current + questXP)
  return {
    currentXP=state.current, maximumXP=state.maximum, remaining=state.remaining,
    completedQuestXP=questXP, questCount=questCount, projectedXP=projected,
    projectedPercent=state.maximum > 0 and projected / state.maximum or 0,
    currentPercent=state.maximum > 0 and state.current / state.maximum or 0,
    ready=questXP >= state.remaining and state.remaining > 0,
    reliable=reliable, multipliers=multipliers,
  }
end

local function barParent()
  return _G.MainStatusTrackingBarContainer or _G.MainMenuExpBar or UIParent
end

function NS:CreateXPProjection()
  if self.xpProjectionFrame then return end
  local parent = barParent()
  local frame = CreateFrame("Frame", "ForeverPathXPProjectionFrame", UIParent, "BackdropTemplate")
  frame:SetFrameStrata("LOW")
  frame:SetSize(math.max(220, (parent.GetWidth and parent:GetWidth() or 300)), 28)
  if parent ~= UIParent and parent.GetWidth then
    frame:SetPoint("BOTTOM", parent, "TOP", 0, 2)
  else
    frame:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 86)
  end
  frame.bg = frame:CreateTexture(nil, "BACKGROUND")
  frame.bg:SetAllPoints(); frame.bg:SetColorTexture(0.02, 0.03, 0.06, 0.72)
  frame.preview = CreateFrame("StatusBar", nil, frame)
  frame.preview:SetPoint("LEFT", 1, 0); frame.preview:SetPoint("RIGHT", -1, 0); frame.preview:SetHeight(7)
  frame.preview:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); frame.preview:SetStatusBarColor(0.92, 0.65, 0.16, 0.60)
  frame.current = CreateFrame("StatusBar", nil, frame)
  frame.current:SetPoint("LEFT", 1, 0); frame.current:SetPoint("RIGHT", -1, 0); frame.current:SetHeight(7)
  frame.current:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); frame.current:SetStatusBarColor(0.22, 0.55, 0.92, 0.92)
  frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  frame.text:SetPoint("TOP", 0, -2); frame.text:SetJustifyH("CENTER")
  frame.text:SetTextColor(0.94, 0.78, 0.30)
  frame:SetAlpha((self.db and self.db.ui and self.db.ui.opacity) or 0.96)
  self.xpProjectionFrame = frame
  self:RefreshXPProjection()
end

function NS:RefreshXPProjection()
  if not self.db then return end
  if not self.xpProjectionFrame then self:CreateXPProjection(); return end
  local projection = self:GetQuestLogProjection()
  local f = self.xpProjectionFrame
  local maxXP = math.max(1, projection.maximumXP)
  f.preview:SetMinMaxValues(0, maxXP); f.preview:SetValue(projection.projectedXP)
  f.current:SetMinMaxValues(0, maxXP); f.current:SetValue(projection.currentXP)
  if projection.ready then
    f.text:SetText("|cff69ff9aLEVEL UP READY!|r  Fertige Quests: " .. tostring(projection.completedQuestXP) .. " XP")
    f.text:SetTextColor(0.40, 1, 0.60)
    f:SetAlpha(0.96)
  else
    local suffix = projection.reliable and "" or " · teils geschätzt"
    f.text:SetText(string.format("Quest-Vorschau: %d XP · %.0f%%%s", projection.completedQuestXP or 0, (projection.projectedPercent or 0) * 100, suffix))
    f.text:SetTextColor(0.94, 0.78, 0.30)
    f:SetAlpha((self.db.ui and self.db.ui.opacity) or 0.96)
  end
  if self.frame and self.frame.views and self.frame.views.route and self.frame.views.route.xpProjection then
    local p = self.frame.views.route.xpProjection
    p:SetText(string.format("Fertige Quest-XP: %d · Vorschau %.0f%% · %s", projection.completedQuestXP or 0, (projection.projectedPercent or 0) * 100, projection.ready and "Level Up Ready!" or "noch offen"))
    p:SetTextColor(projection.ready and 0.40 or 0.94, projection.ready and 1 or 0.78, projection.ready and 0.60 or 0.30)
  end
end
