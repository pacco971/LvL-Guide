local NS=ForeverPath
local function tr(text) return NS.L and NS:L(text) or text end

function NS:ShowOnboarding()
  if self.onboarding or not self.db then return end
  local f=CreateFrame("Frame","ForeverPathOnboarding",UIParent,"BackdropTemplate")
  f:SetSize(520,300); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG"); f:EnableMouse(true)
  f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",edgeSize=24,insets={left=8,right=8,top=8,bottom=8}}); f:SetBackdropColor(0.035,0.045,0.07,0.98)
  local title=f:CreateFontString(nil,"OVERLAY","GameFontNormalLarge"); title:SetPoint("TOPLEFT",24,-24); title:SetTextColor(0.84,0.66,0.29); title:SetText(tr("Willkommen bei ForeverPath"))
  local _,class=UnitClass("player"); local faction=UnitFactionGroup("player") or "unbekannt"; local data=self.GetOpenDataSummary and self:GetOpenDataSummary() or "Offline-Daten geladen"
  local text=f:CreateFontString(nil,"OVERLAY","GameFontNormal"); text:SetPoint("TOPLEFT",24,-62); text:SetWidth(470); text:SetHeight(135); text:SetJustifyH("LEFT"); text:SetWordWrap(true); text:SetText(string.format(tr("ForeverPath liest Questlog, Zone, Level und Spielereignisse automatisch.\n\nErkannt: %s · %s\n\nDer Tracker, Richtungspfeil und die Minimap-Route starten mit sicheren Standardpositionen. Datenstand:\n%s"),class or tr("Klasse unbekannt"),faction,data))
  local start=CreateFrame("Button",nil,f,"UIPanelButtonTemplate"); start:SetSize(190,30); start:SetPoint("BOTTOMLEFT",24,24); start:SetText(tr("Erste Route starten")); start:SetScript("OnClick",function() NS.db.onboarded=true; f:Hide(); NS:Toggle(); NS:ShowTab("route"); NS:AutoScan(false) end)
  local close=CreateFrame("Button",nil,f,"UIPanelButtonTemplate"); close:SetSize(120,30); close:SetPoint("BOTTOMRIGHT",-24,24); close:SetText(tr("Später")); close:SetScript("OnClick",function() NS.db.onboarded=true; f:Hide() end)
  self.onboarding=f
end
