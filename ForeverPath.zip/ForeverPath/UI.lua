local NS = ForeverPath

local GOLD, BLUE, DARK = {0.84, 0.66, 0.29}, {0.20, 0.55, 0.85}, {0.055, 0.065, 0.09}
local function button(parent, text, width, height)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetText(text); b:SetSize(width or 100, height or 24); return b
end
local function buttonTextColor(buttonFrame, ...)
  if not buttonFrame or not buttonFrame.GetFontString then return end
  local text = buttonFrame:GetFontString()
  if text and text.SetTextColor then text:SetTextColor(...) end
end
local function label(parent, text, size, color)
  local t = parent:CreateFontString(nil, "OVERLAY", size or "GameFontNormal")
  t:SetText(text); if color then t:SetTextColor(unpack(color)) end; return t
end
local function panel(parent, x, y, w, h)
  local p = CreateFrame("Frame", nil, parent, "BackdropTemplate")
  p:SetPoint("TOPLEFT", x, y); p:SetSize(w, h)
  p:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=12, insets={left=3,right=3,top=3,bottom=3}})
  p:SetBackdropColor(unpack(DARK)); p:SetBackdropBorderColor(0.22, 0.25, 0.34, 1); return p
end

function NS:CreateUI()
  local f = CreateFrame("Frame", "ForeverPathFrame", UIParent, "BackdropTemplate")
  f:SetSize(1000, 720); f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", function() if not (NS.db and NS.db.ui and NS.db.ui.lockFrames) then f:StartMoving() end end); f:SetScript("OnDragStop", function() f:StopMovingOrSizing(); NS:SaveFramePosition(f, "main") end)
  f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", edgeSize=24, insets={left=8,right=8,top=8,bottom=8}})
  f:SetBackdropColor(0.035, 0.045, 0.07, 0.98)
  local title = label(f, "FOREVERPATH", "GameFontNormalLarge", GOLD); title:SetPoint("TOPLEFT", 24, -20)
  local subtitle = label(f, "Deine Route. Dein Tempo. Deine Entscheidung.", "GameFontNormalSmall", {0.55,0.60,0.70}); subtitle:SetPoint("TOPLEFT", 25, -42)
  local close = button(f, "X", 28, 24); close:SetPoint("TOPRIGHT", -18, -18); close:SetScript("OnClick", function() f:Hide() end)
  f.tabs, f.views = {}, {}
  local tabNames = { {"route", "Route"}, {"fast", "Schnell leveln"}, {"gear", "Gear & Rewards"}, {"dungeon", "Dungeons"}, {"class", "Klasse"}, {"settings", "Einstellungen"} }
  local tabX = 22
  for i, info in ipairs(tabNames) do
    local width = info[1] == "gear" and 142 or info[1] == "fast" and 126 or 115
    local t = button(f, info[2], width, 28); t:SetPoint("TOPLEFT", tabX, -62); f.tabs[info[1]] = t; tabX = tabX + width + 8
  end
  local content = panel(f, 18, -98, 964, 590); f.content = content

  local route = CreateFrame("Frame", nil, content); route:SetAllPoints(); f.views.route = route
  local status = label(route, "", "GameFontNormal", GOLD); status:SetPoint("TOPLEFT", 18, -18); status:SetWidth(900); route.status = status
  route.zoneInfo = label(route, "", "GameFontNormalSmall", {0.55,0.78,0.62}); route.zoneInfo:SetPoint("TOPLEFT", 18, -38); route.zoneInfo:SetWidth(900)
  local bar = CreateFrame("StatusBar", nil, route, "BackdropTemplate"); bar:SetSize(884, 12); bar:SetPoint("TOPLEFT", 18, -62); bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); bar:SetStatusBarColor(unpack(BLUE)); bar:SetMinMaxValues(0, 1); route.progress = bar
  route.xpProjection = label(route, "", "GameFontNormalSmall", GOLD); route.xpProjection:SetPoint("TOPLEFT", 18, -76); route.xpProjection:SetWidth(884); route.xpProjection:SetJustifyH("LEFT")
  local list = panel(route, 18, -104, 360, 275); route.list = list
  local detail = panel(route, 390, -104, 576, 275); route.detail = detail
  route.detailTitle = label(detail, "", "GameFontNormalLarge", GOLD); route.detailTitle:SetPoint("TOPLEFT", 18, -18); route.detailTitle:SetWidth(530); route.detailTitle:SetJustifyH("LEFT")
  route.detailText = label(detail, "", "GameFontNormal", {0.82,0.84,0.90}); route.detailText:SetPoint("TOPLEFT", 18, -58); route.detailText:SetWidth(535); route.detailText:SetHeight(118); route.detailText:SetJustifyH("LEFT"); route.detailText:SetWordWrap(true)
  route.chainInfo = label(detail, "", "GameFontNormalSmall", {0.55,0.78,0.62}); route.chainInfo:SetPoint("TOPLEFT", 18, -184); route.chainInfo:SetWidth(535); route.chainInfo:SetHeight(42); route.chainInfo:SetJustifyH("LEFT"); route.chainInfo:SetWordWrap(true)
  local done = button(detail, "Schritt erledigt", 145, 28); done:SetPoint("BOTTOMLEFT", 18, 16); done:SetScript("OnClick", function() NS:CompleteCurrent() end); route.done = done
  local skip = button(detail, "Überspringen", 110, 28); skip:SetPoint("BOTTOMLEFT", 174, 16); skip:SetScript("OnClick", function() NS:SkipCurrent() end); route.skip = skip
  local wp = button(detail, "Wegpunkt", 105, 28); wp:SetPoint("BOTTOMRIGHT", -18, 16); wp:SetScript("OnClick", function() if not NS:SetBestWaypoint(NS:GetCurrentStep()) then NS:Print("Für diesen Schritt ist kein Wegpunkt verfügbar.") end end)

  -- Ingame dashboard row matching the ForeverPath design board: compact
  -- navigation, active quest tracking, and live route score at a glance.
  local navPanel = panel(route, 18, -390, 282, 124); route.navPanel = navPanel
  navPanel.title = label(navPanel, "01 · NAVIGATION-HUD", "GameFontNormalSmall", GOLD); navPanel.title:SetPoint("TOPLEFT", 12, -10)
  navPanel.arrow = navPanel:CreateTexture(nil, "OVERLAY"); navPanel.arrow:SetTexture("Interface\\Minimap\\MinimapArrow"); navPanel.arrow:SetSize(52, 52); navPanel.arrow:SetPoint("LEFT", 16, -38); navPanel.arrow:SetVertexColor(0.98, 0.72, 0.18, 1)
  navPanel.target = label(navPanel, "Ziel wird geladen ...", "GameFontNormal", {0.94,0.78,0.30}); navPanel.target:SetPoint("TOPLEFT", 82, -34); navPanel.target:SetWidth(184); navPanel.target:SetWordWrap(false)
  navPanel.distance = label(navPanel, "Entfernung wird gemessen", "GameFontNormalSmall", {0.62,0.78,0.96}); navPanel.distance:SetPoint("TOPLEFT", 82, -56); navPanel.distance:SetWidth(184)
  navPanel.hint = label(navPanel, "Pfeil folgt deiner Blickrichtung", "GameFontNormalSmall", {0.55,0.78,0.62}); navPanel.hint:SetPoint("TOPLEFT", 82, -76); navPanel.hint:SetWidth(184); navPanel.hint:SetWordWrap(false)

  local trackerPanel = panel(route, 319, -390, 282, 124); route.dashboardTracker = trackerPanel
  trackerPanel.title = label(trackerPanel, "02 · QUESTTRACKER", "GameFontNormalSmall", GOLD); trackerPanel.title:SetPoint("TOPLEFT", 12, -10)
  trackerPanel.target = label(trackerPanel, "Aktuelles Questziel", "GameFontNormal", {0.94,0.78,0.30}); trackerPanel.target:SetPoint("TOPLEFT", 12, -34); trackerPanel.target:SetWidth(258); trackerPanel.target:SetWordWrap(false)
  trackerPanel.body = label(trackerPanel, "Questziele werden analysiert", "GameFontNormalSmall", {0.78,0.80,0.86}); trackerPanel.body:SetPoint("TOPLEFT", 12, -56); trackerPanel.body:SetWidth(258); trackerPanel.body:SetHeight(18); trackerPanel.body:SetWordWrap(false)
  trackerPanel.progress = CreateFrame("StatusBar", nil, trackerPanel, "BackdropTemplate"); trackerPanel.progress:SetPoint("BOTTOMLEFT", 12, 18); trackerPanel.progress:SetSize(258, 8); trackerPanel.progress:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); trackerPanel.progress:SetStatusBarColor(0.84,0.66,0.29,1); trackerPanel.progress:SetMinMaxValues(0,1)
  trackerPanel.status = label(trackerPanel, "Fortschritt 0/0", "GameFontNormalSmall", {0.55,0.78,0.62}); trackerPanel.status:SetPoint("BOTTOMLEFT", 12, 3); trackerPanel.status:SetWidth(258)

  local scorePanel = panel(route, 620, -390, 282, 124); route.dashboardScore = scorePanel
  scorePanel.title = label(scorePanel, "03 · ROUTEN-SCORE", "GameFontNormalSmall", GOLD); scorePanel.title:SetPoint("TOPLEFT", 12, -10)
  scorePanel.value = label(scorePanel, "--", "GameFontNormalHuge", GOLD); scorePanel.value:SetPoint("TOPLEFT", 14, -34); scorePanel.value:SetWidth(54); scorePanel.value:SetJustifyH("CENTER")
  scorePanel.route = label(scorePanel, "Aktive Route", "GameFontNormal", {0.94,0.78,0.30}); scorePanel.route:SetPoint("TOPLEFT", 78, -38); scorePanel.route:SetWidth(188); scorePanel.route:SetWordWrap(false)
  scorePanel.detail = label(scorePanel, "XP/min -- · Reise -- · Risiko --", "GameFontNormalSmall", {0.62,0.78,0.96}); scorePanel.detail:SetPoint("TOPLEFT", 78, -60); scorePanel.detail:SetWidth(188); scorePanel.detail:SetWordWrap(true)
  scorePanel.bar = CreateFrame("StatusBar", nil, scorePanel, "BackdropTemplate"); scorePanel.bar:SetPoint("BOTTOMLEFT", 78, 20); scorePanel.bar:SetSize(188, 8); scorePanel.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); scorePanel.bar:SetStatusBarColor(0.84,0.66,0.29,1); scorePanel.bar:SetMinMaxValues(0,100)
  scorePanel.source = label(scorePanel, "ForeverDB · Questlog · Livewerte", "GameFontNormalSmall", {0.55,0.78,0.62}); scorePanel.source:SetPoint("BOTTOMLEFT", 78, 4); scorePanel.source:SetWidth(188); scorePanel.source:SetWordWrap(false)

  -- Untere Dashboard-Reihe: dieselben Informationsbereiche wie im Mockup,
  -- aber kompakt genug für das echte WoW-Fenster.
  local xpPanel = panel(route, 18, -522, 282, 62); route.xpPanel = xpPanel
  xpPanel.title = label(xpPanel, "04 · XP / TTG", "GameFontNormalSmall", GOLD); xpPanel.title:SetPoint("TOPLEFT", 12, -8)
  xpPanel.value = label(xpPanel, "Questlog wird gelesen ...", "GameFontNormalSmall", {0.94,0.78,0.30}); xpPanel.value:SetPoint("TOPLEFT", 12, -27); xpPanel.value:SetWidth(258); xpPanel.value:SetWordWrap(false)
  xpPanel.detail = label(xpPanel, "XP/h und Level-Up-Zeit werden gemessen", "GameFontNormalSmall", {0.55,0.78,0.62}); xpPanel.detail:SetPoint("TOPLEFT", 12, -44); xpPanel.detail:SetWidth(258); xpPanel.detail:SetWordWrap(false)

  local mapPanel = panel(route, 319, -522, 282, 62); route.mapPanel = mapPanel
  mapPanel.title = label(mapPanel, "05 · MINIMAP-ROUTE", "GameFontNormalSmall", GOLD); mapPanel.title:SetPoint("TOPLEFT", 12, -8)
  mapPanel.value = label(mapPanel, "Zielmarker wird gesetzt ...", "GameFontNormalSmall", {0.94,0.78,0.30}); mapPanel.value:SetPoint("TOPLEFT", 12, -27); mapPanel.value:SetWidth(258); mapPanel.value:SetWordWrap(false)
  mapPanel.detail = label(mapPanel, "Linie und kommende Ziele werden aktualisiert", "GameFontNormalSmall", {0.55,0.78,0.62}); mapPanel.detail:SetPoint("TOPLEFT", 12, -44); mapPanel.detail:SetWidth(258); mapPanel.detail:SetWordWrap(false)

  local dataPanel = panel(route, 620, -522, 282, 62); route.dataPanel = dataPanel
  dataPanel.title = label(dataPanel, "06 · DATENSTATUS", "GameFontNormalSmall", GOLD); dataPanel.title:SetPoint("TOPLEFT", 12, -8)
  dataPanel.value = label(dataPanel, "ForeverDB · Questlog", "GameFontNormalSmall", {0.94,0.78,0.30}); dataPanel.value:SetPoint("TOPLEFT", 12, -27); dataPanel.value:SetWidth(258); dataPanel.value:SetWordWrap(false)
  dataPanel.detail = label(dataPanel, "Datenquelle wird geprüft ...", "GameFontNormalSmall", {0.55,0.78,0.62}); dataPanel.detail:SetPoint("TOPLEFT", 12, -44); dataPanel.detail:SetWidth(258); dataPanel.detail:SetWordWrap(false)

  route.sessionInfo = label(route, "", "GameFontNormalSmall", {0.55,0.78,0.62}); route.sessionInfo:Hide()
  route.layerInfo = label(route, "", "GameFontNormalSmall", {0.62,0.68,0.78}); route.layerInfo:Hide()

  local fast = CreateFrame("Frame", nil, content); fast:SetAllPoints(); f.views.fast = fast
  fast.heading = label(fast, "Schnell leveln", "GameFontNormalLarge", GOLD); fast.heading:SetPoint("TOPLEFT", 20, -18)
  fast.summary = label(fast, "Questdaten werden bewertet ...", "GameFontNormal", {0.75,0.78,0.86}); fast.summary:SetPoint("TOPLEFT", 20, -48); fast.summary:SetWidth(880); fast.summary:SetWordWrap(false)
  fast.strategy = label(fast, "", "GameFontNormalSmall", {0.55,0.78,0.62}); fast.strategy:SetPoint("TOPLEFT", 20, -72); fast.strategy:SetWidth(700); fast.strategy:SetWordWrap(false)
  fast.refresh = button(fast, "Route neu berechnen", 150, 28); fast.refresh:SetPoint("TOPRIGHT", -20, -18); fast.refresh:SetScript("OnClick", function() NS:InvalidateFastRoute(); NS:Refresh() end)
  fast.activate = button(fast, "Schnellmodus aktivieren", 190, 30); fast.activate:SetPoint("TOPLEFT", 20, -92); fast.activate:SetScript("OnClick", function() NS:SetFastRouteActive(not NS:IsFastRouteActive()) end)
  fast.list = panel(fast, 20, -136, 360, 410)
  fast.detail = panel(fast, 394, -136, 570, 410)
  fast.detailTitle = label(fast.detail, "Berechnete Solo-Route", "GameFontNormalLarge", GOLD); fast.detailTitle:SetPoint("TOPLEFT", 18, -18); fast.detailTitle:SetWidth(525)
  fast.detailText = label(fast.detail, "Wähle links einen Schritt.", "GameFontNormal", {0.82,0.84,0.90}); fast.detailText:SetPoint("TOPLEFT", 18, -58); fast.detailText:SetWidth(525); fast.detailText:SetHeight(200); fast.detailText:SetWordWrap(true)
  fast.detailSource = label(fast.detail, "", "GameFontNormalSmall", {0.55,0.78,0.62}); fast.detailSource:SetPoint("TOPLEFT", 18, -282); fast.detailSource:SetWidth(525); fast.detailSource:SetWordWrap(true)
  fast.note = label(fast.detail, "Die Reihenfolge ist eine Live-Berechnung. Exakte Quest-XP wird verwendet, sobald sie im Questlog oder in deinen Messwerten bekannt ist; sonst bleibt die Schätzung gekennzeichnet.", "GameFontNormalSmall", {0.62,0.68,0.78}); fast.note:SetPoint("BOTTOMLEFT", 18, 16); fast.note:SetWidth(525); fast.note:SetWordWrap(true)

  local gear = CreateFrame("Frame", nil, content); gear:SetAllPoints(); f.views.gear = gear
  gear.heading = label(gear, "Gear & Rewards", "GameFontNormalLarge", GOLD); gear.heading:SetPoint("TOPLEFT", 20, -18)
  gear.summary = label(gear, "", "GameFontNormal", {0.75,0.78,0.86}); gear.summary:SetPoint("TOPLEFT", 20, -48); gear.summary:SetWidth(700); gear.summary:SetWordWrap(true)
  gear.role = label(gear, "", "GameFontNormalSmall", {0.55,0.78,0.62}); gear.role:SetPoint("TOPLEFT", 20, -74); gear.role:SetWidth(700)
  gear.equipment = panel(gear, 20, -96, 340, 310)
  gear.rewards = panel(gear, 374, -96, 340, 310)
  gear.refresh = button(gear, "Itemdaten neu laden", 150, 28); gear.refresh:SetPoint("TOPLEFT", 20, -420); gear.refresh:SetScript("OnClick", function() NS:InvalidateGearCache(); NS:Refresh() end)
  gear.note = label(gear, "Der Vergleich wartet auf vollständig geladene Itemdaten und bleibt eine Stat-Heuristik.", "GameFontNormalSmall", {0.55,0.60,0.70}); gear.note:SetPoint("TOPLEFT", 184, -426); gear.note:SetWidth(520); gear.note:SetWordWrap(true)

  local dungeon = CreateFrame("Frame", nil, content); dungeon:SetAllPoints(); f.views.dungeon = dungeon
  dungeon.heading = label(dungeon, "Dungeon-Route", "GameFontNormalLarge", GOLD); dungeon.heading:SetPoint("TOPLEFT", 20, -18)
  dungeon.info = label(dungeon, "", "GameFontNormal", {0.75,0.78,0.86}); dungeon.info:SetPoint("TOPLEFT", 20, -48); dungeon.info:SetWidth(670); dungeon.info:SetWordWrap(true)
  dungeon.list = panel(dungeon, 20, -86, 670, 245)

  local class = CreateFrame("Frame", nil, content); class:SetAllPoints(); f.views.class = class
  class.heading = label(class, "Klassenprofil", "GameFontNormalLarge", GOLD); class.heading:SetPoint("TOPLEFT", 20, -18)
  class.text = label(class, "", "GameFontNormal", {0.82,0.84,0.90}); class.text:SetPoint("TOPLEFT", 20, -58); class.text:SetWidth(665); class.text:SetHeight(220); class.text:SetJustifyH("LEFT"); class.text:SetWordWrap(true)

  local settings = CreateFrame("Frame", nil, content); settings:SetAllPoints(); f.views.settings = settings
  settings.heading = label(settings, "Route konfigurieren", "GameFontNormalLarge", GOLD); settings.heading:SetPoint("TOPLEFT", 20, -18)
  settings.info = label(settings, "Modus und Fraktion ändern den aktiven Guide. Der Fortschritt des aktuellen Modus wird auf Schritt 1 gesetzt.", "GameFontNormal", {0.75,0.78,0.86}); settings.info:SetPoint("TOPLEFT", 20, -50); settings.info:SetWidth(660); settings.info:SetWordWrap(true)
  settings.info:SetText("Die Route läuft automatisch. Hier bleiben nur die Schalter, die du im Spiel wirklich brauchst.")
  local routeLabel = label(settings, "ROUTE", "GameFontNormal", GOLD); routeLabel:SetPoint("TOPLEFT", 20, -98)
  local solo = button(settings, "Solo / Quests", 145, 28); solo:SetPoint("TOPLEFT", 20, -120); solo:SetScript("OnClick", function() NS:SetMode("speed"); NS:ShowTab("route") end)
  local dungeonMode = button(settings, "Dungeon", 145, 28); dungeonMode:SetPoint("TOPLEFT", 175, -120); dungeonMode:SetScript("OnClick", function() NS:SetMode("dungeon"); NS:ShowTab("dungeon") end)
  local scan = button(settings, "Jetzt analysieren", 170, 30); scan:SetPoint("TOPLEFT", 20, -164); scan:SetScript("OnClick", function() NS:AutoScan(true); NS:ShowTab("route") end)
  local reset = button(settings, "Fortschritt zurücksetzen", 190, 30); reset:SetPoint("TOPLEFT", 200, -164); reset:SetScript("OnClick", function() NS:ResetProgress() end)
  settings.scanHint = label(settings, "Questlog-Scan: beim Login und automatisch alle 5 Minuten.", "GameFontNormalSmall", {0.55,0.60,0.70}); settings.scanHint:SetPoint("TOPLEFT", 20, -202); settings.scanHint:SetWidth(500)

  local hudLabel = label(settings, "HUD", "GameFontNormal", GOLD); hudLabel:SetPoint("TOPLEFT", 20, -238)
  local navigation = button(settings, "Navigation", 135, 28); navigation:SetPoint("TOPLEFT", 20, -260); navigation:SetScript("OnClick", function() NS:ToggleNavigation() end); settings.navigationButton=navigation
  local tracker = button(settings, "Questtracker", 135, 28); tracker:SetPoint("TOPLEFT", 165, -260); tracker:SetScript("OnClick", function() if NS.tracker then NS.tracker:SetShown(not NS.tracker:IsShown()) end end)
  local collapse = button(settings, "Tracker einklappen", 145, 28); collapse:SetPoint("TOPLEFT", 310, -260); collapse:SetScript("OnClick", function() NS:ToggleTrackerCollapsed() end)
  local trackerDown = button(settings, "Tracker −", 78, 26); trackerDown:SetPoint("TOPLEFT", 20, -300); trackerDown:SetScript("OnClick", function() NS:SetTrackerScale(-0.1) end)
  local trackerUp = button(settings, "Tracker +", 78, 26); trackerUp:SetPoint("TOPLEFT", 104, -300); trackerUp:SetScript("OnClick", function() NS:SetTrackerScale(0.1) end)
  local arrowSizeDown = button(settings, "Pfeil −", 78, 26); arrowSizeDown:SetPoint("TOPLEFT", 210, -300); arrowSizeDown:SetScript("OnClick", function() NS:SetArrowScale(-0.1) end)
  local arrowSizeUp = button(settings, "Pfeil +", 78, 26); arrowSizeUp:SetPoint("TOPLEFT", 294, -300); arrowSizeUp:SetScript("OnClick", function() NS:SetArrowScale(0.1) end)
  local opacity = button(settings, "Transparenz", 120, 26); opacity:SetPoint("TOPLEFT", 400, -300); opacity:SetScript("OnClick", function() NS:CycleOpacity() end); settings.opacityButton = opacity
  local lock = button(settings, "UI sperren", 112, 26); lock:SetPoint("TOPLEFT", 20, -336); lock:SetScript("OnClick", function() NS:SetFrameLock() end); settings.lockButton = lock
  local font = button(settings, "Schriftgröße", 112, 26); font:SetPoint("TOPLEFT", 140, -336); font:SetScript("OnClick", function() NS:CycleFontScale() end); settings.fontButton = font
  local arrowColor = button(settings, "Pfeilfarbe", 100, 26); arrowColor:SetPoint("TOPLEFT", 260, -336); arrowColor:SetScript("OnClick", function() NS:CycleArrowColor() end)
  local arrowStyle = button(settings, "Pfeilstil", 92, 26); arrowStyle:SetPoint("TOPLEFT", 368, -336); arrowStyle:SetScript("OnClick", function() NS:CycleArrowStyle() end)

  local supportLabel = label(settings, "STATUS & SUPPORT", "GameFontNormal", GOLD); supportLabel:SetPoint("TOPLEFT", 20, -382)
  local diagnostics = button(settings, "Fehlerbericht", 130, 26); diagnostics:SetPoint("TOPLEFT", 20, -404); diagnostics:SetScript("OnClick", function() NS:ShowDiagnostics() end)
  local dataStatus = button(settings, "Datenstatus", 112, 26); dataStatus:SetPoint("TOPLEFT", 160, -404); dataStatus:SetScript("OnClick", function() NS:PrintDataStatus() end)
  settings.dataInfo = label(settings, NS.GetOpenDataSummary and NS:GetOpenDataSummary() or "Offene Daten werden geladen.", "GameFontNormalSmall", {0.55,0.60,0.70}); settings.dataInfo:SetPoint("TOPLEFT", 20, -444); settings.dataInfo:SetWidth(850); settings.dataInfo:SetWordWrap(true)
  settings.dbInfo = label(settings, NS.GetForeverDBOverview and NS:GetForeverDBOverview() or "ForeverDB-Zusatzdaten werden geladen.", "GameFontNormalSmall", {0.48,0.78,0.60}); settings.dbInfo:SetPoint("TOPLEFT", 20, -466); settings.dbInfo:SetWidth(850); settings.dbInfo:SetWordWrap(true)
  settings.sourceInfo = label(settings, "Quellen: ForeverDB.net · QuestieDB-Forever · Evergreen for WoW Forever\nDer ForeverDB-API-Schlüssel ist nicht im Addon enthalten.", "GameFontNormalSmall", {0.62,0.68,0.78}); settings.sourceInfo:SetPoint("TOPLEFT", 20, -492); settings.sourceInfo:SetWidth(850); settings.sourceInfo:SetWordWrap(true)

  for key, t in pairs(f.tabs) do t:SetScript("OnClick", function() NS:ShowTab(key) end) end
  self.frame = f; self:RestoreFramePosition(f, "main", "CENTER", UIParent, 0, 0); self:ShowTab("route"); self:Refresh()
end

function NS:CycleOpacity()
  self:EnsureSettings(); local values = {0.78, 0.88, 0.96}; local current = self.db.ui.opacity or 0.96; local nextValue = values[1]
  for index, value in ipairs(values) do if math.abs(current - value) < 0.03 then nextValue = values[index % #values + 1]; break end end
  self.db.ui.opacity = nextValue; if self.tracker then self:ApplyTrackerSettings() end; if self.navigationFrame then self:RefreshNavigation() end; self:Refresh()
end

function NS:CycleFontScale()
  self:EnsureSettings(); local values = {0.9, 1.0, 1.1, 1.2}; local current = self.db.ui.fontScale or 1; local nextValue = values[1]
  for index, value in ipairs(values) do if math.abs(current - value) < 0.03 then nextValue = values[index % #values + 1]; break end end
  self.db.ui.fontScale = nextValue; if self.tracker then self:ApplyTrackerSettings() end; if self.navigationFrame then self:RefreshNavigation() end; self:Refresh()
end

function NS:ToggleMinimalMode()
  self:EnsureSettings(); self.db.ui.minimal = not self.db.ui.minimal; self:Refresh(); self:Print(self.db.ui.minimal and "Minimalmodus aktiviert." or "Minimalmodus deaktiviert.")
end
function NS:SetLayout(layout)
  self:EnsureSettings(); local ui=self.db.ui; ui.layout=layout
  if layout=="compact" then ui.streamer=false; ui.minimal=true; ui.trackerScale=0.85; ui.navigationScale=0.85; ui.fontScale=0.9
  elseif layout=="streamer" then ui.streamer=true; ui.minimal=true; ui.trackerScale=0.9; ui.navigationScale=0.9; ui.fontScale=1
  else ui.streamer=false; ui.minimal=false; ui.trackerScale=1; ui.navigationScale=1; ui.fontScale=1 end
  self:Refresh(); self:Print("Layout gespeichert: "..tostring(layout))
end
function NS:ToggleStreamerMode()
  self:EnsureSettings(); if self.db.ui.streamer then self:SetLayout("large") else self:SetLayout("streamer") end
end

function NS:RefreshSettings()
  if not self.frame or not self.frame.views.settings then return end
  self:EnsureSettings(); local view = self.frame.views.settings; local ui = self.db.ui
  if view.dataInfo then view.dataInfo:SetText(self.GetOpenDataSummary and self:GetOpenDataSummary() or "Offene Daten werden geladen.") end
  if view.dbInfo then view.dbInfo:SetText(self.GetForeverDBOverview and self:GetForeverDBOverview() or "ForeverDB-Zusatzdaten werden geladen.") end
  if view.opacityButton then view.opacityButton:SetText(string.format("Alpha %.0f%%", (ui.opacity or 0.96) * 100)) end
  if view.fontButton then view.fontButton:SetText(string.format("Schrift %.1fx", ui.fontScale or 1)) end
  if view.minimalButton then view.minimalButton:SetText(ui.minimal and "Minimal: AN" or "Minimal: AUS") end
  if view.lockButton then view.lockButton:SetText(ui.lockFrames and "UI entsperren" or "UI sperren") end
  if view.streamerButton then view.streamerButton:SetText(ui.streamer and "Streamer: AN" or "Streamer: AUS") end
  if view.navigationButton then view.navigationButton:SetText(self.db.navigation and self.db.navigation.show ~= false and "Navigation: AN" or "Navigation: AUS") end
  if view.mobPriorityButton then view.mobPriorityButton:SetText(self.db.navigation.mobPriority and "EP-Mob: AN" or "EP-Mob: AUS") end
  if view.layerHintsButton then view.layerHintsButton:SetText(ui.layerHints and "Layer: AN" or "Layer: AUS") end
end

function NS:ShowTab(name)
  if not self.frame then return end
  for key, view in pairs(self.frame.views) do view:SetShown(key == name) end
  for key, tab in pairs(self.frame.tabs) do tab:SetEnabled(key ~= name) end
  self.frame.activeTab = name; self:Refresh()
end

function NS:GetZoneProgress()
  local context=self.GetPlanningContext and self:GetPlanningContext() or {zone=self.GetPlayerZone and self:GetPlayerZone() or ""}
  local total,done=0,0
  for _,s in ipairs(self:GetSteps()) do
    local same=(s.mapID and context.mapID and s.mapID==context.mapID) or (s.zone and context.zone and string.find(string.lower(s.zone),string.lower(context.zone),1,true))
    if same then total=total+1; if self.db.completed[s.id] or (s.phase and self:IsPlannedStepComplete(s)) then done=done+1 end end
  end
  return context.mapName or context.zone or "Unbekannt",done,total
end
function NS:GetQuestChainSummary(step)
  if not step or not step.record then return "Questkette: keine Zusatzdaten" end
  local record=step.record; local previous,following={},{}
  for _,id in ipairs(type(record.chainPrevious)=="table" and record.chainPrevious or {}) do previous[#previous+1]=tostring(type(id)=="table" and id.questID or id) end
  for _,id in ipairs(type(record.chainNext)=="table" and record.chainNext or {}) do following[#following+1]=tostring(type(id)=="table" and id.questID or id) end
  local text="Questkette: "..(step.questID and ("#"..tostring(step.questID)) or "unbekannt")
  if #previous>0 then text=text.." · Vorher: "..table.concat(previous,",") end
  if #following>0 then text=text.." · Danach: "..table.concat(following,",") end
  local alternatives=self.GetRouteAlternatives and self:GetRouteAlternatives(step,2) or {}
  if alternatives[1] then text=text.."\nAlternative: "..alternatives[1].step.title end
  return text
end

function NS:RefreshRouteView()
  local f, steps, current = self.frame, self:GetSteps(), self:GetCurrentStep(); local view = f.views.route
  local p = self:GetClassProfile(); local doneCount = math.max(0, self.db.step - 1)
  local zoneName,zoneDone,zoneTotal=self:GetZoneProgress()
  view.status:SetText(string.format("%s  ·  %s  ·  %s  ·  Schritt %d/%d%s", self.modes[self.db.mode] or self.db.mode, self.db.route == "horde" and "Horde" or "Allianz", p.name, doneCount, #steps, self:IsFastRouteActive() and "  ·  SCHNELLROUTE" or ""))
  view.zoneInfo:SetText(string.format("Zone: %s · Fortschritt %d/%d · Alternativen und Folgequests werden dynamisch bewertet",zoneName,zoneDone,zoneTotal))
  view.progress:SetValue(#steps > 0 and doneCount / #steps or 0)
  if view.xpProjection and self.GetQuestLogProjection then
    local projection=self:GetQuestLogProjection(); view.xpProjection:SetText(string.format("Quest-Vorschau: %d XP (%d Quest%s) · Abgabe bereit: %d XP (%d fertig) · Vorschau %.0f%% · %s", projection.questLogXP or 0, projection.questLogCount or 0, (projection.questLogCount or 0) == 1 and "" or "s", projection.completedQuestXP or 0, projection.questCount or 0, (projection.questLogProjectedPercent or 0)*100, projection.ready and "LEVEL UP READY!" or "noch offen")); view.xpProjection:SetTextColor(projection.ready and 0.40 or 0.94, projection.ready and 1 or 0.78, projection.ready and 0.60 or 0.30)
  end
  if view.sessionInfo and self.GetSessionStats then
    local stats=self:GetSessionStats(); local ttg=stats.ttg and string.format("TTG %.0f Min.",stats.ttg/60) or "TTG wird gemessen"; local sessionText=string.format("XP/h %.0f · %s · Reise %.1f Min.",stats.movingXPPerHour or 0,ttg,(stats.travelSeconds or 0)/60)
    view.sessionInfo:SetText(sessionText)
    if view.xpPanel then
      local projection = self.GetQuestLogProjection and self:GetQuestLogProjection() or {}
      view.xpPanel.value:SetText(string.format("Questlog %d XP · %d Quest%s", projection.questLogXP or 0, projection.questLogCount or 0, (projection.questLogCount or 0) == 1 and "" or "s"))
      view.xpPanel.detail:SetText(sessionText)
    end
  end
  if view.layerInfo and self.GetLayerAdvice then view.layerInfo:SetText("Layer: " .. self:GetLayerAdvice().text .. " · Automatischer Wechsel nur über vorhandene ForeverGuild-Funktionen") end
  if view.dataPanel then
    local summary = self.GetOpenDataSummary and self:GetOpenDataSummary() or "Offene Daten werden geladen."
    local overview = self.GetForeverDBOverview and self:GetForeverDBOverview() or "ForeverDB-Zusatzdaten werden geladen."
    view.dataPanel.value:SetText("ForeverDB · Questlog · Livewerte")
    view.dataPanel.detail:SetText(summary:match("^[^·]+") or overview:match("^[^·]+") or "Datenstand verfügbar")
  end
  if current and view.navPanel then
    local nav = view.navPanel
    local waypoint = self.GetBestWaypoint and self:GetBestWaypoint(current) or nil
    local measurement = waypoint and self.GetNavigationMeasurement and self:GetNavigationMeasurement(waypoint) or nil
    nav.target:SetText(current.liveTitle or current.title or "Questziel")
    if measurement and measurement.worldDistance then
      nav.distance:SetText(string.format("%.0f m · ETA ~%s", measurement.worldDistance, measurement.eta and (math.floor(measurement.eta / 60) .. ":" .. string.format("%02d", measurement.eta % 60) .. " Min.") or "--"))
      nav.hint:SetText(measurement.sameMap and "Pfeil folgt deiner Blickrichtung" or "Gebietsrichtung wird berechnet")
    elseif measurement then
      nav.distance:SetText(string.format("%.0f%% Kartenstrecke", (measurement.fraction or 0) * 100))
      nav.hint:SetText(measurement.sameMap and "Pfeil folgt deiner Blickrichtung" or "Gebietsrichtung wird berechnet")
    else
      nav.distance:SetText("Zielkoordinaten werden geprüft")
      nav.hint:SetText("Route-Recovery aktiv")
    end
    if self.navigationAngle and nav.arrow.SetRotation then nav.arrow:SetRotation(self.navigationAngle - math.pi / 2) end
    if view.mapPanel then
      view.mapPanel.value:SetText("Zielmarker: " .. (measurement and "aktiv" or "prüfen"))
      view.mapPanel.detail:SetText(measurement and "Minimap-Linie und Folgeziele live" or "Für dieses Ziel fehlen Koordinaten")
    end
  end
  if current and view.dashboardTracker then
    local tracker = view.dashboardTracker
    local objective = self.GetTrackedObjective and self:GetTrackedObjective(current) or nil
    tracker.target:SetText(current.phase == "accept" and "Quest annehmen" or current.phase == "turnin" and "Quest abgeben" or (current.liveTitle or current.title or "Aktuelles Questziel"))
    tracker.body:SetText(objective and objective.text or "Ziele aus dem Questlog werden automatisch gelesen")
    if objective and objective.required and objective.required > 0 then
      tracker.progress:SetMinMaxValues(0, objective.required); tracker.progress:SetValue(math.min(objective.done or 0, objective.required)); tracker.status:SetText(string.format("Fortschritt %d/%d", objective.done or 0, objective.required))
    else
      tracker.progress:SetMinMaxValues(0, 1); tracker.progress:SetValue(0); tracker.status:SetText("Fortschritt wird aus dem Client gelesen")
    end
  end
  if current and view.dashboardScore then
    local scorePanel = view.dashboardScore
    local recommendation = self.GetRecommendations and self:GetRecommendations(1)[1]
    local score = recommendation and recommendation.score or current.priority or 0
    scorePanel.value:SetText(string.format("%.0f", score))
    scorePanel.route:SetText(recommendation and recommendation.step and recommendation.step.title or current.title or "Aktive Route")
    local components = recommendation and recommendation.components or {}
    scorePanel.detail:SetText(string.format("XP/min %.0f · Reise %.0f · Risiko %.0f", components.xpPerMinute or 0, components.travel or 0, components.risk or 0))
    scorePanel.bar:SetValue(math.max(0, math.min(100, score)))
  end
  if view.stepButtons then for _, b in ipairs(view.stepButtons) do b:Hide() end else view.stepButtons = {} end
  local displayLimit=math.min(#steps,10)
  for i=1,displayLimit do
    local s=steps[i]
    local b = view.stepButtons[i] or button(view.list, "", 340, 24); view.stepButtons[i] = b
    b:ClearAllPoints(); b:SetPoint("TOPLEFT", 10, -10 - (i-1)*26); local marker = self.db.completed[s.id] and "✓ " or (i == self.db.step and "▶ " or "· "); b:SetText(string.format("%s%d  %s", marker, s.level or 0, s.title)); b:SetShown(true)
    if self.db.completed[s.id] then buttonTextColor(b, 0.48, 0.78, 0.60) elseif i == self.db.step then buttonTextColor(b, unpack(GOLD)) else buttonTextColor(b, 0.78,0.80,0.86) end
    b:SetScript("OnClick", function() self.db.step = i; self.db.selectedStepID=s.id; self:Refresh() end)
    b:SetScript("OnEnter", function()
      if not GameTooltip then return end
      GameTooltip:SetOwner(b,"ANCHOR_RIGHT"); GameTooltip:AddLine(s.title or "Schritt",0.84,0.66,0.29)
      if s.questID then GameTooltip:AddLine("Quest-ID: "..tostring(s.questID),0.78,0.80,0.86) end
      if s.phase then GameTooltip:AddLine("Phase: "..tostring(s.phase),0.55,0.78,0.62) end
      if s.record and s.record.foreverDB then GameTooltip:AddLine("Quelle: ForeverDB.net",0.55,0.78,0.62) end
      GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
  end
  if not view.more then view.more=label(view.list,"","GameFontNormalSmall",{0.55,0.60,0.70}); view.more:SetPoint("BOTTOMLEFT",10,8); view.more:SetWidth(280) end
  view.more:SetText(#steps>displayLimit and string.format("+ %d weitere Schritte – Tracker zeigt das aktuelle Ziel",#steps-displayLimit) or "")
  if not current then view.detailTitle:SetText("Route abgeschlossen"); view.detailText:SetText("Wähle einen anderen Modus oder setze den Fortschritt zurück."); view.chainInfo:SetText(""); view.done:Disable(); view.skip:Disable(); return end
  view.done:Enable(); view.skip:Enable(); view.detailTitle:SetText(string.format("Stufe %s · %s", current.level or "–", current.title)); view.detailText:SetText((current.zone and ("Gebiet: " .. current.zone .. "\n\n") or "") .. self:GetCurrentBody(current)); view.chainInfo:SetText(self:GetQuestChainSummary(current))
end

function NS:RefreshFastView()
  local view = self.frame and self.frame.views.fast
  if not view or not self.GetFastLevelRoute then return end
  local rows, meta = self:GetFastLevelRoute(12)
  meta = meta or {}
  view.summary:SetText(string.format("Schnellste Solo-Vorschau · Stufe %d · %s · %d Questlog-Schritt%s", meta.level or 1, meta.zone or "Unbekannt", meta.activeCount or 0, (meta.activeCount or 0) == 1 and "" or "e"))
  view.strategy:SetText(self:IsFastRouteActive() and "Aktiv: der Haupttracker priorisiert diese Solo-Bewertung." or "Vorschau: der Haupttracker bleibt ausgewogen, bis du den Schnellmodus aktivierst.")
  view.activate:SetText(self:IsFastRouteActive() and "Schnellmodus deaktivieren" or "Schnellmodus aktivieren")
  if view.rows then for _, row in ipairs(view.rows) do row:Hide() end else view.rows = {} end
  for index, row in ipairs(rows or {}) do
    local step = row.step
    local buttonFrame = view.rows[index] or button(view.list, "", 340, 28); view.rows[index] = buttonFrame
    local marker = row.source == "Questlog" and "Q  " or "→  "
    local title = tostring(step.title or "Quest")
    if #title > 46 then title = title:sub(1, 43) .. "..." end
    buttonFrame:ClearAllPoints(); buttonFrame:SetPoint("TOPLEFT", 10, -10 - (index - 1) * 34); buttonFrame:SetText(string.format("%s%d  %s", marker, step.level or 0, title)); buttonFrame:Show()
    if row.source == "Questlog" then buttonTextColor(buttonFrame, 0.48, 0.78, 0.60) else buttonTextColor(buttonFrame, unpack(GOLD)) end
    buttonFrame:SetScript("OnClick", function() self.db.fastSelected = index; self:Refresh() end)
    buttonFrame:SetScript("OnEnter", function()
      if not GameTooltip then return end
      GameTooltip:SetOwner(buttonFrame, "ANCHOR_RIGHT"); GameTooltip:AddLine(step.title or "Quest", 0.84, 0.66, 0.29)
      GameTooltip:AddLine(string.format("Score: %.0f · Quelle: %s", row.score or 0, row.source or "Berechnung"), 0.78, 0.80, 0.86)
      GameTooltip:Show()
    end)
    buttonFrame:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
  end
  local selected = rows and rows[self.db.fastSelected or 1] or nil
  if not selected then
    view.detailTitle:SetText("Keine passende Soloquest gefunden")
    view.detailText:SetText("Questlog öffnen oder Datenstatus prüfen. Sobald verfügbare Quests erkannt werden, wird hier die Reihenfolge nachgerechnet.")
    view.detailSource:SetText("")
    return
  end
  local step, detail = selected.step, selected.detail or {}
  view.detailTitle:SetText(string.format("%s · Score %.0f", step.title or "Quest", selected.score or 0))
  local components = detail.components or {}
  local waypoint = self.GetBestWaypoint and self:GetBestWaypoint(step) or nil
  local destination = waypoint and string.format("%s · %.1f / %.1f", waypoint.name or "Ziel", waypoint.x or 0, waypoint.y or 0) or "Koordinaten werden aus Questlog/Quellen geprüft"
  local reasons = detail.reasons and #detail.reasons > 0 and table.concat(detail.reasons, " · ") or "Level- und Zonenscore"
  view.detailText:SetText(string.format("Gebiet: %s\n\nNächster Schritt: %s\n\nZiel: %s\n\nBewertung: XP %+.0f · Level %+.0f · Zone %+.0f · Kette %+.0f · Reise -%.0f\n\nWarum: %s", step.zone or "Unbekannt", step.phase == "accept" and "Quest annehmen" or "Quest fortsetzen", destination, components.xp or 0, components.level or 0, components.zone or 0, components.chain or 0, components.travel or 0, reasons))
  view.detailSource:SetText(string.format("Quest-ID: %s · %s · %s", tostring(step.questID or "?"), selected.source or "Berechnung", detail.estimated and "XP geschätzt" or "XP bekannt / gemessen"))
end

function NS:RefreshGearView()
  local view=self.frame and self.frame.views.gear; if not view then return end
  local summary=self.GetEquipmentSummary and self:GetEquipmentSummary() or {average=0,weakSlots=0,pending=0,state="unbekannt"}
  view.summary:SetText(string.format("Durchschnittliches Itemlevel: %.0f · Status: %s · Leere Plätze: %d · Wartende Itemdaten: %d",summary.average or 0,summary.state or "unbekannt",summary.weakSlots or 0,summary.pending or 0))
  view.role:SetText("Profil: "..(self.GetGearRole and self:GetGearRole() or "AUTO").." · Waffen werden stärker gewichtet; Tank/Heiler/DPS/Solo getrennt bewertet.")
  if view.equipment.rows then for _, row in ipairs(view.equipment.rows) do row:Hide() end else view.equipment.rows={} end
  for i,r in ipairs(self.GetEquipmentRows and self:GetEquipmentRows() or {}) do
    local row=view.equipment.rows[i] or label(view.equipment,"","GameFontNormalSmall",{0.78,0.80,0.86}); view.equipment.rows[i]=row
    row:SetPoint("TOPLEFT",12,-12-(i-1)*16); row:SetWidth(315); row:SetWordWrap(false); row:SetText(string.format("%-10s  %s",r.label or "Slot",r.item and string.format("%s (%.0f)",r.item.name or "Item",r.score or 0) or (r.status or "unbekannt"))); row:Show()
  end
  local comparison=self.GetRewardComparison and self:GetRewardComparison() or {rows={},advice="Belohnungsdaten nicht verfügbar."}
  view.rewards.advice=view.rewards.advice or label(view.rewards,"","GameFontNormal",GOLD); view.rewards.advice:SetPoint("TOPLEFT",12,-14); view.rewards.advice:SetWidth(315); view.rewards.advice:SetWordWrap(true); view.rewards.advice:SetText(comparison.advice or "Keine Auswahlbelohnung geöffnet.")
  if view.rewards.rows then for _, row in ipairs(view.rewards.rows) do row:Hide() end else view.rewards.rows={} end
  for i,r in ipairs(comparison.rows or {}) do
    local row=view.rewards.rows[i] or label(view.rewards,"","GameFontNormalSmall",{0.78,0.80,0.86}); view.rewards.rows[i]=row
    row:SetPoint("TOPLEFT",12,-56-(i-1)*24); row:SetWidth(315); row:SetWordWrap(true); row:SetText(string.format("%s  %s",r.name or "Belohnung",r.delta and string.format("%+.1f",r.delta) or (r.status or "lädt"))); row:Show()
  end
end

function NS:RefreshUI()
  if not self.db or not self.frame then return end
  local active = self.frame.activeTab or "route"
  if active == "route" then self:RefreshRouteView()
  elseif active == "fast" then self:RefreshFastView()
  elseif active == "gear" then self:RefreshGearView()
  elseif active == "class" then
    local p = self:GetClassProfile() or {}
    local _, token = UnitClass and UnitClass("player")
    local level = self.GetPlayerLevel and self:GetPlayerLevel() or (UnitLevel and UnitLevel("player")) or "?"
    local extra = self.GetForeverDBOverview and ("\n\n" .. self:GetForeverDBOverview()) or ""
    self.frame.views.class.text:SetText(string.format("Erkannt: %s · Stufe %s\nProfil: %s · %s\nGeschwindigkeit: %s · Rolle: %s\n\n%s\n\nKlassenquests, Trainer und Berufe werden nur eingeplant, wenn der Client dafür einen passenden Datenpunkt liefert. Fehlt ein Punkt, bleibt die Route unverändert und zeigt das transparent an.%s", p.name or token or "Unbekannt", level, p.spec or "flexibel", token or "UNKNOWN", p.speed or "?", p.role or "flexibel", p.note or "Keine Profilnotiz verfügbar.", extra))
  elseif active == "dungeon" then
    local route = self.routes[self.db.route] or self.routes.alliance; local d = route.dungeon or {}
    local best, bestScore
    if self.GetBestDungeon then best, bestScore = self:GetBestDungeon() end
    local bestText = best and string.format("Beste Instanz jetzt: %s (Score %.0f). Dungeon-Loot-Bonus wird nur heuristisch aus Level, Gruppe, Rolle und Ausrüstungszustand geschätzt.", best.name, bestScore or 0) or "Keine passende Instanz gefunden."
    self.frame.views.dungeon.info:SetText(bestText .. "\nEinmalige Dungeonquests zuerst sammeln; Wiederholungen nur bei stabiler Gruppe.")
    if self.frame.views.dungeon.buttons then for _, b in ipairs(self.frame.views.dungeon.buttons) do b:Hide() end else self.frame.views.dungeon.buttons = {} end
    for i, s in ipairs(d) do local b = self.frame.views.dungeon.buttons[i] or button(self.frame.views.dungeon.list, "", 640, 24); self.frame.views.dungeon.buttons[i] = b; b:ClearAllPoints(); b:SetPoint("TOPLEFT", 12, -10-(i-1)*26); local marker = self.db.completed[s.id] and "✓ " or (i == self.db.step and "▶ " or "· "); b:SetText(string.format("%s%d  %s", marker, s.level or 0, s.title)); b:SetShown(true); b:SetScript("OnClick", function() self:SetMode("dungeon"); self.db.step=i; self:Refresh() end) end
  end
  self:RefreshSettings()
end
function NS:Toggle() if not self.frame then self:CreateUI() end; self.frame:SetShown(not self.frame:IsShown()) end
