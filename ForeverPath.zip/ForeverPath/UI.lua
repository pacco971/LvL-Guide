local NS = ForeverPath

local GOLD, BLUE, DARK = {0.84, 0.66, 0.29}, {0.20, 0.55, 0.85}, {0.055, 0.065, 0.09}
local function button(parent, text, width, height)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetText(text); b:SetSize(width or 100, height or 24); return b
end
local function label(parent, text, size, color)
  local t = parent:CreateFontString(nil, "OVERLAY", size or "GameFontNormal")
  t:SetText(text); if color then t:SetTextColor(unpack(color)) end; return t
end
local function panel(parent, x, y, w, h)
  local p = CreateFrame("Frame", nil, parent, "BackdropTemplate")
  p:SetPoint("TOPLEFT", x, y); p:SetSize(w, h)
  p:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=12, insets={left=3,right=3,top=3,bottom=3}})
  p:SetBackdropColor(unpack(DARK)); p:SetBackdropBorderColor(0.22, 0.25, 0.34, 1); return p
end

function NS:CreateUI()
  local f = CreateFrame("Frame", "ForeverPathFrame", UIParent, "BackdropTemplate")
  f:SetSize(760, 500); f:SetPoint("CENTER"); f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
  f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", edgeSize=24, insets={left=8,right=8,top=8,bottom=8}})
  f:SetBackdropColor(0.035, 0.045, 0.07, 0.98)
  local title = label(f, "FOREVERPATH", "GameFontNormalLarge", GOLD); title:SetPoint("TOPLEFT", 24, -20)
  local subtitle = label(f, "Deine Route. Dein Tempo. Deine Entscheidung.", "GameFontNormalSmall", {0.55,0.60,0.70}); subtitle:SetPoint("TOPLEFT", 25, -42)
  local close = button(f, "X", 28, 24); close:SetPoint("TOPRIGHT", -18, -18); close:SetScript("OnClick", function() f:Hide() end)
  f.tabs, f.views = {}, {}
  local tabNames = { {"route", "Route"}, {"dungeon", "Dungeons"}, {"class", "Klasse"}, {"settings", "Einstellungen"} }
  for i, info in ipairs(tabNames) do
    local t = button(f, info[2], 115, 28); t:SetPoint("TOPLEFT", 22 + (i-1)*119, -62); f.tabs[info[1]] = t
  end
  local content = panel(f, 18, -98, 724, 375); f.content = content

  local route = CreateFrame("Frame", nil, content); route:SetAllPoints(); f.views.route = route
  local status = label(route, "", "GameFontNormal", GOLD); status:SetPoint("TOPLEFT", 18, -18); route.status = status
  local bar = CreateFrame("StatusBar", nil, route, "BackdropTemplate"); bar:SetSize(684, 12); bar:SetPoint("TOPLEFT", 18, -46); bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); bar:SetStatusBarColor(unpack(BLUE)); bar:SetMinMaxValues(0, 1); route.progress = bar
  local list = panel(route, 18, -70, 300, 285); route.list = list
  local detail = panel(route, 330, -70, 376, 285); route.detail = detail
  route.detailTitle = label(detail, "", "GameFontNormalLarge", GOLD); route.detailTitle:SetPoint("TOPLEFT", 18, -18); route.detailTitle:SetWidth(340); route.detailTitle:SetJustifyH("LEFT")
  route.detailText = label(detail, "", "GameFontNormal", {0.82,0.84,0.90}); route.detailText:SetPoint("TOPLEFT", 18, -58); route.detailText:SetWidth(335); route.detailText:SetHeight(130); route.detailText:SetJustifyH("LEFT"); route.detailText:SetWordWrap(true)
  local done = button(detail, "Schritt erledigt", 145, 28); done:SetPoint("BOTTOMLEFT", 18, 16); done:SetScript("OnClick", function() NS:CompleteCurrent() end); route.done = done
  local wp = button(detail, "Wegpunkt", 105, 28); wp:SetPoint("BOTTOMRIGHT", -18, 16); wp:SetScript("OnClick", function() if not NS:SetBestWaypoint(NS:GetCurrentStep()) then NS:Print("Für diesen Schritt ist kein Wegpunkt verfügbar.") end end)

  local dungeon = CreateFrame("Frame", nil, content); dungeon:SetAllPoints(); f.views.dungeon = dungeon
  dungeon.heading = label(dungeon, "Dungeon-Route", "GameFontNormalLarge", GOLD); dungeon.heading:SetPoint("TOPLEFT", 20, -18)
  dungeon.info = label(dungeon, "", "GameFontNormal", {0.75,0.78,0.86}); dungeon.info:SetPoint("TOPLEFT", 20, -48); dungeon.info:SetWidth(670); dungeon.info:SetWordWrap(true)
  dungeon.list = panel(dungeon, 20, -86, 670, 245)

  local class = CreateFrame("Frame", nil, content); class:SetAllPoints(); f.views.class = class
  class.heading = label(class, "Klassenprofil", "GameFontNormalLarge", GOLD); class.heading:SetPoint("TOPLEFT", 20, -18)
  class.text = label(class, "", "GameFontNormal", {0.82,0.84,0.90}); class.text:SetPoint("TOPLEFT", 20, -58); class.text:SetWidth(665); class.text:SetHeight(220); class.text:SetJustifyH("LEFT"); class.text:SetWordWrap(true)

  local settings = CreateFrame("Frame", nil, content); settings:SetAllPoints(); f.views.settings = settings
  settings.heading = label(settings, "Route konfigurieren", "GameFontNormalLarge", GOLD); settings.heading:SetPoint("TOPLEFT", 20, -18)
  settings.info = label(settings, "Modus und Fraktion ändern den aktiven Guide. Der Fortschritt des aktuellen Modus wird auf Schritt 1 gesetzt.", "GameFontNormal", {0.75,0.78,0.86}); settings.info:SetPoint("TOPLEFT", 20, -50); settings.info:SetWidth(660); settings.info:SetWordWrap(true)
  local modeLabel = label(settings, "Modus", "GameFontNormal", GOLD); modeLabel:SetPoint("TOPLEFT", 20, -98)
  for i, mode in ipairs({"speed", "dungeon", "discovery", "legacy"}) do
    local b = button(settings, NS.modes[mode], 145, 28); b:SetPoint("TOPLEFT", 20 + ((i-1)%2)*160, -120 - math.floor((i-1)/2)*36); b:SetScript("OnClick", function() NS:SetMode(mode); NS:ShowTab("route") end)
  end
  local routeLabel = label(settings, "Fraktion", "GameFontNormal", GOLD); routeLabel:SetPoint("TOPLEFT", 360, -98)
  local a = button(settings, "Allianz", 120, 28); a:SetPoint("TOPLEFT", 360, -120); a:SetScript("OnClick", function() NS.db.route, NS.db.step = "alliance", 1; NS:Refresh(); NS:ShowTab("route") end)
  local h = button(settings, "Horde", 120, 28); h:SetPoint("TOPLEFT", 490, -120); h:SetScript("OnClick", function() NS.db.route, NS.db.step = "horde", 1; NS:Refresh(); NS:ShowTab("route") end)
  local reset = button(settings, "Fortschritt zurücksetzen", 170, 28); reset:SetPoint("TOPLEFT", 360, -170); reset:SetScript("OnClick", function() NS:ResetProgress() end)
  local scan = button(settings, "Jetzt analysieren", 170, 30); scan:SetPoint("TOPLEFT", 360, -210); scan:SetScript("OnClick", function() NS:AutoScan(true); NS:ShowTab("route") end)
  local tracker = button(settings, "Tracker umschalten", 170, 30); tracker:SetPoint("TOPLEFT", 360, -250); tracker:SetScript("OnClick", function() if NS.tracker then NS.tracker:SetShown(not NS.tracker:IsShown()) end end)
  settings.scanHint = label(settings, "Automatischer Scan: beim Login und alle 5 Minuten.", "GameFontNormalSmall", {0.55,0.60,0.70}); settings.scanHint:SetPoint("TOPLEFT", 20, -220); settings.scanHint:SetWidth(300); settings.scanHint:SetJustifyH("LEFT")
  settings.dataInfo = label(settings, NS.GetOpenDataSummary and NS:GetOpenDataSummary() or "Offene Daten werden geladen.", "GameFontNormalSmall", {0.55,0.60,0.70}); settings.dataInfo:SetPoint("TOPLEFT", 20, -292); settings.dataInfo:SetWidth(680); settings.dataInfo:SetWordWrap(true)
  settings.sourceInfo = label(settings, "Quellen: QuestieDB-Forever · Evergreen for WoW Forever\nOptionaler ForeverDB-Import: https://foreverdb.net · Datenquelle wird sichtbar genannt", "GameFontNormalSmall", {0.62,0.68,0.78}); settings.sourceInfo:SetPoint("TOPLEFT", 20, -326); settings.sourceInfo:SetWidth(680); settings.sourceInfo:SetWordWrap(true)

  for key, t in pairs(f.tabs) do t:SetScript("OnClick", function() NS:ShowTab(key) end) end
  self.frame = f; self:ShowTab("route"); self:Refresh()
end

function NS:ShowTab(name)
  if not self.frame then return end
  for key, view in pairs(self.frame.views) do view:SetShown(key == name) end
  for key, tab in pairs(self.frame.tabs) do tab:SetEnabled(key ~= name) end
  self.frame.activeTab = name; self:Refresh()
end

function NS:RefreshRouteView()
  local f, steps, current = self.frame, self:GetSteps(), self:GetCurrentStep(); local view = f.views.route
  local p = self:GetClassProfile(); local doneCount = math.max(0, self.db.step - 1)
  view.status:SetText(string.format("%s  ·  %s  ·  %s  ·  Schritt %d/%d", self.modes[self.db.mode] or self.db.mode, self.db.route == "horde" and "Horde" or "Allianz", p.name, doneCount, #steps))
  view.progress:SetValue(#steps > 0 and doneCount / #steps or 0)
  if view.stepButtons then for _, b in ipairs(view.stepButtons) do b:Hide() end else view.stepButtons = {} end
  for i, s in ipairs(steps) do
    local b = view.stepButtons[i] or button(view.list, "", 280, 24); view.stepButtons[i] = b
    b:ClearAllPoints(); b:SetPoint("TOPLEFT", 10, -10 - (i-1)*26); b:SetText(string.format("%s%d  %s", i == self.db.step and "▶ " or "  ", s.level or 0, s.title)); b:SetShown(true)
    if i == self.db.step then b:SetTextColor(unpack(GOLD)) else b:SetTextColor(0.78,0.80,0.86) end
    b:SetScript("OnClick", function() self.db.step = i; self:Refresh() end)
  end
  if not current then view.detailTitle:SetText("Route abgeschlossen"); view.detailText:SetText("Wähle einen anderen Modus oder setze den Fortschritt zurück."); view.done:Disable(); return end
  view.done:Enable(); view.detailTitle:SetText(string.format("Stufe %s · %s", current.level or "–", current.title)); view.detailText:SetText((current.zone and ("Gebiet: " .. current.zone .. "\n\n") or "") .. self:GetCurrentBody(current))
end

function NS:Refresh()
  if not self.db or not self.frame then return end
  local active = self.frame.activeTab or "route"
  if active == "route" then self:RefreshRouteView()
  elseif active == "class" then local p = self:GetClassProfile(); self.frame.views.class.text:SetText(string.format("Klasse: %s\nLevel-Spec: %s\nGeschwindigkeitsprofil: %s\nRolle: %s\n\n%s\n\nDie Route priorisiert kurze Reisewege, zusammenhängende Questhubs und passende Dungeonfenster.", p.name, p.spec, p.speed, p.role, p.note))
  elseif active == "dungeon" then local route = self.routes[self.db.route] or self.routes.alliance; local d = route.dungeon or {}; self.frame.views.dungeon.info:SetText("Dungeon-Schritte werden abhängig von Fraktion, Stufe und Klassenprofil angezeigt. Einmalige Dungeonquests zuerst sammeln; Wiederholungen nur bei guter Gruppe."); if self.frame.views.dungeon.buttons then for _, b in ipairs(self.frame.views.dungeon.buttons) do b:Hide() end else self.frame.views.dungeon.buttons = {} end; for i, s in ipairs(d) do local b = self.frame.views.dungeon.buttons[i] or button(self.frame.views.dungeon.list, "", 640, 24); self.frame.views.dungeon.buttons[i] = b; b:ClearAllPoints(); b:SetPoint("TOPLEFT", 12, -10-(i-1)*26); b:SetText(string.format("%s%d  %s", i == self.db.step and "▶ " or "  ", s.level or 0, s.title)); b:SetShown(true); b:SetScript("OnClick", function() self:SetMode("dungeon"); self.db.step=i; self:Refresh() end) end
  end
end
function NS:Toggle() if not self.frame then self:CreateUI() end; self.frame:SetShown(not self.frame:IsShown()) end
