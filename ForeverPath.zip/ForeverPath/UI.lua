local NS = ForeverPath

local GOLD, BLUE, DARK = {0.84, 0.66, 0.29}, {0.20, 0.55, 0.85}, {0.055, 0.065, 0.09}
local function button(parent, text, width, height)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetText(text); b:SetSize(width or 100, height or 24); return b
end
local function label(parent, text, size, color)
  local t = parent:CreateFontString(nil, "OVERLAY", size or "GameFontNormal")
  t:SetText(text); if color then t:SetTextColor(unpack(color)) end; return t
end
local function panel(parent, x, y, w, h)
  local p = CreateFrame("Frame", nil, parent, "BackdropTemplate")
  p:SetPoint("TOPLEFT", x, y); p:SetSize(w, h)
  p:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=12, insets={left=3,right=3,top=3,bottom=3}})
  p:SetBackdropColor(unpack(DARK)); p:SetBackdropBorderColor(0.22, 0.25, 0.34, 1); return p
end

function NS:CreateUI()
  local f = CreateFrame("Frame", "ForeverPathFrame", UIParent, "BackdropTemplate")
  f:SetSize(800, 625); f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", function() if not (NS.db and NS.db.ui and NS.db.ui.lockFrames) then f:StartMoving() end end); f:SetScript("OnDragStop", function() f:StopMovingOrSizing(); NS:SaveFramePosition(f, "main") end)
  f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", edgeSize=24, insets={left=8,right=8,top=8,bottom=8}})
  f:SetBackdropColor(0.035, 0.045, 0.07, 0.98)
  local title = label(f, "FOREVERPATH", "GameFontNormalLarge", GOLD); title:SetPoint("TOPLEFT", 24, -20)
  local subtitle = label(f, "Deine Route. Dein Tempo. Deine Entscheidung.", "GameFontNormalSmall", {0.55,0.60,0.70}); subtitle:SetPoint("TOPLEFT", 25, -42)
  local close = button(f, "X", 28, 24); close:SetPoint("TOPRIGHT", -18, -18); close:SetScript("OnClick", function() f:Hide() end)
  f.tabs, f.views = {}, {}
  local tabNames = { {"route", "Route"}, {"gear", "Gear & Rewards"}, {"dungeon", "Dungeons"}, {"class", "Klasse"}, {"settings", "Einstellungen"} }
  for i, info in ipairs(tabNames) do
    local t = button(f, info[2], i == 2 and 142 or 115, 28); t:SetPoint("TOPLEFT", 22 + (i-1)*119, -62); f.tabs[info[1]] = t
  end
  local content = panel(f, 18, -98, 764, 500); f.content = content

  local route = CreateFrame("Frame", nil, content); route:SetAllPoints(); f.views.route = route
  local status = label(route, "", "GameFontNormal", GOLD); status:SetPoint("TOPLEFT", 18, -18); route.status = status
  local bar = CreateFrame("StatusBar", nil, route, "BackdropTemplate"); bar:SetSize(684, 12); bar:SetPoint("TOPLEFT", 18, -46); bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); bar:SetStatusBarColor(unpack(BLUE)); bar:SetMinMaxValues(0, 1); route.progress = bar
  local list = panel(route, 18, -70, 300, 285); route.list = list
  local detail = panel(route, 330, -70, 376, 285); route.detail = detail
  route.detailTitle = label(detail, "", "GameFontNormalLarge", GOLD); route.detailTitle:SetPoint("TOPLEFT", 18, -18); route.detailTitle:SetWidth(340); route.detailTitle:SetJustifyH("LEFT")
  route.detailText = label(detail, "", "GameFontNormal", {0.82,0.84,0.90}); route.detailText:SetPoint("TOPLEFT", 18, -58); route.detailText:SetWidth(335); route.detailText:SetHeight(130); route.detailText:SetJustifyH("LEFT"); route.detailText:SetWordWrap(true)
  local done = button(detail, "Schritt erledigt", 145, 28); done:SetPoint("BOTTOMLEFT", 18, 16); done:SetScript("OnClick", function() NS:CompleteCurrent() end); route.done = done
  local skip = button(detail, "Überspringen", 110, 28); skip:SetPoint("BOTTOMLEFT", 174, 16); skip:SetScript("OnClick", function() NS:SkipCurrent() end); route.skip = skip
  local wp = button(detail, "Wegpunkt", 105, 28); wp:SetPoint("BOTTOMRIGHT", -18, 16); wp:SetScript("OnClick", function() if not NS:SetBestWaypoint(NS:GetCurrentStep()) then NS:Print("Für diesen Schritt ist kein Wegpunkt verfügbar.") end end)

  local gear = CreateFrame("Frame", nil, content); gear:SetAllPoints(); f.views.gear = gear
  gear.heading = label(gear, "Gear & Rewards", "GameFontNormalLarge", GOLD); gear.heading:SetPoint("TOPLEFT", 20, -18)
  gear.summary = label(gear, "", "GameFontNormal", {0.75,0.78,0.86}); gear.summary:SetPoint("TOPLEFT", 20, -48); gear.summary:SetWidth(700); gear.summary:SetWordWrap(true)
  gear.role = label(gear, "", "GameFontNormalSmall", {0.55,0.78,0.62}); gear.role:SetPoint("TOPLEFT", 20, -74); gear.role:SetWidth(700)
  gear.equipment = panel(gear, 20, -96, 340, 310)
  gear.rewards = panel(gear, 374, -96, 340, 310)
  gear.refresh = button(gear, "Itemdaten neu laden", 150, 28); gear.refresh:SetPoint("TOPLEFT", 20, -420); gear.refresh:SetScript("OnClick", function() NS:InvalidateGearCache(); NS:Refresh() end)
  gear.note = label(gear, "Der Vergleich wartet auf vollständig geladene Itemdaten und bleibt eine Stat-Heuristik.", "GameFontNormalSmall", {0.55,0.60,0.70}); gear.note:SetPoint("TOPLEFT", 184, -426); gear.note:SetWidth(520); gear.note:SetWordWrap(true)

  local dungeon = CreateFrame("Frame", nil, content); dungeon:SetAllPoints(); f.views.dungeon = dungeon
  dungeon.heading = label(dungeon, "Dungeon-Route", "GameFontNormalLarge", GOLD); dungeon.heading:SetPoint("TOPLEFT", 20, -18)
  dungeon.info = label(dungeon, "", "GameFontNormal", {0.75,0.78,0.86}); dungeon.info:SetPoint("TOPLEFT", 20, -48); dungeon.info:SetWidth(670); dungeon.info:SetWordWrap(true)
  dungeon.list = panel(dungeon, 20, -86, 670, 245)

  local class = CreateFrame("Frame", nil, content); class:SetAllPoints(); f.views.class = class
  class.heading = label(class, "Klassenprofil", "GameFontNormalLarge", GOLD); class.heading:SetPoint("TOPLEFT", 20, -18)
  class.text = label(class, "", "GameFontNormal", {0.82,0.84,0.90}); class.text:SetPoint("TOPLEFT", 20, -58); class.text:SetWidth(665); class.text:SetHeight(220); class.text:SetJustifyH("LEFT"); class.text:SetWordWrap(true)

  local settings = CreateFrame("Frame", nil, content); settings:SetAllPoints(); f.views.settings = settings
  settings.heading = label(settings, "Route konfigurieren", "GameFontNormalLarge", GOLD); settings.heading:SetPoint("TOPLEFT", 20, -18)
  settings.info = label(settings, "Modus und Fraktion ändern den aktiven Guide. Der Fortschritt des aktuellen Modus wird auf Schritt 1 gesetzt.", "GameFontNormal", {0.75,0.78,0.86}); settings.info:SetPoint("TOPLEFT", 20, -50); settings.info:SetWidth(660); settings.info:SetWordWrap(true)
  local modeLabel = label(settings, "Modus", "GameFontNormal", GOLD); modeLabel:SetPoint("TOPLEFT", 20, -98)
  for i, mode in ipairs({"speed", "dungeon", "discovery", "legacy"}) do
    local b = button(settings, NS.modes[mode], 145, 28); b:SetPoint("TOPLEFT", 20 + ((i-1)%2)*160, -120 - math.floor((i-1)/2)*36); b:SetScript("OnClick", function() NS:SetMode(mode); NS:ShowTab("route") end)
  end
  local routeLabel = label(settings, "Fraktion", "GameFontNormal", GOLD); routeLabel:SetPoint("TOPLEFT", 360, -98)
  local a = button(settings, "Allianz", 120, 28); a:SetPoint("TOPLEFT", 360, -120); a:SetScript("OnClick", function() NS.db.route, NS.db.step = "alliance", 1; NS:Refresh(); NS:ShowTab("route") end)
  local h = button(settings, "Horde", 120, 28); h:SetPoint("TOPLEFT", 490, -120); h:SetScript("OnClick", function() NS.db.route, NS.db.step = "horde", 1; NS:Refresh(); NS:ShowTab("route") end)
  local reset = button(settings, "Fortschritt zurücksetzen", 170, 28); reset:SetPoint("TOPLEFT", 360, -170); reset:SetScript("OnClick", function() NS:ResetProgress() end)
  local scan = button(settings, "Jetzt analysieren", 170, 30); scan:SetPoint("TOPLEFT", 360, -210); scan:SetScript("OnClick", function() NS:AutoScan(true); NS:ShowTab("route") end)
  local tracker = button(settings, "Tracker umschalten", 170, 30); tracker:SetPoint("TOPLEFT", 360, -250); tracker:SetScript("OnClick", function() if NS.tracker then NS.tracker:SetShown(not NS.tracker:IsShown()) end end)
  local navigation = button(settings, "Navigation umschalten", 170, 30); navigation:SetPoint("TOPLEFT", 20, -250); navigation:SetScript("OnClick", function() NS:ToggleNavigation() end)
  settings.scanHint = label(settings, "Automatischer Scan: beim Login und alle 5 Minuten.", "GameFontNormalSmall", {0.55,0.60,0.70}); settings.scanHint:SetPoint("TOPLEFT", 20, -220); settings.scanHint:SetWidth(300); settings.scanHint:SetJustifyH("LEFT")
  local trackerDown = button(settings, "Tracker −", 78, 26); trackerDown:SetPoint("TOPLEFT", 20, -298); trackerDown:SetScript("OnClick", function() NS:SetTrackerScale(-0.1) end)
  local trackerUp = button(settings, "Tracker +", 78, 26); trackerUp:SetPoint("TOPLEFT", 104, -298); trackerUp:SetScript("OnClick", function() NS:SetTrackerScale(0.1) end)
  local collapse = button(settings, "Tracker einklappen", 140, 26); collapse:SetPoint("TOPLEFT", 188, -298); collapse:SetScript("OnClick", function() NS:ToggleTrackerCollapsed() end)
  local navDown = button(settings, "Pfeil −", 78, 26); navDown:SetPoint("TOPLEFT", 360, -298); navDown:SetScript("OnClick", function() NS:SetNavigationScale(-0.1) end)
  local navUp = button(settings, "Pfeil +", 78, 26); navUp:SetPoint("TOPLEFT", 444, -298); navUp:SetScript("OnClick", function() NS:SetNavigationScale(0.1) end)
  local opacity = button(settings, "Transparenz", 112, 26); opacity:SetPoint("TOPLEFT", 528, -298); opacity:SetScript("OnClick", function() NS:CycleOpacity() end); settings.opacityButton = opacity
  local minimal = button(settings, "Minimalmodus", 112, 26); minimal:SetPoint("TOPLEFT", 20, -334); minimal:SetScript("OnClick", function() NS:ToggleMinimalMode() end); settings.minimalButton = minimal
  local lock = button(settings, "UI sperren", 112, 26); lock:SetPoint("TOPLEFT", 140, -334); lock:SetScript("OnClick", function() NS:SetFrameLock() end); settings.lockButton = lock
  local font = button(settings, "Schriftgröße", 112, 26); font:SetPoint("TOPLEFT", 260, -334); font:SetScript("OnClick", function() NS:CycleFontScale() end); settings.fontButton = font
  local diagnostics = button(settings, "Fehlerbericht", 130, 26); diagnostics:SetPoint("TOPLEFT", 380, -334); diagnostics:SetScript("OnClick", function() NS:ShowDiagnostics() end)
  local dataStatus = button(settings, "Datenstatus", 112, 26); dataStatus:SetPoint("TOPLEFT", 518, -334); dataStatus:SetScript("OnClick", function() NS:PrintDataStatus() end)
  local roleLabel = label(settings, "Gear-Profil", "GameFontNormalSmall", GOLD); roleLabel:SetPoint("TOPLEFT", 528, -370)
  local autoRole = button(settings, "Auto", 50, 24); autoRole:SetPoint("TOPLEFT", 528, -390); autoRole:SetScript("OnClick", function() NS:SetGearRole("AUTO") end)
  local dpsRole = button(settings, "DPS", 48, 24); dpsRole:SetPoint("TOPLEFT", 582, -390); dpsRole:SetScript("OnClick", function() NS:SetGearRole("DPS") end)
  local tankRole = button(settings, "Tank", 52, 24); tankRole:SetPoint("TOPLEFT", 634, -390); tankRole:SetScript("OnClick", function() NS:SetGearRole("TANK") end)
  local healerRole = button(settings, "Heal", 52, 24); healerRole:SetPoint("TOPLEFT", 690, -390); healerRole:SetScript("OnClick", function() NS:SetGearRole("HEALER") end)
  settings.dataInfo = label(settings, NS.GetOpenDataSummary and NS:GetOpenDataSummary() or "Offene Daten werden geladen.", "GameFontNormalSmall", {0.55,0.60,0.70}); settings.dataInfo:SetPoint("TOPLEFT", 20, -420); settings.dataInfo:SetWidth(730); settings.dataInfo:SetWordWrap(true)
  settings.dbInfo = label(settings, NS.GetForeverDBOverview and NS:GetForeverDBOverview() or "ForeverDB-Zusatzdaten werden geladen.", "GameFontNormalSmall", {0.48,0.78,0.60}); settings.dbInfo:SetPoint("TOPLEFT", 20, -442); settings.dbInfo:SetWidth(730); settings.dbInfo:SetWordWrap(true)
  settings.sourceInfo = label(settings, "Quellen: ForeverDB.net (Questdaten) · QuestieDB-Forever · Evergreen for WoW Forever\nForeverDB: https://foreverdb.net · Der API-Schlüssel ist nicht im Addon enthalten", "GameFontNormalSmall", {0.62,0.68,0.78}); settings.sourceInfo:SetPoint("TOPLEFT", 20, -466); settings.sourceInfo:SetWidth(730); settings.sourceInfo:SetWordWrap(true)

  for key, t in pairs(f.tabs) do t:SetScript("OnClick", function() NS:ShowTab(key) end) end
  self.frame = f; self:RestoreFramePosition(f, "main", "CENTER", UIParent, 0, 0); self:ShowTab("route"); self:Refresh()
end

function NS:CycleOpacity()
  self:EnsureSettings(); local values = {0.78, 0.88, 0.96}; local current = self.db.ui.opacity or 0.96; local nextValue = values[1]
  for index, value in ipairs(values) do if math.abs(current - value) < 0.03 then nextValue = values[index % #values + 1]; break end end
  self.db.ui.opacity = nextValue; if self.tracker then self:ApplyTrackerSettings() end; if self.navigationFrame then self:RefreshNavigation() end; self:Refresh()
end

function NS:CycleFontScale()
  self:EnsureSettings(); local values = {0.9, 1.0, 1.1, 1.2}; local current = self.db.ui.fontScale or 1; local nextValue = values[1]
  for index, value in ipairs(values) do if math.abs(current - value) < 0.03 then nextValue = values[index % #values + 1]; break end end
  self.db.ui.fontScale = nextValue; if self.tracker then self:ApplyTrackerSettings() end; if self.navigationFrame then self:RefreshNavigation() end; self:Refresh()
end

function NS:ToggleMinimalMode()
  self:EnsureSettings(); self.db.ui.minimal = not self.db.ui.minimal; self:Refresh(); self:Print(self.db.ui.minimal and "Minimalmodus aktiviert." or "Minimalmodus deaktiviert.")
end

function NS:RefreshSettings()
  if not self.frame or not self.frame.views.settings then return end
  self:EnsureSettings(); local view = self.frame.views.settings; local ui = self.db.ui
  if view.dataInfo then view.dataInfo:SetText(self.GetOpenDataSummary and self:GetOpenDataSummary() or "Offene Daten werden geladen.") end
  if view.dbInfo then view.dbInfo:SetText(self.GetForeverDBOverview and self:GetForeverDBOverview() or "ForeverDB-Zusatzdaten werden geladen.") end
  if view.opacityButton then view.opacityButton:SetText(string.format("Alpha %.0f%%", (ui.opacity or 0.96) * 100)) end
  if view.fontButton then view.fontButton:SetText(string.format("Schrift %.1fx", ui.fontScale or 1)) end
  if view.minimalButton then view.minimalButton:SetText(ui.minimal and "Minimal: AN" or "Minimal: AUS") end
  if view.lockButton then view.lockButton:SetText(ui.lockFrames and "UI entsperren" or "UI sperren") end
end

function NS:ShowTab(name)
  if not self.frame then return end
  for key, view in pairs(self.frame.views) do view:SetShown(key == name) end
  for key, tab in pairs(self.frame.tabs) do tab:SetEnabled(key ~= name) end
  self.frame.activeTab = name; self:Refresh()
end

function NS:RefreshRouteView()
  local f, steps, current = self.frame, self:GetSteps(), self:GetCurrentStep(); local view = f.views.route
  local p = self:GetClassProfile(); local doneCount = math.max(0, self.db.step - 1)
  view.status:SetText(string.format("%s  ·  %s  ·  %s  ·  Schritt %d/%d", self.modes[self.db.mode] or self.db.mode, self.db.route == "horde" and "Horde" or "Allianz", p.name, doneCount, #steps))
  view.progress:SetValue(#steps > 0 and doneCount / #steps or 0)
  if view.stepButtons then for _, b in ipairs(view.stepButtons) do b:Hide() end else view.stepButtons = {} end
  for i, s in ipairs(steps) do
    local b = view.stepButtons[i] or button(view.list, "", 280, 24); view.stepButtons[i] = b
    b:ClearAllPoints(); b:SetPoint("TOPLEFT", 10, -10 - (i-1)*26); local marker = self.db.completed[s.id] and "✓ " or (i == self.db.step and "▶ " or "· "); b:SetText(string.format("%s%d  %s", marker, s.level or 0, s.title)); b:SetShown(true)
    if self.db.completed[s.id] then b:SetTextColor(0.48, 0.78, 0.60) elseif i == self.db.step then b:SetTextColor(unpack(GOLD)) else b:SetTextColor(0.78,0.80,0.86) end
    b:SetScript("OnClick", function() self.db.step = i; self:Refresh() end)
  end
  if not current then view.detailTitle:SetText("Route abgeschlossen"); view.detailText:SetText("Wähle einen anderen Modus oder setze den Fortschritt zurück."); view.done:Disable(); view.skip:Disable(); return end
  view.done:Enable(); view.skip:Enable(); view.detailTitle:SetText(string.format("Stufe %s · %s", current.level or "–", current.title)); view.detailText:SetText((current.zone and ("Gebiet: " .. current.zone .. "\n\n") or "") .. self:GetCurrentBody(current))
end

function NS:RefreshGearView()
  local view=self.frame and self.frame.views.gear; if not view then return end
  local summary=self.GetEquipmentSummary and self:GetEquipmentSummary() or {average=0,weakSlots=0,pending=0,state="unbekannt"}
  view.summary:SetText(string.format("Durchschnittliches Itemlevel: %.0f · Status: %s · Leere Plätze: %d · Wartende Itemdaten: %d",summary.average or 0,summary.state or "unbekannt",summary.weakSlots or 0,summary.pending or 0))
  view.role:SetText("Profil: "..(self.GetGearRole and self:GetGearRole() or "AUTO").." · Waffen werden stärker gewichtet; Tank/Heiler/DPS/Solo getrennt bewertet.")
  if view.equipment.rows then for _, row in ipairs(view.equipment.rows) do row:Hide() end else view.equipment.rows={} end
  for i,r in ipairs(self.GetEquipmentRows and self:GetEquipmentRows() or {}) do
    local row=view.equipment.rows[i] or label(view.equipment,"","GameFontNormalSmall",{0.78,0.80,0.86}); view.equipment.rows[i]=row
    row:SetPoint("TOPLEFT",12,-12-(i-1)*16); row:SetWidth(315); row:SetWordWrap(false); row:SetText(string.format("%-10s  %s",r.label or "Slot",r.item and string.format("%s (%.0f)",r.item.name or "Item",r.score or 0) or (r.status or "unbekannt"))); row:Show()
  end
  local comparison=self.GetRewardComparison and self:GetRewardComparison() or {rows={},advice="Belohnungsdaten nicht verfügbar."}
  view.rewards.advice=view.rewards.advice or label(view.rewards,"","GameFontNormal",GOLD); view.rewards.advice:SetPoint("TOPLEFT",12,-14); view.rewards.advice:SetWidth(315); view.rewards.advice:SetWordWrap(true); view.rewards.advice:SetText(comparison.advice or "Keine Auswahlbelohnung geöffnet.")
  if view.rewards.rows then for _, row in ipairs(view.rewards.rows) do row:Hide() end else view.rewards.rows={} end
  for i,r in ipairs(comparison.rows or {}) do
    local row=view.rewards.rows[i] or label(view.rewards,"","GameFontNormalSmall",{0.78,0.80,0.86}); view.rewards.rows[i]=row
    row:SetPoint("TOPLEFT",12,-56-(i-1)*24); row:SetWidth(315); row:SetWordWrap(true); row:SetText(string.format("%s  %s",r.name or "Belohnung",r.delta and string.format("%+.1f",r.delta) or (r.status or "lädt"))); row:Show()
  end
end

function NS:RefreshUI()
  if not self.db or not self.frame then return end
  local active = self.frame.activeTab or "route"
  if active == "route" then self:RefreshRouteView()
  elseif active == "gear" then self:RefreshGearView()
  elseif active == "class" then local p = self:GetClassProfile(); local extra = self.GetForeverDBOverview and ("\n\n" .. self:GetForeverDBOverview()) or ""; self.frame.views.class.text:SetText(string.format("Klasse: %s\nLevel-Spec: %s\nGeschwindigkeitsprofil: %s\nRolle: %s\n\n%s\n\nTrainer, Klassenquests und Berufe werden als Stopps in die Route eingeordnet. Loot- und Reward-Hinweise bleiben Empfehlungen und ersetzen keine Spielerentscheidung.%s", p.name, p.spec, p.speed, p.role, p.note, extra))
  elseif active == "dungeon" then
    local route = self.routes[self.db.route] or self.routes.alliance; local d = route.dungeon or {}
    local best, bestScore
    if self.GetBestDungeon then best, bestScore = self:GetBestDungeon() end
    local bestText = best and string.format("Beste Instanz jetzt: %s (Score %.0f). Dungeon-Loot-Bonus wird nur heuristisch aus Level, Gruppe, Rolle und Ausrüstungszustand geschätzt.", best.name, bestScore or 0) or "Keine passende Instanz gefunden."
    self.frame.views.dungeon.info:SetText(bestText .. "\nEinmalige Dungeonquests zuerst sammeln; Wiederholungen nur bei stabiler Gruppe.")
    if self.frame.views.dungeon.buttons then for _, b in ipairs(self.frame.views.dungeon.buttons) do b:Hide() end else self.frame.views.dungeon.buttons = {} end
    for i, s in ipairs(d) do local b = self.frame.views.dungeon.buttons[i] or button(self.frame.views.dungeon.list, "", 640, 24); self.frame.views.dungeon.buttons[i] = b; b:ClearAllPoints(); b:SetPoint("TOPLEFT", 12, -10-(i-1)*26); local marker = self.db.completed[s.id] and "✓ " or (i == self.db.step and "▶ " or "· "); b:SetText(string.format("%s%d  %s", marker, s.level or 0, s.title)); b:SetShown(true); b:SetScript("OnClick", function() self:SetMode("dungeon"); self.db.step=i; self:Refresh() end) end
  end
  self:RefreshSettings()
end
function NS:Toggle() if not self.frame then self:CreateUI() end; self.frame:SetShown(not self.frame:IsShown()) end
