local NS = ForeverPath

local function now()
  return GetTime and GetTime() or 0
end

function NS:InitLayerRouting()
  self.db.layerRouting = self.db.layerRouting or { samples={}, suggestions=0 }
  self.layerRouting = self.db.layerRouting
end

function NS:GetForeverGuildLayerInfo()
  -- Do not call another addon's functions from the refresh loop.  On current
  -- Forever builds ForeverGuild can expose protected/secret values; invoking
  -- those methods from here would taint both addons.  Layer pressure remains
  -- locally measured and the player can still change layers manually.
  return nil, false
end

function NS:RecordLayerPressure(event)
  if not self.layerRouting then self:InitLayerRouting() end
  local zone = self.GetPlayerZone and self:GetPlayerZone() or "Unbekannt"
  local row = self.layerRouting.samples[zone] or {seen=0, empty=0, kills=0, last=0}
  row.seen = math.min(500, (row.seen or 0) + 1)
  if event == "empty" then row.empty = math.min(500, (row.empty or 0) + 1) end
  if event == "kill" then row.kills = math.min(500, (row.kills or 0) + 1) end
  row.last = now(); self.layerRouting.samples[zone] = row
end

function NS:GetLayerAdvice()
  if not self.layerRouting then self:InitLayerRouting() end
  local zone = self.GetPlayerZone and self:GetPlayerZone() or "Unbekannt"
  local row = self.layerRouting.samples[zone]
  local layer, integrated = self:GetForeverGuildLayerInfo()
  if integrated then return {state="known", text="Layer " .. layer .. " · ForeverGuild-Info erkannt", layer=layer} end
  if not row or (row.seen or 0) < 5 then return {state="unknown", text="Layer-Druck wird noch gemessen"} end
  local pressure = (row.empty or 0) / math.max(1, row.seen)
  if pressure >= 0.45 then
    return {state="high", text="Zone wirkt überfarmt · Layer-Wechsel prüfen", pressure=pressure}
  end
  return {state="normal", text="Layer-Druck normal · kein Wechsel nötig", pressure=pressure}
end

function NS:SuggestLayerHop()
  local advice = self:GetLayerAdvice()
  if advice.state == "high" then
    self.layerRouting.suggestions = (self.layerRouting.suggestions or 0) + 1
    self:Print("Layer-Hinweis: Zone wirkt überfarmt. Prüfe den Layer-Wechsel über ForeverGuild.")
    return true
  end
  self:Print(advice.text)
  return false
end
