local NS = ForeverPath

local GOLD = {0.84, 0.66, 0.29, 1}
local BLUE = {0.20, 0.55, 0.85, 1}
local DIRECTIONS = {"→", "↘", "↓", "↙", "←", "↖", "↑", "↗"}
local ARROW_STYLES = {{"Klassisch", {"→", "↘", "↓", "↙", "←", "↖", "↑", "↗"}}, {"Chevron", {"›", "⌟", "⌄", "⌞", "‹", "⌜", "⌃", "⌝"}}, {"Doppelt", {"⇒", "⇘", "⇓", "⇙", "⇐", "⇖", "⇑", "⇗"}}}
local ARROW_COLORS = {{"Gold", {0.98,0.72,0.18,1}}, {"Blau", {0.28,0.68,1.00,1}}, {"Grün", {0.35,1.00,0.62,1}}, {"Violett", {0.82,0.42,1.00,1}}, {"Weiß", {0.95,0.97,1.00,1}}}

local function directionForAngle(angle)
  local sector = math.floor(((angle + math.pi * 2 + math.pi / 8) % (math.pi * 2)) / (math.pi / 4)) + 1
  return DIRECTIONS[sector] or "↑"
end

local function ensureSettings()
  if NS.EnsureSettings then NS:EnsureSettings() end
  NS.db.navigation = NS.db.navigation or {}
  if NS.db.navigation.show == nil then NS.db.navigation.show = true end
  if NS.db.navigation.minimapLine == nil then NS.db.navigation.minimapLine = true end
  if NS.db.navigation.scale == nil then NS.db.navigation.scale = 1 end
end

local function arrowGlyph(angle)
  local style = ARROW_STYLES[(NS.db and NS.db.ui and NS.db.ui.arrowStyle or 1)] or ARROW_STYLES[1]
  local sector = math.floor(((angle + math.pi * 2 + math.pi / 8) % (math.pi * 2)) / (math.pi / 4)) + 1
  return style[2][sector] or style[2][7]
end

local function compactTargetText(value)
  value = tostring(value or "Questziel"):gsub("\n", " ")
  value = value:gsub("%s+[Aa]t%s+.*$", ""):gsub("%s+[Ii]n%s+.*$", ""):gsub("%s+[Ff]rom%s+.*$", "")
  if #value > 36 then value = value:sub(1, 35) .. "..." end
  return value
end

local function showArrowTexture(frame, rotation, shown)
  if not frame then return end
  if frame.arrowTexture then
    frame.arrowTexture:SetShown(shown ~= false)
    -- MinimapArrow points upward at zero rotation; navigationAngle is based
    -- on an east-facing vector, so rotate the texture into the same basis.
    if shown ~= false and frame.arrowTexture.SetRotation then frame.arrowTexture:SetRotation((rotation or 0) - math.pi / 2) end
  end
  for _, layer in ipairs({frame.arrow, frame.arrowGlow, frame.arrowShadow}) do if layer then layer:Hide() end end
end

local function readableNumber(value)
  if value == nil or type(value) ~= "number" then return false end
  if issecretvalue then
    local ok, secret = pcall(issecretvalue, value)
    if ok and secret then return false end
  end
  return true
end

local function readableXY(position)
  if not position or not position.GetXY then return nil end
  local ok, x, y = pcall(function()
    local px, py = position:GetXY()
    if not readableNumber(px) or not readableNumber(py) then return nil, nil end
    return px, py
  end)
  if not ok or not x or not y then return nil end
  return x, y
end

function NS:GetSafeMapPosition(mapID, unit)
  if not C_Map or not C_Map.GetPlayerMapPosition or not mapID then return nil end
  local ok, position = pcall(C_Map.GetPlayerMapPosition, mapID, unit or "player")
  if not ok then return nil end
  local x, y = readableXY(position)
  if not x or not y then return nil end
  return x, y
end

local function getWorldDistance(mapID,px,py,tx,ty)
  if not C_Map or not C_Map.GetWorldPosFromMapPos or not CreateVector2D then return nil end
  local function worldXY(id,x,y)
    local ok,a,b=pcall(C_Map.GetWorldPosFromMapPos,id,CreateVector2D(x,y)); if not ok then return nil end
    local point=a and a.GetXY and a or b and b.GetXY and b; if not point then return nil end
    return readableXY(point)
  end
  local ax,ay=worldXY(mapID,px,py); local bx,by=worldXY(mapID,tx,ty)
  if not ax or not ay or not bx or not by then return nil end
  local okDistance, distance = pcall(function()
    return math.sqrt((bx-ax)^2+(by-ay)^2)
  end)
  return okDistance and distance or nil
end

local function getWorldXY(mapID, x, y)
  if not C_Map or not C_Map.GetWorldPosFromMapPos or not CreateVector2D or not mapID then return nil end
  local ok,a,b=pcall(C_Map.GetWorldPosFromMapPos,mapID,CreateVector2D(x,y)); if not ok then return nil end
  local point=a and a.GetXY and a or b and b.GetXY and b; if not point then return nil end
  return readableXY(point)
end

local function getTargetData()
  local step = NS.GetCurrentStep and NS:GetCurrentStep()
  local target = step and NS.GetBestWaypoint and NS:GetBestWaypoint(step)
  if NS.db and NS.db.navigation and NS.db.navigation.mobPriority and NS.GetEfficientMobWaypoint then
    local mob = NS:GetEfficientMobWaypoint()
    if mob and (not target or target.kind == "giver" or target.kind == "objective") then target = mob end
  end
  if not target or not target.mapID or not target.x or not target.y then return nil end
  if not C_Map or not C_Map.GetBestMapForUnit or not C_Map.GetPlayerMapPosition then return nil end
  local okMap, mapID = pcall(C_Map.GetBestMapForUnit, "player")
  if not okMap then return nil end
  if not mapID then return {target=target, mapID=nil} end
  -- Forever can return the continent map (for example 1415) while the
  -- quest marker uses the zone map (for example 1420). Ask for the player
  -- position on the target map before declaring a zone change.
  local positionMap = target.mapID
  local px, py = NS:GetSafeMapPosition(positionMap, "player")
  if px and py then
    mapID = positionMap
  elseif mapID ~= target.mapID then
    -- We are on another zone map.  When the client exposes world positions,
    -- keep the arrow useful during the zone/flight transition instead of
    -- replacing it with a static "Gebietswechsel" message.
    local playerX, playerY = NS:GetSafeMapPosition(mapID, "player")
    local currentWX, currentWY = getWorldXY(mapID, playerX, playerY)
    local targetWX, targetWY = getWorldXY(target.mapID, target.x / 100, target.y / 100)
    if currentWX and currentWY and targetWX and targetWY then
      local dx, dy = targetWX - currentWX, targetWY - currentWY
      local distance = math.sqrt(dx * dx + dy * dy)
      return {target=target, mapID=mapID, sameMap=false, directionAvailable=true, distance=distance, worldDistance=distance, angle=math.atan2(-dy, dx), eta=math.max(8, math.floor(distance / 4))}
    end
    return {target=target, mapID=mapID, sameMap=false}
  else
    px, py = NS:GetSafeMapPosition(mapID, "player")
  end
  if not px or not py then return {target=target, mapID=mapID, sameMap=false, restricted=true} end
  local okCalculation, calculation = pcall(function()
    local dx, dy = target.x - px * 100, target.y - py * 100
    local distance = math.sqrt(dx * dx + dy * dy)
    local worldDistance = getWorldDistance(mapID,px,py,target.x/100,target.y/100)
    local angle = math.atan2(-dy, dx)
    return {dx=dx,dy=dy,distance=distance,worldDistance=worldDistance,angle=angle}
  end)
  if not okCalculation or not calculation then return {target=target, mapID=mapID, sameMap=false, restricted=true} end
  local dx, dy = calculation.dx, calculation.dy
  local distance = calculation.distance
  local worldDistance = calculation.worldDistance
  local angle = calculation.angle
  local eta = math.max(5, math.floor(distance * 1.4))
  return {target=target, mapID=mapID, sameMap=true, distance=distance, worldDistance=worldDistance, distanceMode=worldDistance and "m" or "% Kartenstrecke", angle=angle, eta=eta}
end

local function formatETA(seconds)
  if not seconds then return "–" end
  if seconds < 60 then return string.format("%d Sek.", seconds) end
  return string.format("%d:%02d Min.", math.floor(seconds / 60), seconds % 60)
end

function NS:CreateNavigation()
  if self.navigationFrame then return end
  ensureSettings()

  local f = CreateFrame("Frame", "ForeverPathNavigationFrame", UIParent, "BackdropTemplate")
  f:SetSize(340, 132)
  f:SetPoint("TOP", UIParent, "TOP", 0, -22)
  f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
  f:SetClampedToScreen(true); f:SetToplevel(true)
  f:SetFrameStrata("DIALOG"); f:SetFrameLevel(50)
  f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=12, insets={left=3,right=3,top=3,bottom=3}})
  f:SetBackdropColor(0.035, 0.045, 0.07, 0.96); f:SetBackdropBorderColor(0.60, 0.44, 0.20, 1)

  local header = CreateFrame("Button", nil, f)
  header:SetPoint("TOPLEFT", 6, -5); header:SetPoint("TOPRIGHT", -28, -5); header:SetHeight(20); header:RegisterForDrag("LeftButton")
  header:SetScript("OnDragStart", function() if not (NS.db and NS.db.ui and NS.db.ui.lockFrames) then f:StartMoving() end end)
  header:SetScript("OnDragStop", function()
    f:StopMovingOrSizing()
    NS:SaveFramePosition(f, "navigation")
  end)
  f.title = header:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  f.title:SetPoint("LEFT", 4, 0); f.title:SetTextColor(unpack(GOLD)); f.title:SetText("FOREVERPATH · NAVIGATION")

  local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
  close:SetSize(20, 20); close:SetPoint("TOPRIGHT", -3, -3); close:SetScript("OnClick", function() NS:SetNavigationShown(false) end)

  -- Mehrschichtiger Pfeil: Schatten + Glow + Vorderseite erzeugen einen
  -- gut lesbaren 3D-Look, ohne geschützte Addon-Assets zu kopieren.
  f.arrowShadow = f:CreateFontString(nil, "BACKGROUND", "GameFontNormalHuge")
  f.arrowShadow:SetPoint("LEFT", 15, -10); f.arrowShadow:SetWidth(52); f.arrowShadow:SetJustifyH("CENTER"); f.arrowShadow:SetTextColor(0.02, 0.04, 0.08, 0.95); f.arrowShadow:SetText("↑")
  f.arrowGlow = f:CreateFontString(nil, "BORDER", "GameFontNormalHuge")
  f.arrowGlow:SetPoint("LEFT", 13, -7); f.arrowGlow:SetWidth(52); f.arrowGlow:SetJustifyH("CENTER"); f.arrowGlow:SetTextColor(1.0, 0.32, 0.12, 0.28); f.arrowGlow:SetText("↑")
  f.arrow = f:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
  f.arrow:SetPoint("LEFT", 12, -6); f.arrow:SetWidth(52); f.arrow:SetJustifyH("CENTER"); f.arrow:SetTextColor(unpack(GOLD)); f.arrow:SetText("↑")
  if STANDARD_TEXT_FONT then
    f.arrow:SetFont(STANDARD_TEXT_FONT, 42, "OUTLINE")
    f.arrowGlow:SetFont(STANDARD_TEXT_FONT, 42, "OUTLINE")
    f.arrowShadow:SetFont(STANDARD_TEXT_FONT, 42, "OUTLINE")
  end
  f.arrowTexture = f:CreateTexture(nil, "OVERLAY")
  f.arrowTexture:SetTexture("Interface\\Minimap\\MinimapArrow")
  f.arrowTexture:SetSize(52, 52); f.arrowTexture:SetPoint("LEFT", 12, -48); f.arrowTexture:SetVertexColor(0.98, 0.72, 0.18, 1)
  f.arrowTexture:Hide()
  -- The old FontString arrows were only a fallback for early prototypes.
  -- Keep them allocated for SavedVariables compatibility, but never render
  -- them; unsupported glyphs otherwise appear as the purple square seen in
  -- the client screenshot.
  f.arrow:Hide(); f.arrowGlow:Hide(); f.arrowShadow:Hide()
  f.target = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  f.target:SetPoint("TOPLEFT", 18, -31); f.target:SetWidth(304); f.target:SetHeight(36); f.target:SetJustifyH("LEFT"); f.target:SetWordWrap(true); f.target:SetText("Ziel wird geladen ...")
  f.distance = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  f.distance:SetPoint("TOPLEFT", 18, -73); f.distance:SetWidth(304); f.distance:SetTextColor(0.65, 0.72, 0.84)
  f.hint = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  f.hint:SetPoint("TOPLEFT", 18, -91); f.hint:SetWidth(304); f.hint:SetWordWrap(false); f.hint:SetTextColor(0.55, 0.78, 0.62)

  if self.db.navigation.point and self.db.navigation.x and self.db.navigation.y and not (self.db.ui and self.db.ui.positions and self.db.ui.positions.navigation) then
    f:ClearAllPoints(); f:SetPoint(self.db.navigation.point, UIParent, self.db.navigation.point, self.db.navigation.x, self.db.navigation.y)
  else self:RestoreFramePosition(f, "navigation", "TOP", UIParent, 0, -22) end

  -- Separater, frei verschiebbarer TomTom-ähnlicher Pfeil. Das Detail-HUD
  -- bleibt unabhängig davon verschiebbar; beide Positionen werden getrennt
  -- in den SavedVariables gespeichert.
  local arrowFrame = CreateFrame("Frame", "ForeverPathNavigationArrowFrame", UIParent, "BackdropTemplate")
  arrowFrame:SetSize(124, 94)
  arrowFrame:SetMovable(true); arrowFrame:EnableMouse(true); arrowFrame:RegisterForDrag("LeftButton")
  arrowFrame:SetClampedToScreen(true); arrowFrame:SetToplevel(true); arrowFrame:SetFrameStrata("DIALOG"); arrowFrame:SetFrameLevel(51)
  arrowFrame:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=10, insets={left=2,right=2,top=2,bottom=2}})
  arrowFrame:SetBackdropColor(0.02, 0.03, 0.06, 0.78); arrowFrame:SetBackdropBorderColor(0.60, 0.44, 0.20, 0.85)
  arrowFrame:SetScript("OnDragStart", function()
    if not (NS.db and NS.db.ui and NS.db.ui.lockFrames) then arrowFrame:StartMoving() end
  end)
  arrowFrame:SetScript("OnDragStop", function()
    arrowFrame:StopMovingOrSizing(); NS:SaveFramePosition(arrowFrame, "navigationArrow")
  end)
  arrowFrame.arrowTexture = arrowFrame:CreateTexture(nil, "OVERLAY")
  arrowFrame.arrowTexture:SetTexture("Interface\\Minimap\\MinimapArrow")
  arrowFrame.arrowTexture:SetSize(52, 52); arrowFrame.arrowTexture:SetPoint("TOP", 0, -3); arrowFrame.arrowTexture:SetVertexColor(0.98, 0.72, 0.18, 1)
  arrowFrame.target = arrowFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  arrowFrame.target:SetPoint("TOP", 0, -53); arrowFrame.target:SetWidth(116); arrowFrame.target:SetHeight(16); arrowFrame.target:SetJustifyH("CENTER"); arrowFrame.target:SetWordWrap(false); arrowFrame.target:SetTextColor(0.94, 0.78, 0.30)
  arrowFrame.distance = arrowFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  arrowFrame.distance:SetPoint("TOP", 0, -70); arrowFrame.distance:SetWidth(116); arrowFrame.distance:SetHeight(16); arrowFrame.distance:SetJustifyH("CENTER"); arrowFrame.distance:SetWordWrap(false); arrowFrame.distance:SetTextColor(0.72, 0.82, 0.96)
  self:RestoreFramePosition(arrowFrame, "navigationArrow", "CENTER", UIParent, 0, -130)

  f:SetScript("OnUpdate", function(_, elapsed)
    f.elapsed = (f.elapsed or 0) + elapsed
    if f.elapsed >= 0.12 then f.elapsed = 0; NS:RefreshNavigation() end
  end)

  local line = CreateFrame("Frame", "ForeverPathMinimapRouteLine", Minimap)
  line:SetAllPoints(Minimap); line:SetFrameLevel(Minimap:GetFrameLevel() + 3); line:Hide()
  line.segment = line:CreateTexture(nil, "OVERLAY")
  line.segment:SetTexture("Interface\\Buttons\\WHITE8X8"); line.segment:SetVertexColor(BLUE[1], BLUE[2], BLUE[3], 0.90); line.segment:SetHeight(3)
  line.dot = line:CreateTexture(nil, "OVERLAY")
  line.dot:SetTexture("Interface\\Buttons\\WHITE8X8"); line.dot:SetVertexColor(GOLD[1], GOLD[2], GOLD[3], 1); line.dot:SetSize(8, 8)
  line.nextDots = {}
  for index = 1, 3 do
    line.nextDots[index] = line:CreateTexture(nil, "OVERLAY")
    line.nextDots[index]:SetTexture("Interface\\Buttons\\WHITE8X8"); line.nextDots[index]:SetVertexColor(BLUE[1], BLUE[2], BLUE[3], 0.85); line.nextDots[index]:SetSize(6, 6); line.nextDots[index]:Hide()
  end

  self.navigationFrame, self.navigationArrowFrame, self.minimapRouteLine = f, arrowFrame, line
  f:Show()
  self:RefreshNavigation()
end

function NS:SetNavigationShown(shown)
  ensureSettings()
  NS.db.navigation.show = shown ~= false
  if self.navigationFrame then self.navigationFrame:SetShown(NS.db.navigation.show) end
  if self.navigationArrowFrame then self.navigationArrowFrame:SetShown(NS.db.navigation.show) end
  if not NS.db.navigation.show and self.minimapRouteLine then self.minimapRouteLine:Hide() end
  if NS.db.navigation.show then self:RefreshNavigation() end
end

function NS:ToggleNavigation()
  ensureSettings()
  self:SetNavigationShown(not NS.db.navigation.show)
end

function NS:SetNavigationScale(delta)
  self:EnsureSettings(); self.db.ui.navigationScale = math.max(0.75, math.min(1.45, (self.db.ui.navigationScale or 1) + delta)); self:RefreshNavigation(); self:Print(string.format("Pfeil-Skalierung: %.2fx", self.db.ui.navigationScale))
end

function NS:SetArrowScale(delta)
  self:EnsureSettings(); self.db.ui.arrowScale=math.max(0.70,math.min(1.70,(self.db.ui.arrowScale or 1)+delta)); self:RefreshNavigation(); self:Print(string.format("Pfeilgröße: %.2fx",self.db.ui.arrowScale))
end
function NS:CycleArrowColor()
  self:EnsureSettings(); self.db.ui.arrowColor=(self.db.ui.arrowColor or 1)%#ARROW_COLORS+1; self:RefreshNavigation(); self:Print("Pfeilfarbe: "..ARROW_COLORS[self.db.ui.arrowColor][1])
end
function NS:CycleArrowStyle()
  self:EnsureSettings(); self.db.ui.arrowStyle=(self.db.ui.arrowStyle or 1)%#ARROW_STYLES+1; self:RefreshNavigation(); self:Print("Pfeilstil: "..ARROW_STYLES[self.db.ui.arrowStyle][1])
end
function NS:ApplyArrowSettings()
  local f=self.navigationFrame; if not f then return end
  local color=(ARROW_COLORS[self.db.ui.arrowColor or 1] or ARROW_COLORS[1])[2]
  local scale=self.db.ui.arrowScale or 1
  for _, layer in ipairs({f.arrow, f.arrowGlow, f.arrowShadow}) do if layer then layer:SetScale(scale) end end
  if f.arrow then f.arrow:SetTextColor(unpack(color)) end
  if f.arrowGlow then f.arrowGlow:SetTextColor(color[1],color[2],color[3],0.28) end
  if f.arrowTexture then f.arrowTexture:SetVertexColor(unpack(color)); f.arrowTexture:SetScale(scale) end
  local arrowFrame=self.navigationArrowFrame
  if arrowFrame then
    arrowFrame:SetScale((self.db.ui.navigationScale or 1) * (self.db.ui.fontScale or 1))
    arrowFrame:SetAlpha(self.db.ui.opacity or 0.96)
    if arrowFrame.arrowTexture then arrowFrame.arrowTexture:SetVertexColor(unpack(color)); arrowFrame.arrowTexture:SetScale(scale) end
  end
end

function NS:RefreshNavigation()
  if not self.navigationFrame or not self.db then return end
  ensureSettings()
  self:ApplyArrowSettings()
  local step = self.GetCurrentStep and self:GetCurrentStep()
  self.navigationFrame:SetScale((self.db.navigation.scale or 1) * (self.db.ui.navigationScale or 1) * (self.db.ui.fontScale or 1)); self.navigationFrame:SetAlpha(self.db.ui.opacity or 0.96)
  self.navigationFrame:SetShown(self.db.navigation.show ~= false)
  if self.navigationArrowFrame then self.navigationArrowFrame:SetShown(self.db.navigation.show ~= false) end
  if self.db.navigation.show == false then if self.minimapRouteLine then self.minimapRouteLine:Hide() end; return end

  local data = getTargetData()
  local line = self.minimapRouteLine
  local function hideNextDots()
    if line and line.nextDots then for _, dot in ipairs(line.nextDots) do dot:Hide() end end
  end
  if not data then
    showArrowTexture(self.navigationArrowFrame, 0, false); self.navigationFrame.target:SetText("Kein Wegpunkt"); self.navigationFrame.distance:SetText("Schritt ohne Zielkoordinaten"); self.navigationFrame.hint:SetText("")
    if self.navigationArrowFrame then self.navigationArrowFrame.target:SetText("Kein Wegpunkt"); self.navigationArrowFrame.distance:SetText("-") end
    if line then line:Hide() end; hideNextDots()
    return
  end
  local kindNames = { giver="NPC", objective="Ziel", turnin="Abgabe", enemy="Gegner", item="Item" }
  local targetName = (kindNames[data.target.kind] and ("[" .. kindNames[data.target.kind] .. "] ") or "") .. compactTargetText(data.target.hint or data.target.title or "Questziel")
  self.navigationFrame.target:SetText(targetName)
  if not data.sameMap then
    local crossAngle = data.angle
    if data.directionAvailable and crossAngle and GetPlayerFacing then
      local okFacing, facing = pcall(GetPlayerFacing)
      if okFacing and readableNumber(facing) then crossAngle = crossAngle - facing end
      local previousAngle = self.navigationAngle or crossAngle
      local delta = (crossAngle - previousAngle + math.pi) % (math.pi * 2) - math.pi
      self.navigationAngle = previousAngle + delta * 0.28
      showArrowTexture(self.navigationArrowFrame, self.navigationAngle, true)
    else
      showArrowTexture(self.navigationArrowFrame, 0, false)
    end
    local crossDistance = data.worldDistance and string.format("%.0f m", data.worldDistance) or "Gebietswechsel"
    self.navigationFrame.distance:SetText(data.directionAvailable and ("Gebietswechsel · " .. crossDistance) or "Gebietswechsel erforderlich")
    self.navigationFrame.hint:SetText(self.GetTravelAdvice and self:GetTravelAdvice(step) or "Wegpunkt auf der Weltkarte gesetzt")
    if self.navigationArrowFrame then self.navigationArrowFrame.target:SetText(compactTargetText(targetName)); self.navigationArrowFrame.distance:SetText(crossDistance) end
    if line then line:Hide() end; hideNextDots()
    return
  end
  local targetAngle = data.angle
  if GetPlayerFacing then
    local okFacing, facing = pcall(GetPlayerFacing)
    if okFacing and readableNumber(facing) then targetAngle = targetAngle - facing end
  end
  local previousAngle = self.navigationAngle or targetAngle
  local delta = (targetAngle - previousAngle + math.pi) % (math.pi * 2) - math.pi
  self.navigationAngle = previousAngle + delta * 0.28
  local distanceText=data.worldDistance and string.format("%.0f m",data.worldDistance) or string.format("%.0f%% Kartenstrecke",data.distance or 0)
  showArrowTexture(self.navigationArrowFrame, self.navigationAngle, true)
  self.navigationFrame.distance:SetText(distanceText.." · ETA ~"..formatETA(data.eta))
  local hint = self.GetTravelAdvice and self:GetTravelAdvice(step) or "Dynamischer Quest-Wegpunkt"
  if data.target.kind == "enemy" then hint = "EP-Mob priorisiert · " .. hint end
  if self.GetLayerAdvice and self.db.ui.layerHints ~= false then
    local layer = self:GetLayerAdvice()
    if layer and layer.state == "high" then hint = hint .. " · Layer prüfen" end
  end
  self.navigationFrame.hint:SetText(hint)
  if self.navigationArrowFrame then
    self.navigationArrowFrame.target:SetText(compactTargetText(targetName))
    self.navigationArrowFrame.distance:SetText(distanceText .. " · " .. formatETA(data.eta))
  end

  if not line or not self.db.navigation.minimapLine then hideNextDots(); return end
  local mapWidth, mapHeight = Minimap:GetWidth(), Minimap:GetHeight()
  local mapID = data.mapID
  local px, py = self:GetSafeMapPosition(mapID, "player")
  if not px or not py then line:Hide(); hideNextDots(); return end
  local dx, dy = data.target.x / 100 - px, data.target.y / 100 - py
  local sx, sy = dx * mapWidth * 2.0, -dy * mapHeight * 2.0
  local radius = math.min(mapWidth, mapHeight) * 0.44
  local length = math.sqrt(sx * sx + sy * sy)
  if length < 2 then line:Hide(); hideNextDots(); return end
  if length > radius then sx, sy = sx / length * radius, sy / length * radius; length = radius end
  line.segment:ClearAllPoints(); line.segment:SetPoint("CENTER", Minimap, "CENTER", sx / 2, sy / 2); line.segment:SetSize(length, 3); line.segment:SetRotation(math.atan2(sy, sx))
  line.dot:ClearAllPoints(); line.dot:SetPoint("CENTER", Minimap, "CENTER", sx, sy)
  line:Show()
  local upcoming = self.GetUpcomingWaypoints and self:GetUpcomingWaypoints(4) or {}
  for index, dot in ipairs(line.nextDots or {}) do
    local nextPoint = upcoming[index + 1] and upcoming[index + 1].target
    if nextPoint and nextPoint.mapID == mapID then
      local nx, ny = (nextPoint.x / 100 - px) * mapWidth * 2.0, -(nextPoint.y / 100 - py) * mapHeight * 2.0
      local nLength = math.sqrt(nx * nx + ny * ny)
      if nLength > radius then nx, ny = nx / nLength * radius, ny / nLength * radius end
      dot:ClearAllPoints(); dot:SetPoint("CENTER", Minimap, "CENTER", nx, ny); dot:Show()
    else
      dot:Hide()
    end
  end
end

-- Liefert bewusst relative Kartenwerte: die Classic/WoW-Forever-API stellt
-- nicht auf jedem Client echte Weltmeter für alle Karten bereit.
function NS:GetNavigationMeasurement(point)
  local data=getTargetData()
  if not data or not point or data.target.mapID~=point.mapID then return nil end
  return {sameMap=data.sameMap, fraction=(data.distance or 0)/100, worldDistance=data.worldDistance, angle=data.angle, eta=data.eta}
end
