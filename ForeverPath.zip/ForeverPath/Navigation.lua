local NS = ForeverPath

local GOLD = {0.84, 0.66, 0.29, 1}
local BLUE = {0.20, 0.55, 0.85, 1}
local DIRECTIONS = {"→", "↘", "↓", "↙", "←", "↖", "↑", "↗"}

local function ensureSettings()
  NS.db.navigation = NS.db.navigation or {}
  if NS.db.navigation.show == nil then NS.db.navigation.show = true end
  if NS.db.navigation.minimapLine == nil then NS.db.navigation.minimapLine = true end
  if NS.db.navigation.scale == nil then NS.db.navigation.scale = 1 end
end

local function getTargetData()
  local step = NS.GetCurrentStep and NS:GetCurrentStep()
  local target = step and NS.GetBestWaypoint and NS:GetBestWaypoint(step)
  if not target or not target.mapID or not target.x or not target.y then return nil end
  if not C_Map or not C_Map.GetBestMapForUnit or not C_Map.GetPlayerMapPosition then return nil end
  local mapID = C_Map.GetBestMapForUnit("player")
  if not mapID then return {target=target, mapID=nil} end
  if mapID ~= target.mapID then return {target=target, mapID=mapID, sameMap=false} end
  local ok, position = pcall(C_Map.GetPlayerMapPosition, mapID, "player")
  if not ok or not position or not position.GetXY then return {target=target, mapID=mapID, sameMap=false} end
  local px, py = position:GetXY()
  local dx, dy = target.x - px * 100, target.y - py * 100
  local distance = math.sqrt(dx * dx + dy * dy)
  local angle = math.atan2(-dy, dx)
  local sector = math.floor(((angle + math.pi * 2 + math.pi / 8) % (math.pi * 2)) / (math.pi / 4)) + 1
  local eta = math.max(5, math.floor(distance * 1.4))
  return {target=target, mapID=mapID, sameMap=true, distance=distance, angle=angle, direction=DIRECTIONS[sector], eta=eta}
end

local function formatETA(seconds)
  if not seconds then return "–" end
  if seconds < 60 then return string.format("%d Sek.", seconds) end
  return string.format("%d:%02d Min.", math.floor(seconds / 60), seconds % 60)
end

function NS:CreateNavigation()
  if self.navigationFrame then return end
  ensureSettings()

  local f = CreateFrame("Frame", "ForeverPathNavigationFrame", UIParent, "BackdropTemplate")
  f:SetSize(226, 94)
  f:SetPoint("TOP", UIParent, "TOP", 0, -72)
  f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
  f:SetFrameStrata("MEDIUM")
  f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=12, insets={left=3,right=3,top=3,bottom=3}})
  f:SetBackdropColor(0.035, 0.045, 0.07, 0.96); f:SetBackdropBorderColor(0.60, 0.44, 0.20, 1)

  local header = CreateFrame("Button", nil, f)
  header:SetPoint("TOPLEFT", 6, -5); header:SetPoint("TOPRIGHT", -28, -5); header:SetHeight(20); header:RegisterForDrag("LeftButton")
  header:SetScript("OnDragStart", function() f:StartMoving() end)
  header:SetScript("OnDragStop", function()
    f:StopMovingOrSizing()
    local point, _, _, x, y = f:GetPoint()
    NS.db.navigation.point, NS.db.navigation.x, NS.db.navigation.y = point, x, y
  end)
  f.title = header:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  f.title:SetPoint("LEFT", 4, 0); f.title:SetTextColor(unpack(GOLD)); f.title:SetText("FOREVERPATH · NAVIGATION")

  local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
  close:SetSize(20, 20); close:SetPoint("TOPRIGHT", -3, -3); close:SetScript("OnClick", function() NS:SetNavigationShown(false) end)

  f.arrow = f:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
  f.arrow:SetPoint("LEFT", 14, -8); f.arrow:SetWidth(48); f.arrow:SetJustifyH("CENTER"); f.arrow:SetTextColor(unpack(GOLD)); f.arrow:SetText("↑")
  f.target = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  f.target:SetPoint("TOPLEFT", 72, -31); f.target:SetWidth(140); f.target:SetJustifyH("LEFT"); f.target:SetText("Ziel wird geladen …")
  f.distance = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  f.distance:SetPoint("TOPLEFT", 72, -53); f.distance:SetWidth(140); f.distance:SetTextColor(0.65, 0.72, 0.84)
  f.hint = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  f.hint:SetPoint("TOPLEFT", 72, -70); f.hint:SetWidth(140); f.hint:SetTextColor(0.55, 0.78, 0.62)

  if self.db.navigation.point and self.db.navigation.x and self.db.navigation.y then
    f:ClearAllPoints(); f:SetPoint(self.db.navigation.point, UIParent, self.db.navigation.point, self.db.navigation.x, self.db.navigation.y)
  end
  f:SetScript("OnUpdate", function(_, elapsed)
    f.elapsed = (f.elapsed or 0) + elapsed
    if f.elapsed >= 0.25 then f.elapsed = 0; NS:RefreshNavigation() end
  end)

  local line = CreateFrame("Frame", "ForeverPathMinimapRouteLine", Minimap)
  line:SetAllPoints(Minimap); line:SetFrameLevel(Minimap:GetFrameLevel() + 3); line:Hide()
  line.segment = line:CreateTexture(nil, "OVERLAY")
  line.segment:SetTexture("Interface\\Buttons\\WHITE8X8"); line.segment:SetVertexColor(BLUE[1], BLUE[2], BLUE[3], 0.90); line.segment:SetHeight(3)
  line.dot = line:CreateTexture(nil, "OVERLAY")
  line.dot:SetTexture("Interface\\Buttons\\WHITE8X8"); line.dot:SetVertexColor(GOLD[1], GOLD[2], GOLD[3], 1); line.dot:SetSize(8, 8)

  self.navigationFrame, self.minimapRouteLine = f, line
  self:RefreshNavigation()
end

function NS:SetNavigationShown(shown)
  ensureSettings()
  NS.db.navigation.show = shown ~= false
  if self.navigationFrame then self.navigationFrame:SetShown(NS.db.navigation.show) end
  if not NS.db.navigation.show and self.minimapRouteLine then self.minimapRouteLine:Hide() end
  if NS.db.navigation.show then self:RefreshNavigation() end
end

function NS:ToggleNavigation()
  ensureSettings()
  self:SetNavigationShown(not NS.db.navigation.show)
end

function NS:RefreshNavigation()
  if not self.navigationFrame or not self.db then return end
  ensureSettings()
  self.navigationFrame:SetScale(self.db.navigation.scale or 1)
  self.navigationFrame:SetShown(self.db.navigation.show ~= false)
  if self.db.navigation.show == false then if self.minimapRouteLine then self.minimapRouteLine:Hide() end; return end

  local data = getTargetData()
  if not data then
    self.navigationFrame.arrow:SetText("•"); self.navigationFrame.target:SetText("Kein Wegpunkt"); self.navigationFrame.distance:SetText("Schritt ohne Zielkoordinaten"); self.navigationFrame.hint:SetText("")
    if self.minimapRouteLine then self.minimapRouteLine:Hide() end
    return
  end
  local targetName = data.target.hint or data.target.title or "Questziel"
  self.navigationFrame.target:SetText(targetName)
  if not data.sameMap then
    self.navigationFrame.arrow:SetText("⇢"); self.navigationFrame.distance:SetText("Gebietswechsel erforderlich"); self.navigationFrame.hint:SetText("Wegpunkt auf der Weltkarte gesetzt")
    if self.minimapRouteLine then self.minimapRouteLine:Hide() end
    return
  end
  self.navigationFrame.arrow:SetText(data.direction or "↑")
  self.navigationFrame.distance:SetText(string.format("%.0f Kartenmeter · ETA ~%s", data.distance or 0, formatETA(data.eta)))
  self.navigationFrame.hint:SetText("Dynamischer Quest-Wegpunkt")

  local line = self.minimapRouteLine
  if not line or not self.db.navigation.minimapLine then return end
  local mapWidth, mapHeight = Minimap:GetWidth(), Minimap:GetHeight()
  local mapID = data.mapID
  local ok, position = pcall(C_Map.GetPlayerMapPosition, mapID, "player")
  if not ok or not position or not position.GetXY then line:Hide(); return end
  local px, py = position:GetXY()
  local dx, dy = data.target.x / 100 - px, data.target.y / 100 - py
  local sx, sy = dx * mapWidth * 2.0, -dy * mapHeight * 2.0
  local radius = math.min(mapWidth, mapHeight) * 0.44
  local length = math.sqrt(sx * sx + sy * sy)
  if length < 2 then line:Hide(); return end
  if length > radius then sx, sy = sx / length * radius, sy / length * radius; length = radius end
  line.segment:ClearAllPoints(); line.segment:SetPoint("CENTER", Minimap, "CENTER", sx / 2, sy / 2); line.segment:SetSize(length, 3); line.segment:SetRotation(math.atan2(sy, sx))
  line.dot:ClearAllPoints(); line.dot:SetPoint("CENTER", Minimap, "CENTER", sx, sy)
  line:Show()
end
