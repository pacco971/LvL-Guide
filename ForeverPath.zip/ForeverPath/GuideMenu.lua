local NS = ForeverPath

-- Hierarchical Horde guide menu. Labels come from the user-provided,
-- unencrypted Horde guide source; the menu itself is native ForeverPath UI.
local function leaf(key, title, range, routeMode, guideKey)
  return {kind="leaf", key=key, title=title, range=range, routeMode=routeMode,
    guideKey=guideKey or "horde_barrens", summary="Horde-Guide " .. range .. " · " .. title}
end

local function range(key, title, children)
  return {kind="submenu", key=key, title=title, children=children}
end

local function leaves(prefix, routeMode, items, guideKey)
  local result = {}
  for index, item in ipairs(items) do
    result[#result + 1] = leaf(prefix .. ":" .. tostring(index), item[2], item[1], routeMode, guideKey)
  end
  return result
end

local dungeon22 = {
  {"22-24", "Hügellandhof"}, {"24-25", "Burg Schattenfang"},
  {"25-26", "Südliches Brachland"}, {"26-28", "Eschental"},
  {"28-29", "Tiefschwarze Grotte"}, {"29-30", "Tausend Nadeln"},
}
local dungeon30 = {
  {"30-31", "Kral der Klingenhauer"}, {"31-31", "Gnomeregan"},
  {"31-32", "Hügellandhof / Arathi"}, {"32-33", "Ausgrabung Site: Sumpfland"},
  {"33-34", "Stadt Dalaran"}, {"34-35", "Flimmern Flats"},
  {"35-37", "Nördliches Schlingendorntal"}, {"37-38", "Düstermarschen"},
  {"38-38", "Hügel der Klingenhauer"}, {"38-39", "Alterac / Arathi"},
  {"39-40", "Ödland"},
}
local dungeon40 = {
  {"40-41", "Schlingendorntal"}, {"41-41", "Sümpfe des Elends"},
  {"41-41", "Desolace II"}, {"41-43", "Tanaris / Dustwallow"},
  {"43-44", "Feralas"}, {"44-45", "Southern Stranglethorn"},
  {"45-46", "Sümpfe des Elends"}, {"46-48", "Tanaris"},
  {"48-49", "Das Hinterland"}, {"49-50", "Maraudon"},
}
local dungeon50 = {
  {"50-51", "Stranglethorn / Verwüstete Lande"},
  {"51-52", "Sengende Schlucht / Brennende Steppe"},
  {"52-53", "Azshara"}, {"53-54", "Teufelswald"},
  {"54-55", "Krater von Un'Goro"}, {"55-56", "Teufelswald / Winterquell"},
  {"56-57", "Schwarzfelstiefen"}, {"57-59", "Westliche PL / Östliche PL"},
  {"59-59", "Winterquell / Silithus I"}, {"59-60", "Winterquell / Silithus II"},
}

local route22 = {
  {"22-24", "Hügellandhof"}, {"24-26", "Südliches Brachland / Stonetalon"},
  {"26-28", "Eschental"}, {"28-30", "Tausend Nadeln"},
}
local route30 = {
  {"30-33", "Hügellandhof / Arathi"}, {"33-34", "Flimmern Flats"},
  {"34-35", "Desolace"}, {"35-37", "Nördliches Schlingendorntal"},
  {"37-38", "Düstermarschen"}, {"38-39", "Alterac / Arathi"},
  {"39-40", "Ödland"},
}
local route40 = {
  {"40-41", "Schlingendorntal"}, {"41-42", "Sümpfe des Elends"},
  {"41-43", "Desolace II"}, {"41-43", "Tanaris / Dustwallow"},
  {"43-44", "Feralas"}, {"44-45", "Southern Stranglethorn"},
  {"45-46", "Sümpfe des Elends"}, {"46-48", "Tanaris"},
  {"48-49", "Das Hinterland"}, {"49-50", "Feralas"},
}
local route50 = {
  {"50-51", "Stranglethorn / Verwüstete Lande"},
  {"51-52", "Sengende Schlucht / Brennende Steppe"},
  {"52-53", "Azshara"}, {"53-54", "Teufelswald"},
  {"54-55", "Krater von Un'Goro"}, {"55-56", "Teufelswald / Winterquell"},
  {"56-58", "Westliche Pestländer / Östliche Pestländer"},
  {"58-59", "Winterquell / Silithus I"}, {"59-60", "Winterquell / Silithus II"},
}

NS.hordeGuideMenu = {
  {kind="submenu", key="dungeon", title="ForeverPath Dungeonführer (H)", children={
    range("dungeon:1", "Dungeonführer 1–22", leaves("dungeon:1", "dungeon", {
      {"1-6", "Tirisfal"}, {"6-12", "Tirisfal"}, {"12-14", "Silberwald"},
      {"14-16", "Das Brachland"}, {"16-18", "Die Flammenschlund-Vorquests"},
      {"18-22", "Die Höhlen des Wehklagens"},
    })),
    range("dungeon:2", "Dungeonführer 22–30", leaves("dungeon:2", "dungeon", dungeon22)),
    range("dungeon:3", "Dungeonführer 30–40", leaves("dungeon:3", "dungeon", dungeon30)),
    range("dungeon:4", "Dungeonführer 40–50", leaves("dungeon:4", "dungeon", dungeon40)),
    range("dungeon:5", "Dungeonführer 50–60", leaves("dungeon:5", "dungeon", dungeon50)),
  }},
  {kind="submenu", key="route", title="ForeverPath Route (H)", children={
    range("route:1", "Schnellste Route 1–22", leaves("route:1", "speed", {
      {"1-6", "Tirisfal"}, {"1-6", "Mulgore"}, {"1-9", "Skyborne"},
      {"6-10", "Durotar"}, {"6-12", "Mulgore"}, {"9-12", "Skyborne"},
      {"10-12", "Durotar"}, {"10-12", "Tirisfal (Orc/Troll)"},
    })),
    range("route:2", "Schnellste Route 22–30", leaves("route:2", "speed", route22)),
    range("route:3", "Schnellste Route 30–40", leaves("route:3", "speed", route30)),
    range("route:4", "Schnellste Route 40–50", leaves("route:4", "speed", route40)),
    range("route:5", "Schnellste Route 50–60", leaves("route:5", "speed", route50)),
  }},
  {kind="submenu", key="quests", title="ForeverPath Verliesquests (H)", children={
    range("quests:1", "Verliesquests 15–30", leaves("quests:1", "dungeon", {
      {"15-30", "Der Flammenschlund"}, {"15-30", "Ruinen von Lordaeron"},
      {"15-30", "Die Höhlen des Wehklagens"}, {"15-30", "Burg Schattenfang"},
      {"15-30", "Tiefschwarze Grotte"},
    })),
    range("quests:2", "Verliesquests 30–50", leaves("quests:2", "dungeon", {
      {"30-50", "Kral der Klingenhauer"}, {"30-50", "Gnomeregan"},
      {"30-50", "Ausgrabung Site: Sumpfland"}, {"30-50", "Stadt Dalaran"},
      {"30-50", "Hügel der Klingenhauer"}, {"30-50", "Scharlachrotes Kloster"},
      {"30-50", "Uldaman"}, {"30-50", "Zul'Farrak"}, {"30-50", "Maraudon"},
    })),
    range("quests:3", "Verliesquests 50–60", leaves("quests:3", "dungeon", {
      {"50-60", "Versunkener Tempel"}, {"50-60", "Schwarzfelstiefen"},
      {"50-60", "Lower Schwarzfelsspitze"}, {"50-60", "Obere Schwarzfelsspitze"},
      {"50-60", "Scholomance"}, {"50-60", "Stratholme"},
      {"50-60", "Düsterbruch (East)"}, {"50-60", "Düsterbruch (West)"},
      {"50-60", "Düsterbruch (North)"},
    })),
  }},
}

local byKey = {}
local function indexNodes(nodes)
  for _, node in ipairs(nodes or {}) do
    byKey[node.key] = node
    indexNodes(node.children)
  end
end
indexNodes(NS.hordeGuideMenu)

function NS:GetGuideMenuNode(key)
  return byKey[key]
end

-- Manual menu choices may target a future level range. The normal guide
-- chooser remains level-filtered; this menu is an explicit override.
local previousGetActiveGuide = NS.GetActiveGuide
local previousBuildGuideSpecs = NS.BuildGuideSpecs

function NS:GetActiveGuide(context)
  local selected = self.db and self.db.menuGuideKey and byKey[self.db.menuGuideKey]
  if selected and selected.kind == "leaf" then return selected, false end
  return previousGetActiveGuide(self, context)
end

function NS:BuildGuideSpecs(context)
  local selected = self.db and self.db.menuGuideKey and byKey[self.db.menuGuideKey]
  if selected and selected.kind == "leaf" then
    local routeSet = self.routes and self.routes.horde
    local route = routeSet and routeSet[selected.routeMode or "speed"]
    if route and #route > 0 then return route, selected, false end
  end
  return previousBuildGuideSpecs(self, context)
end

function NS:ActivateGuideMenuLeaf(node)
  if not node or node.kind ~= "leaf" then return false end
  self:EnsureSettings()
  self.db.menuGuideKey = node.key
  self.db.menuGuideTitle = node.title
  self.db.guideKey = node.guideKey or "horde_barrens"
  self.db.mode = node.routeMode or "speed"
  self.db.route = "horde"
  self.db.step = 1
  self.db.selectedStepID = nil
  if self.InvalidateQuestPlan then self:InvalidateQuestPlan() end
  if self.InvalidateFastRoute then self:InvalidateFastRoute() end
  self:HideGuideMenu()
  self:Refresh()
  self:Print("Guide aktiviert: " .. tostring(node.range or "") .. " · " .. tostring(node.title or ""))
  return true
end

local GOLD = {0.95, 0.72, 0.14}
local BLUE = {0.20, 0.52, 0.86}

local function menuButton(parent, width, height)
  local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
  b:SetSize(width, height); b:EnableMouse(true)
  b:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=8, insets={left=2,right=2,top=2,bottom=2}})
  b:SetBackdropColor(0.035, 0.035, 0.05, 0.90); b:SetBackdropBorderColor(0.10, 0.16, 0.26, 0.90)
  b.text = b:CreateFontString(nil, "OVERLAY", "GameFontNormal"); b.text:SetPoint("LEFT", 12, 0)
  b.text:SetWidth(width - 32); b.text:SetJustifyH("LEFT"); b.text:SetWordWrap(false)
  return b
end

local function menuPanel(width, height)
  local p = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
  p:SetSize(width, height); p:SetFrameStrata("TOOLTIP"); p:SetClampedToScreen(true); p:EnableMouse(true)
  p:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", edgeSize=16, insets={left=5,right=5,top=5,bottom=5}})
  p:SetBackdropColor(0.015, 0.018, 0.028, 0.96); p:SetBackdropBorderColor(0.16, 0.22, 0.34, 1)
  return p
end

local function screenWidth()
  return (GetScreenWidth and GetScreenWidth()) or (UIParent and UIParent:GetWidth()) or 1920
end

function NS:CreateGuideMenu()
  if self.guideMenu then return self.guideMenu end
  local root = menuPanel(276, 330)
  root.title = root:CreateFontString(nil, "OVERLAY", "GameFontNormal"); root.title:SetPoint("TOPLEFT", 16, -14)
  root.title:SetText("Verfügbare Guides"); root.title:SetTextColor(GOLD[1], GOLD[2], GOLD[3], 1)
  root.close = menuButton(root, 26, 24); root.close:SetPoint("TOPRIGHT", -8, -8)
  root.close.text:SetText("×"); root.close.text:SetPoint("CENTER"); root.close.text:SetWidth(20)
  root.close:SetScript("OnClick", function() NS:HideGuideMenu() end)
  root.panels = {root}; self.guideMenu = root; root:Hide()
  return root
end

function NS:HideGuideMenu()
  if not self.guideMenu then return end
  for _, panel in ipairs(self.guideMenu.panels or {}) do panel:Hide() end
end

function NS:ShowGuideMenuSubmenu(parent, node)
  local root = self:CreateGuideMenu()
  for _, other in ipairs(root.panels or {}) do
    if other ~= root and other ~= parent then other:Hide() end
  end
  local panel = node._panel
  local count = #(node.children or {})
  local height = math.max(78, 42 + count * 27)
  if not panel then
    panel = menuPanel(250, height); node._panel = panel; root.panels[#root.panels + 1] = panel
  else
    panel:SetHeight(height); for _, child in ipairs(panel.buttons or {}) do child:Hide() end
  end
  panel.buttons = panel.buttons or {}
  panel.title = panel.title or panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  panel.title:ClearAllPoints(); panel.title:SetPoint("TOPLEFT", 14, -12); panel.title:SetText(node.title); panel.title:SetTextColor(GOLD[1], GOLD[2], GOLD[3], 1)
  panel:ClearAllPoints()
  if (parent:GetRight() or 0) + 250 < screenWidth() then panel:SetPoint("TOPLEFT", parent, "TOPRIGHT", -2, 0) else panel:SetPoint("TOPRIGHT", parent, "TOPLEFT", 2, 0) end
  panel:Show(); panel:Raise()
  for index, child in ipairs(node.children or {}) do
    local b = panel.buttons[index] or menuButton(panel, 226, 24); panel.buttons[index] = b
    b:ClearAllPoints(); b:SetPoint("TOPLEFT", 10, -36 - (index - 1) * 27); b:Show()
    b.text:SetText((child.range and (child.range .. " ") or "") .. child.title .. ((child.kind == "submenu") and "  ▶" or ""))
    b.text:SetTextColor(child.kind == "submenu" and 0.86 or 0.82, child.kind == "submenu" and 0.82 or 0.86, child.kind == "submenu" and 0.30 or 0.94, 1)
    b:SetScript("OnEnter", function() b:SetBackdropColor(0.08, 0.16, 0.28, 0.98); b:SetBackdropBorderColor(BLUE[1], BLUE[2], BLUE[3], 1); if child.kind == "submenu" then NS:ShowGuideMenuSubmenu(panel, child) end end)
    b:SetScript("OnLeave", function() b:SetBackdropColor(0.035, 0.035, 0.05, 0.90); b:SetBackdropBorderColor(0.10, 0.16, 0.26, 0.90) end)
    b:SetScript("OnClick", function() if child.kind == "leaf" then NS:ActivateGuideMenuLeaf(child) else NS:ShowGuideMenuSubmenu(panel, child) end end)
  end
end

function NS:RefreshGuideMenu()
  local root = self:CreateGuideMenu(); root.buttons = root.buttons or {}
  for _, button in ipairs(root.buttons) do button:Hide() end
  local rows = NS.hordeGuideMenu
  for index, node in ipairs(rows) do
    local b = root.buttons[index] or menuButton(root, 256, 24); root.buttons[index] = b
    b:ClearAllPoints(); b:SetPoint("TOPLEFT", 10, -38 - (index - 1) * 27); b:Show()
    b.text:SetText(node.title .. "  ▶"); b.text:SetTextColor(0.86, 0.86, 0.94, 1)
    b:SetScript("OnEnter", function() b:SetBackdropColor(0.08, 0.16, 0.28, 0.98); b:SetBackdropBorderColor(BLUE[1], BLUE[2], BLUE[3], 1); NS:ShowGuideMenuSubmenu(root, node) end)
    b:SetScript("OnLeave", function() b:SetBackdropColor(0.035, 0.035, 0.05, 0.90); b:SetBackdropBorderColor(0.10, 0.16, 0.26, 0.90) end)
  end
  local actions = {
    {"Optionen...", function() NS:HideGuideMenu(); NS:Toggle(); if NS.frame then NS:ShowTab("settings") end end},
    {"Guides importieren", function() NS:HideGuideMenu(); if NS.ShowDiagnostics then NS:ShowDiagnostics() end end},
    {"Levelreport", function() NS:HideGuideMenu(); NS:PrintRecommendation() end},
    {"Feedback-Formular öffnen", function() NS:HideGuideMenu(); NS:Print("Öffne den Fehlerbericht unter Optionen; dort kannst du ihn direkt kopieren.") end},
    {"Schließen", function() NS:HideGuideMenu() end},
  }
  local base = 38 + #rows * 27 + 6
  for index, action in ipairs(actions) do
    local b = root.buttons[#rows + index] or menuButton(root, 256, 23); root.buttons[#rows + index] = b
    b:ClearAllPoints(); b:SetPoint("TOPLEFT", 10, -base - (index - 1) * 25); b:Show()
    b.text:SetText(action[1]); b.text:SetTextColor(index == #actions and 0.78 or 0.86, index == #actions and 0.82 or 0.86, index == #actions and 0.90 or 0.94, 1)
    b:SetScript("OnClick", action[2])
    b:SetScript("OnEnter", function() b:SetBackdropColor(0.08, 0.16, 0.28, 0.98); b:SetBackdropBorderColor(BLUE[1], BLUE[2], BLUE[3], 1) end)
    b:SetScript("OnLeave", function() b:SetBackdropColor(0.035, 0.035, 0.05, 0.90); b:SetBackdropBorderColor(0.10, 0.16, 0.26, 0.90) end)
  end
end

function NS:ToggleGuideMenu()
  local root = self:CreateGuideMenu()
  if root:IsShown() then self:HideGuideMenu(); return end
  self:RefreshGuideMenu()
  local x, y = GetCursorPosition(); local scale = UIParent:GetEffectiveScale()
  root:ClearAllPoints(); root:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", (x or 200) / scale, (y or 200) / scale)
  root:Show(); root:Raise()
end
