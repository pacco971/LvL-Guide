local NS = ForeverPath
local function tr(text) return NS.L and NS:L(text) or text end

-- Eigenständiger Solo-Routen-Scorer. Er nutzt nur die bereits importierten
-- Questdaten und die Live-Questlogdaten; er startet keine geschützten Aktionen.
local function lower(value)
  return value and string.lower(tostring(value)) or ""
end

local function number(value)
  if type(value) ~= "number" then return nil end
  if issecretvalue then
    local ok, secret = pcall(issecretvalue, value)
    if ok and secret then return nil end
  end
  return value
end

local function zoneMatches(a, b)
  a, b = lower(a), lower(b)
  if a == "" or b == "" then return false end
  return a == b or string.find(a, b, 1, true) ~= nil or string.find(b, a, 1, true) ~= nil
end

local function chainCount(value)
  if type(value) ~= "table" then return 0 end
  local count = 0
  for _ in pairs(value) do count = count + 1 end
  return count
end

local function recordPoint(self, record)
  if not record then return nil end
  local point = record.startPoint or record.turnInPoint
  if point and number(point.mapID) and number(point.x) and number(point.y) then
    return {mapID=point.mapID, x=point.x, y=point.y, name=point.name}
  end
  if number(record.mapID) and number(record.x) and number(record.y) then
    return {mapID=record.mapID, x=record.x, y=record.y, name=record.title}
  end
  local routes = self.externalRoutesByQuest and self.externalRoutesByQuest[record.id] or {}
  for _, route in ipairs(routes or {}) do
    local candidate = route.giver or route.objective or route.turnin
    if candidate and number(candidate.mapID) and number(candidate.x) and number(candidate.y) then
      return {mapID=candidate.mapID, x=candidate.x, y=candidate.y, name=candidate.name}
    end
  end
  return nil
end

local function currentPoint(self, context)
  if not context or not context.mapID or not self.GetSafeMapPosition then return nil end
  local x, y = self:GetSafeMapPosition(context.mapID, "player")
  if not x or not y then return nil end
  return {mapID=context.mapID, x=x * 100, y=y * 100, name="Spieler"}
end

local function pointDistance(a, b)
  if not a or not b then return nil end
  if a.mapID ~= b.mapID then return nil end
  local dx, dy = (a.x or 0) - (b.x or 0), (a.y or 0) - (b.y or 0)
  return math.sqrt(dx * dx + dy * dy)
end

function NS:GetFastQuestScore(record, context, previousPoint, previousZone)
  context = context or (self.GetPlanningContext and self:GetPlanningContext()) or {}
  local level = number(context.level) or (self.GetPlayerLevel and self:GetPlayerLevel()) or 1
  local questLevel = number(record and (record.level or record.minLevel)) or level
  local levelGap = math.abs(questLevel - level)
  local score = math.max(0, 42 - levelGap * 9)
  local reasons = {}
  local components = {xp=0, level=0, zone=0, chain=0, travel=0, data=0, gold=0}

  local classToken=context.class or (self.GetClassToken and self:GetClassToken())
  local classAllowed=record and record.classes and next(record.classes) and record.classes[classToken]
  if classAllowed then
    score=score+14; reasons[#reasons+1]="klassenspezifisch"
  elseif record and record.class and record.class==classToken then
    score=score+14; reasons[#reasons+1]="Klassenquest"
  end

  components.level = math.max(0, 28 - levelGap * 7)
  score = score + components.level
  if levelGap <= 1 then reasons[#reasons + 1] = "passendes Level" end

  if zoneMatches(record and record.zone, context.zone) or zoneMatches(record and record.zone, context.mapName) then
    components.zone = 30
    score = score + components.zone
    reasons[#reasons + 1] = "aktuelle Zone"
  elseif record and context.mapID and record.mapID == context.mapID then
    components.zone = 20
    score = score + components.zone
    reasons[#reasons + 1] = "gleiche Karte"
  else
    components.zone = -8
    score = score + components.zone
  end

  local point = recordPoint(self, record)
  if point then
    components.data = 10
    score = score + components.data
  else
    components.data = -20
    score = score + components.data
    reasons[#reasons + 1] = "Koordinaten fehlen"
  end

  if previousZone and zoneMatches(record and record.zone, previousZone) then
    score = score + 14
    reasons[#reasons + 1] = "Ziele gebündelt"
  end
  if previousPoint and point then
    local distance = pointDistance(previousPoint, point)
    if distance then
      components.travel = math.min(42, distance * 0.55)
      score = score - components.travel
    elseif previousPoint.mapID ~= point.mapID then
      components.travel = 24
      score = score - components.travel
    end
  end

  local metric = self.db and self.db.questMetrics and record and self.db.questMetrics[record.id]
  local knownXP = number(metric and metric.xp) or number(record and (record.rewardXP or record.xp))
  if knownXP and knownXP > 0 then
    components.xp = math.min(38, knownXP / 90)
    score = score + components.xp
    reasons[#reasons + 1] = "eigene XP-Messung"
  else
    -- ForeverDB liefert nicht für jede Quest einen statischen XP-Wert. In dem
    -- Fall bleibt es eine klar markierte Level-/Ketten-Schätzung statt einer
    -- erfundenen exakten Belohnung.
    components.xp = math.max(4, 18 - levelGap * 3)
    score = score + components.xp
  end

  local followups = chainCount(record and record.chainNext)
  if followups > 0 then
    components.chain = math.min(18, followups * 5)
    score = score + components.chain
    reasons[#reasons + 1] = "Folgequestwert"
  end
  if self.GetQuestGoldForStep then
    local gold = self:GetQuestGoldForStep({questID=record and record.id, record=record})
    components.gold = math.min(25, gold or 0)
    if components.gold > 0 then
      score = score + components.gold
      reasons[#reasons + 1] = string.format("%s %.2fg", tr("Questgold"), gold)
    end
  end
  if record and record.foreverDB then score = score + 4 end
  if record and record.isInstanceQuest then score = score - 100 end

  return score, {
    point=point,
    reasons=reasons,
    components=components,
    knownXP=knownXP,
    estimated=not knownXP,
  }
end

local function makePreviewStep(record, score, detail)
  return {
    id="fast:" .. tostring(record.id),
    questID=record.id,
    questIDs={record.id},
    phase="accept",
    title="Annehmen: " .. (record.title or tostring(record.id)),
    liveTitle=nil,
    record=record,
    level=record.level or record.minLevel,
    zone=record.zone or "Unbekannt",
    mapID=record.mapID,
    priority=score,
    fastDetail=detail,
  }
end

function NS:GetFastLevelRoute(limit)
  limit = math.max(5, math.min(18, limit or 12))
  local context = (self.GetPlanningContext and self:GetPlanningContext()) or {level=1, zone="Unbekannt"}
  local state = self.questState or (self.RefreshQuestState and self:RefreshQuestState()) or {quests={}}
  local activeCount = 0
  for _ in pairs(state.quests or {}) do activeCount = activeCount + 1 end
  local key = table.concat({context.mapID or 0, lower(context.zone), context.level or 1, context.faction or "", context.class or "", activeCount, self.questStateRevision or 0, self.db and self.db.routeStrategy or "balanced"}, "|")
  if self.fastRouteCache and self.fastRouteCache.key == key and self.fastRouteCache.limit == limit then
    return self.fastRouteCache.rows, self.fastRouteCache.meta
  end

  local rows, seen = {}, {}
  local previousPoint = currentPoint(self, context)
  local previousZone = context.zone

  -- Das Live-Questlog bleibt immer vorn. So wird keine offene Quest für eine
  -- theoretisch schnellere, aber noch nicht angenommene Quest verdrängt.
  local plan = self.GetQuestPlan and self:GetQuestPlan() or {}
  for index, step in ipairs(plan) do
    if step and step.questID and step.phase ~= "done" and not seen[step.questID] then
      seen[step.questID] = true
      rows[#rows + 1] = {step=step, score=1000 - index, source="Questlog", detail={estimated=false, reasons={"bereits im Questlog"}, components={}}}
      local point = self.GetBestWaypoint and self:GetBestWaypoint(step) or nil
      if point then previousPoint = point end
      previousZone = step.zone or previousZone
      if #rows >= math.min(4, limit) then break end
    end
  end

  local candidates = {}
  for id, record in pairs(self.questDB or {}) do
    if type(id) == "number" and record and not seen[id] and not record.repeatable and not record.isInstanceQuest then
      local eligible = self.IsQuestEligible and self:IsQuestEligible(record)
      if eligible then candidates[#candidates + 1] = record end
    end
  end

  while #rows < limit and #candidates > 0 do
    local bestIndex, bestScore, bestDetail
    for index, record in ipairs(candidates) do
      local score, detail = self:GetFastQuestScore(record, context, previousPoint, previousZone)
      if not bestScore or score > bestScore or (score == bestScore and (record.title or "") < (candidates[bestIndex].title or "")) then
        bestIndex, bestScore, bestDetail = index, score, detail
      end
    end
    if not bestIndex then break end
    local record = table.remove(candidates, bestIndex)
    seen[record.id] = true
    rows[#rows + 1] = {step=makePreviewStep(record, bestScore, bestDetail), score=bestScore, source="ForeverDB", detail=bestDetail}
    previousPoint = bestDetail.point or previousPoint
    previousZone = record.zone or previousZone
  end

  local meta = {level=context.level or 1, zone=context.mapName or context.zone or "Unbekannt", activeCount=activeCount, estimated=true, generatedAt=GetTime and GetTime() or 0, candidateCount=#candidates}
  self.fastRouteCache = {key=key, limit=limit, rows=rows, meta=meta}
  return rows, meta
end

function NS:InvalidateFastRoute()
  self.fastRouteCache = nil
end

function NS:SetFastRouteActive(active)
  self:EnsureSettings()
  self.db.routeStrategy = active and "fast" or "balanced"
  self.db.autoSolo = active == true
  self:InvalidateFastRoute()
  if self.InvalidateQuestPlan then self:InvalidateQuestPlan() end
  self:Refresh()
  self:Print(active and "Schnellleveln aktiv: Solo-Route wird nach XP, Reise und Questketten bewertet." or "Schnellleveln deaktiviert: ausgewogene Route aktiv.")
end

function NS:IsFastRouteActive()
  return self.db and self.db.routeStrategy == "fast" or false
end
