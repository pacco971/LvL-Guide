local NS=ForeverPath
function NS:InitSession()
  if self.session then return end
  self.session={started=GetTime(),lastTick=GetTime(),xp=0,deaths=0,lastXP=UnitXP("player"),maxXP=UnitXPMax("player"),level=UnitLevel("player"),elapsed=0,travel=0,combat=0,dead=0}
  self.db.zoneMetrics=self.db.zoneMetrics or {}; self.db.questMetrics=self.db.questMetrics or {}; self.db.deathSpots=self.db.deathSpots or {}; self.db.levelTimes=self.db.levelTimes or {}
end
function NS:UpdateSessionContext()
  self:InitSession(); local s=self.session; local now=GetTime(); local dt=math.max(0,now-s.lastTick); s.lastTick=now; s.elapsed=s.elapsed+dt
  local zone=s.zone or self:GetPlayerZone()
  local z=self.db.zoneMetrics[zone] or {seconds=0,xp=0}; z.seconds=z.seconds+dt; self.db.zoneMetrics[zone]=z
  self.db.levelTimes[s.level]=(self.db.levelTimes[s.level] or 0)+dt
  if UnitIsDeadOrGhost and UnitIsDeadOrGhost("player") then s.dead=s.dead+dt
  elseif UnitAffectingCombat and UnitAffectingCombat("player") then s.combat=s.combat+dt
  elseif GetUnitSpeed and GetUnitSpeed("player")>0 then s.travel=s.travel+dt end
  s.zone=self:GetPlayerZone()
end
function NS:RecordSessionXP()
  self:UpdateSessionContext(); local s=self.session
  local xp,level=UnitXP("player"),UnitLevel("player")
  local gain=level>s.level and math.max(0,s.maxXP-s.lastXP)+xp or math.max(0,xp-s.lastXP)
  s.xp=s.xp+gain; local z=self.db.zoneMetrics[s.zone]; if z then z.xp=z.xp+gain end
  s.lastXP,s.maxXP,s.level=xp,UnitXPMax("player"),level
end
function NS:RecordSessionDeath()
  self:UpdateSessionContext(); self.session.deaths=self.session.deaths+1
  local map=C_Map and C_Map.GetBestMapForUnit("player"); local p=map and C_Map.GetPlayerMapPosition(map,"player")
  if p then local x,y=p:GetXY(); table.insert(self.db.deathSpots,{mapID=map,x=x*100,y=y*100,at=time()}); if #self.db.deathSpots>100 then table.remove(self.db.deathSpots,1) end end
end
function NS:GetSessionStats()
  self:UpdateSessionContext(); local s=self.session; local maximum=UnitXPMax("player")
  return {elapsed=s.elapsed,xp=s.xp,xpPerHour=s.xp*3600/math.max(1,s.elapsed),progress=maximum>0 and UnitXP("player")/maximum or 0,deaths=s.deaths,level=s.level}
end
function NS:GetSessionText() local s=self:GetSessionStats(); return string.format("%.0f XP/h · %d Min. · %d Tode",s.xpPerHour,s.elapsed/60,s.deaths) end
function NS:GetSessionDetail() return self:GetSessionText() end
function NS:GetLearningDetails()
  self:UpdateSessionContext(); local lines={self:GetSessionText()}
  for zone,z in pairs(self.db.zoneMetrics) do lines[#lines+1]=string.format("%s: %.0f XP/h · %.1f Min.",zone,z.xp*3600/math.max(1,z.seconds),z.seconds/60) end
  lines[#lines+1]=string.format("Bewegung %.1f Min. · Kampf %.1f · Tot %.1f",self.session.travel/60,self.session.combat/60,self.session.dead/60)
  lines[#lines+1]="Gespeicherte Todesstellen: "..#self.db.deathSpots
  for id,q in pairs(self.db.questMetrics) do if q.seconds then lines[#lines+1]=string.format("Quest %d: %.1f Min. · %d XP · Planung %s",id,q.seconds/60,q.xp or 0,q.estimatedSeconds and string.format("%.1f Min.",q.estimatedSeconds/60) or "unbekannt") end end
  return table.concat(lines,"\n")
end
