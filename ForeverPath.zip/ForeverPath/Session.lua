local NS = ForeverPath

function NS:InitSession()
  if not self.db then return end
  self.db.session = self.db.session or {}
  local session = self.db.session
  local now = time and time() or 0
  if not session.startedAt or not session.lastSeen or now - session.lastSeen > 300 then
    session.startedAt = now
    session.startLevel = UnitLevel and UnitLevel("player") or 1
    session.startXP = UnitXP and UnitXP("player") or 0
    session.xpGained = 0
    session.deaths = 0
    session.zoneTimes = {}
    session.levelTimes = {}
    session.currentZone = nil
    session.zoneStartedAt = now
    session.currentLevel = session.startLevel
    session.levelStartedAt = now
    session.lastXP = session.startXP
    session.lastMaxXP = UnitXPMax and UnitXPMax("player") or 0
    session.lastLevel = session.startLevel
  end
  session.lastSeen = now
end

function NS:UpdateSessionContext()
  if not self.db then return end
  self:InitSession()
  local session, now = self.db.session, time and time() or 0
  local zone = self.GetPlayerZone and self:GetPlayerZone() or "Unbekannt"
  if session.currentZone and session.currentZone ~= zone then
    session.zoneTimes[session.currentZone] = (session.zoneTimes[session.currentZone] or 0) + math.max(0, now - (session.zoneStartedAt or now))
    session.currentZone, session.zoneStartedAt = zone, now
  elseif not session.currentZone then
    session.currentZone, session.zoneStartedAt = zone, now
  end
  local level = UnitLevel and UnitLevel("player") or session.currentLevel or 1
  if session.currentLevel and session.currentLevel ~= level then
    session.levelTimes[session.currentLevel] = (session.levelTimes[session.currentLevel] or 0) + math.max(0, now - (session.levelStartedAt or now))
    session.currentLevel, session.levelStartedAt = level, now
  elseif not session.currentLevel then
    session.currentLevel, session.levelStartedAt = level, now
  end
end

function NS:RecordSessionXP()
  if not self.db or not UnitXP or not UnitLevel then return end
  self:InitSession()
  local session = self.db.session
  local level, xp = UnitLevel("player"), UnitXP("player") or 0
  local maxXP = UnitXPMax and UnitXPMax("player") or 0
  if session.lastLevel and level > session.lastLevel then
    session.xpGained = (session.xpGained or 0) + math.max(0, (session.lastMaxXP or 0) - (session.lastXP or 0)) + xp
  elseif session.lastXP and xp > session.lastXP then
    session.xpGained = (session.xpGained or 0) + xp - session.lastXP
  end
  session.lastLevel, session.lastXP, session.lastMaxXP = level, xp, maxXP
  session.lastSeen = time and time() or session.lastSeen
  self:UpdateSessionContext()
end

function NS:RecordSessionDeath()
  if not self.db then return end
  self:InitSession(); self.db.session.deaths = (self.db.session.deaths or 0) + 1
end

function NS:GetSessionStats()
  if not self.db then return { elapsed=0, xp=0, xpPerHour=0, level=1, progress=0, deaths=0 } end
  self:InitSession()
  self:UpdateSessionContext()
  local session = self.db.session
  local elapsed = math.max(1, (time and time() or session.startedAt) - session.startedAt)
  local level = UnitLevel and UnitLevel("player") or session.lastLevel or 1
  local xp = UnitXP and UnitXP("player") or session.lastXP or 0
  local maxXP = UnitXPMax and UnitXPMax("player") or session.lastMaxXP or 0
  return { elapsed=elapsed, xp=session.xpGained or 0, xpPerHour=(session.xpGained or 0) * 3600 / elapsed, level=level, progress=maxXP > 0 and xp / maxXP or 0, deaths=session.deaths or 0 }
end

function NS:GetSessionText()
  local stats = self:GetSessionStats()
  local minutes = math.floor(stats.elapsed / 60)
  return string.format("Session %d:%02d · XP/h %.0f · Tode %d", math.floor(minutes / 60), minutes % 60, stats.xpPerHour, stats.deaths)
end

function NS:GetSessionDetail()
  local stats = self:GetSessionStats()
  local zone = self.db.session.currentZone or "Unbekannt"
  local zoneSeconds = (self.db.session.zoneTimes[zone] or 0) + math.max(0, (time and time() or 0) - (self.db.session.zoneStartedAt or (time and time() or 0)))
  return string.format("XP/h %.0f · Level %.0f%% · Zone %s (%d Min.) · Tode %d", stats.xpPerHour, stats.progress * 100, zone, math.floor(zoneSeconds / 60), stats.deaths)
end
