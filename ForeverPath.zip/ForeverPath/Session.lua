local NS=ForeverPath
local function safeNumber(fn,...)
  if type(fn)~="function" then return 0 end
  local ok,value=pcall(fn,...)
  if not ok or type(value)~="number" then return 0 end
  if issecretvalue then
    local okSecret,secret=pcall(issecretvalue,value)
    if okSecret and secret then return 0 end
  end
  return value
end
function NS:InitSession()
  if self.session then return end
  self.session={started=GetTime(),lastTick=GetTime(),xp=0,killXP=0,questXP=0,otherXP=0,deaths=0,lastXP=safeNumber(UnitXP,"player"),maxXP=safeNumber(UnitXPMax,"player"),level=safeNumber(UnitLevel,"player"),elapsed=0,travel=0,combat=0,dead=0,xpSamples={},lastQuestXPAt=0}
  self.db.zoneMetrics=self.db.zoneMetrics or {}; self.db.questMetrics=self.db.questMetrics or {}; self.db.deathSpots=self.db.deathSpots or {}; self.db.levelTimes=self.db.levelTimes or {}
end
function NS:UpdateSessionContext()
  self:InitSession(); local s=self.session; local now=GetTime(); local dt=math.max(0,now-s.lastTick); s.lastTick=now; s.elapsed=s.elapsed+dt
  local zone=s.zone or self:GetPlayerZone()
  local z=self.db.zoneMetrics[zone] or {seconds=0,xp=0}; z.seconds=z.seconds+dt; self.db.zoneMetrics[zone]=z
  self.db.levelTimes[s.level]=(self.db.levelTimes[s.level] or 0)+dt
  if UnitIsDeadOrGhost and UnitIsDeadOrGhost("player") then s.dead=s.dead+dt
  elseif UnitAffectingCombat and UnitAffectingCombat("player") then s.combat=s.combat+dt
  elseif safeNumber(GetUnitSpeed,"player")>0 then s.travel=s.travel+dt end
  s.zone=self:GetPlayerZone()
end
function NS:RecordSessionXP()
  self:UpdateSessionContext(); local s=self.session
  local xp,level=safeNumber(UnitXP,"player"),safeNumber(UnitLevel,"player")
  local gain=level>s.level and math.max(0,s.maxXP-s.lastXP)+xp or math.max(0,xp-s.lastXP)
  if gain > 0 then
    s.xp=s.xp+gain
    local recentQuest = s.lastQuestXPAt and GetTime()-s.lastQuestXPAt < 5
    if recentQuest or self.rewardWindow then s.questXP=(s.questXP or 0)+gain
    elseif UnitAffectingCombat and UnitAffectingCombat("player") or UnitExists and UnitExists("target") then s.killXP=(s.killXP or 0)+gain; if self.RecordMobXPObservation then self:RecordMobXPObservation(gain) end
    else s.otherXP=(s.otherXP or 0)+gain end
    s.xpSamples=s.xpSamples or {}; s.xpSamples[#s.xpSamples+1]={at=GetTime(),gain=gain}
    while #s.xpSamples>120 do table.remove(s.xpSamples,1) end
  end
  local z=self.db.zoneMetrics[s.zone]; if z then z.xp=z.xp+gain end
  s.lastXP,s.maxXP,s.level=xp,safeNumber(UnitXPMax,"player"),level
end
function NS:RecordSessionDeath()
  self:UpdateSessionContext(); self.session.deaths=self.session.deaths+1
  local map=C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player"); local x,y
  if map and self.GetSafeMapPosition then x,y=self:GetSafeMapPosition(map,"player") end
  if x and y then table.insert(self.db.deathSpots,{mapID=map,x=x*100,y=y*100,at=time()}); if #self.db.deathSpots>100 then table.remove(self.db.deathSpots,1) end end
end
function NS:GetMovingXPPerHour()
  local s=self.session; if not s then return 0 end
  local latest=GetTime(); local first=nil; local weightedGain=0; local weightTotal=0
  for i=#(s.xpSamples or {}),1,-1 do
    local sample=s.xpSamples[i]; local age=latest-sample.at
    if age>600 then break end
    first=sample.at; local weight=1-math.min(0.75,age/240); weightedGain=weightedGain+sample.gain*weight; weightTotal=weightTotal+weight
  end
  if not first or weightTotal<=0 then return 0 end
  local span=math.max(60,latest-first)
  return weightedGain/span*3600
end
function NS:GetSessionStats()
  self:UpdateSessionContext(); local s=self.session; local maximum=safeNumber(UnitXPMax,"player"); local rate=self:GetMovingXPPerHour()
  if rate<=0 and s.elapsed>0 then rate=s.xp*3600/math.max(1,s.elapsed) end
  local remaining=math.max(0,maximum-safeNumber(UnitXP,"player"))
  return {elapsed=s.elapsed,xp=s.xp,xpPerHour=s.xp*3600/math.max(1,s.elapsed),movingXPPerHour=rate,ttg=rate>0 and remaining/rate or nil,progress=maximum>0 and UnitXP("player")/maximum or 0,deaths=s.deaths,level=s.level,killsXP=s.killXP or 0,questXP=s.questXP or 0,travelSeconds=s.travel,combatSeconds=s.combat}
end
function NS:GetSessionText() local s=self:GetSessionStats(); local ttg=s.ttg and string.format(" · TTG %.0f Min.",s.ttg/60) or ""; return string.format("%.0f XP/h gleitend · %d Min. · %d Tode%s",s.movingXPPerHour or s.xpPerHour,s.elapsed/60,s.deaths,ttg) end
function NS:GetSessionDetail() return self:GetSessionText() end
function NS:GetLearningDetails()
  self:UpdateSessionContext(); local lines={self:GetSessionText()}
  for zone,z in pairs(self.db.zoneMetrics) do lines[#lines+1]=string.format("%s: %.0f XP/h · %.1f Min.",zone,z.xp*3600/math.max(1,z.seconds),z.seconds/60) end
  local s=self:GetSessionStats(); lines[#lines+1]=string.format("Kills %.0f XP · Quests %.0f XP · Sonstiges %.0f XP",s.killsXP,s.questXP,self.session.otherXP or 0)
  lines[#lines+1]=string.format("Bewegung %.1f Min. · Kampf %.1f · Tot %.1f",self.session.travel/60,self.session.combat/60,self.session.dead/60)
  lines[#lines+1]="Gespeicherte Todesstellen: "..#self.db.deathSpots
  for id,q in pairs(self.db.questMetrics) do if q.seconds then lines[#lines+1]=string.format("Quest %d: %.1f Min. · %d XP · Planung %s",id,q.seconds/60,q.xp or 0,q.estimatedSeconds and string.format("%.1f Min.",q.estimatedSeconds/60) or "unbekannt") end end
  return table.concat(lines,"\n")
end
