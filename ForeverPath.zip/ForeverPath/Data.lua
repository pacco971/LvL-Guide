local NS = ForeverPath

-- Klassenprofile für die schnellste Solo-/Gruppenentscheidung. Die Hinweise
-- ändern nicht die Sicherheitsregeln des Clients und automatisieren keine Kämpfe.
NS.classProfiles = {
  HUNTER = { name="Jäger", spec="Beast Mastery", note="Pet aktiv halten, Wege mit vielen Einzelzielen bevorzugen und nur für gebündelte Dungeonquests gruppen.", speed="S", role="DPS" },
  MAGE = { name="Magier", spec="Frost", note="Wasser/Essen und Evocation einplanen; große Reisen mit Portalen verkürzen und sichere Mehrfachpulls nutzen.", speed="A", role="DPS" },
  WARLOCK = { name="Hexenmeister", spec="Gebrechen", note="Voidwalker für Soloziele, Seelensplitter und Gesundheitssteine vorbereiten; lange Wege mit Ritualen reduzieren.", speed="A", role="DPS" },
  ROGUE = { name="Schurke", spec="Kampf", note="Kampf-Spec für konstante Einzelzielgeschwindigkeit; Stealth nur für gefährliche Abkürzungen und Questziele verwenden.", speed="B", role="DPS" },
  DRUID = { name="Druide", spec="Wildheit", note="Reiseform und Katzenform konsequent nutzen; bei Gruppenbedarf auf Heiler wechseln, ohne die Questroute zu verlassen.", speed="B", role="Hybrid" },
  SHAMAN = { name="Schamane", spec="Verbesserung", note="Geisterwolf und Totems für kurze Kämpfe nutzen; Schilde und Nahkampfwaffe aktuell halten.", speed="B", role="Hybrid" },
  PALADIN = { name="Paladin", spec="Vergeltung", note="Zweihandwaffe priorisieren; bei Dungeonwarteschlangen als Tank/Heiler einspringen, solo aber die Questroute fortsetzen.", speed="B", role="Hybrid" },
  PRIEST = { name="Priester", spec="Schatten", note="Schatten für Solo-XP; Mana- und Trinkpausen in die Routenstopps legen, statt unnötig zurückzureisen.", speed="C", role="Hybrid" },
  WARRIOR = { name="Krieger", spec="Waffen", note="Waffen-Upgrade ist der größte Geschwindigkeitshebel; Elite- und Gruppenquests mit Dungeonfenstern bündeln.", speed="C", role="DPS/Tank" },
  DEFAULT = { name="Unbekannt", spec="flexibel", note="Ausrüstung, Trainer und Gruppenfenster an die aktuelle Situation anpassen.", speed="?", role="flexibel" },
}

-- Klassen-Meilensteine für die Live-Berechnung. Das sind eigene, vorsichtige
-- Empfehlungen: der Client entscheidet weiterhin, welche Trainerfähigkeiten
-- tatsächlich verfügbar sind. Questdaten werden nie aus einem fremden Addon
-- zur Laufzeit geladen.
NS.classLevelPlans = {
  HUNTER={{10,"Pet-/Klassenstopp prüfen"},{20,"Trainer + Reittier vorbereiten"},{30,"Waffen- und Pet-Fähigkeiten bündeln"},{40,"Reittier-/Ausrüstungsstopp"},{50,"Endlevel-Trainer und Verbrauchsgüter"}},
  MAGE={{10,"Frost-/Solo-Fähigkeiten beim Trainer prüfen"},{20,"Teleport- und Reisezauber einplanen"},{30,"AoE nur bei sicherem Pull-Fenster nutzen"},{40,"Portale und Hauptstadtstopps bündeln"},{50,"Endlevel-Training vor Dungeonrunde"}},
  WARLOCK={{10,"Voidwalker-/Klassenquest priorisieren"},{20,"Seelensplitter und Gesundheitssteine vorbereiten"},{30,"Ritual-/Reisestopp bündeln"},{40,"Pet- und Ausrüstungscheck"},{50,"Endlevel-Training und Dungeonquest"}},
  ROGUE={{10,"Gifte und erste Klassenfähigkeiten prüfen"},{20,"Kampf-Fähigkeiten trainieren"},{30,"Waffenwechsel und Giftvorrat"},{40,"Waffen-Upgrade vor langen Questketten"},{50,"Endlevel-Training"}},
  DRUID={{10,"Formen-/Klassenquest priorisieren"},{20,"Reiseform und Trainerstopp prüfen"},{30,"Wildnis- und Heileroptionen bündeln"},{40,"Reiseform-Upgrade prüfen"},{50,"Rollenprofil vor Dungeons wählen"}},
  SHAMAN={{10,"Totems und Schilde trainieren"},{20,"Geisterwolf-/Reisestopp prüfen"},{30,"Nahkampfwaffe und Totems aktualisieren"},{40,"Rollenprofil für Gruppenfenster wählen"},{50,"Endlevel-Training"}},
  PALADIN={{10,"Klassenquest und Siegel priorisieren"},{20,"Zweihandwaffe + Reittierfenster"},{30,"Auren und Trainerstopp bündeln"},{40,"Waffen-Upgrade vor Umwegen"},{50,"Tank-/Heilerrolle für Dungeonfenster prüfen"}},
  PRIEST={{10,"Schatten-/Heilerprofil wählen"},{20,"Trainerstopp mit Hauptstadtbesuch bündeln"},{30,"Schattenfähigkeiten und Zauber prüfen"},{40,"Heilerrolle nur bei kurzer Wartezeit einplanen"},{50,"Endlevel-Training"}},
  WARRIOR={{10,"Waffenprofil und Trainerstopp"},{20,"Zweihandwaffe priorisieren"},{30,"Haltung-/Waffenfähigkeiten bündeln"},{40,"Waffen-Upgrade vor langen Umwegen"},{50,"Tank-/DPS-Profil für Dungeonfenster"}},
  DEFAULT={{10,"Klassenfähigkeiten beim Trainer prüfen"},{20,"Ausrüstung und Reittierfenster"},{30,"Reise- und Trainerstopps bündeln"},{40,"Waffen-/Rüstungsupgrade prüfen"},{50,"Endlevel-Training"}},
}
-- The exact trainer service list is client data and is captured when a
-- trainer window is opened. These locations are the route-planning fallback
-- shown before that scan; faction-specific city names are deliberately not
-- guessed because Forever servers can place trainers differently.
for _, plan in pairs(NS.classLevelPlans) do
  for _, milestone in ipairs(plan) do
    milestone[3] = milestone[1] <= 10 and "Startgebiet / Klassenlehrer" or "Hauptstadt / Klassenlehrer"
  end
end
function NS:GetClassLevelPlan()
  local token=self.GetClassToken and self:GetClassToken() or "DEFAULT"
  return self.classLevelPlans[token] or self.classLevelPlans.DEFAULT
end

local function step(id, level, title, body, zone)
  return { id=id, level=level, title=title, body=body, zone=zone }
end

local function sideData(prefix, startZone, capital, early, mid, late)
  local speed = {
    step(prefix.."01", 1, startZone..": Start und Klassenaufgaben", "1) Heimatort setzen. 2) Klassenlehrer öffnen und alle bezahlbaren Fähigkeiten lernen. 3) Erste Hilfe und Berufe prüfen. 4) Startquests annehmen, bevor du das Gebiet verlässt.", startZone),
    step(prefix.."02", 5, "Hauptstadt: Vorbereitung", "Graue Gegenstände verkaufen, Taschen auffüllen und Erste Hilfe aktualisieren. Danach den Flugpunkt holen, reparieren und den nächsten Hub als Ziel setzen.", capital),
    step(prefix.."03", 10, early[1][1]..": Questzentrum", "Alle verfügbaren Aufgaben am Hauptlager annehmen und den Gasthof setzen. Zuerst Ziele in Laufnähe erledigen, danach Sammel- und Reiseziele in einer Runde verbinden.", early[1][1]),
    step(prefix.."04", 12, early[1][1]..": Abschlussrunde", "Questlog prüfen und fertige Aufgaben zuerst abgeben. Offene Gegner-, Sammel- und Reiseziele abschließen; Rückwege erst antreten, wenn mehrere Abgaben bereit sind.", early[1][1]),
    step(prefix.."05", 14, early[2][1]..": Übergang", "Zum nächsten Questhub reisen und den Flugpunkt sichern. Unterwegs kurze Aufgaben mitnehmen, aber keine Elite- oder Gruppenquest für einen Einzelrückweg erzwingen.", early[2][1]),
    step(prefix.."06", 18, early[3][1]..": Hauptschleife", "Die Zone von innen nach außen abarbeiten: erst nahe Ziele, dann die äußeren Lager. Eliteziele markieren, Gruppenfenster prüfen und die Abgaben am Ende der Runde bündeln.", early[3][1]),
    step(prefix.."07", 20, "Stufe 20: Training und Reise", "Vor dem nächsten Zonenwechsel beim Klassenlehrer vorbeischauen und neue Fähigkeiten lernen. Ausrüstung, Reparatur, Verbrauchsgüter und Flugpunkt in einem Stadtstopp erledigen.", capital),
    step(prefix.."08", 22, mid[1][1]..": Quests bündeln", "Aufgaben aus allen erreichbaren Lagern sammeln und nach Zielgebiet sortieren. Eine komplette Rundreise laufen, statt für einzelne Quests zum Hub zurückzukehren.", mid[1][1]),
    step(prefix.."09", 26, mid[2][1]..": Hauptziele", "Der Hauptroute folgen, den Flugpunkt sichern und Quests mit gemeinsamen Gegnern zuerst abschließen. Danach Abgaben, Trainerstopp und Ausrüstungscheck zusammenlegen.", mid[2][1]),
    step(prefix.."10", 30, mid[3][1]..": Reisehub", "Niedrige Quests gesammelt abgeben und Taschen leeren. Danach anhand von XP pro Minute zwischen dem nächsten Zonenabschnitt, Dungeonquest-Bonus und einer sicheren Soloalternative wählen.", mid[3][1]),
    step(prefix.."11", 32, "Stranglethorn Vale: Sammelrunde", "Bündele Küsten-, Lager- und Jagdziele. PvP- oder Eliteaufgaben nur als optionale Gruppenschritte behandeln.", "Stranglethorn Vale"),
    step(prefix.."12", 35, "Riverglades: neuer Forever-Abschnitt", "Hole alle Aufgaben im neuen Gebiet, aktiviere den Flugpunkt und arbeite die Questketten nach Entfernung ab.", "Riverglades"),
    step(prefix.."13", 38, late[1][1]..": Übergang in die 40er", "Beende Riverglades oder wechsle bei Gruppenmangel nach Desolace/Arathi. Reiseziele als Bündel abschließen.", late[1][1]),
    step(prefix.."14", 42, late[2][1]..": offene Questhubs", "Nimm die 40er-Hubs mit, halte den Inventarplatz frei und plane den nächsten Hauptstadtbesuch für Training und Auktion.", late[2][1]),
    step(prefix.."15", 46, "Searing Gorge: Vorbereitung auf Blackrock", "Erledige die Außenquests, sichere den Flugpunkt und sammle alle Vorquests für die Blackrock-Runden.", "Searing Gorge"),
    step(prefix.."16", 48, "Un'Goro Crater: Forschungsrunde", "Arbeite die Kraterziele in einer Schleife ab. Materialien und seltene Funde behalten, bevor du abgibst.", "Un'Goro Crater"),
    step(prefix.."17", 50, "Felwood und Burning Steppes", "Schließe die erreichbaren Außenquests ab und bereite Schlüsselteile, Resistenzen und Dungeonreisen vor.", "Felwood / Burning Steppes"),
    step(prefix.."18", 53, "Western Plaguelands: Vorquests", "Sammle die verfügbaren Vorquests, erledige die Außenringe und plane Scholomance/Stratholme mit einer Gruppe.", "Western Plaguelands"),
    step(prefix.."19", 55, "Eastern Plaguelands: Endlevel-Runde", "Arbeite die östlichen Questhubs ab, nimm den Flugpunkt und halte die letzten Abgaben für einen effizienten XP-Schub zurück.", "Eastern Plaguelands"),
    step(prefix.."20", 58, "Winterspring und Silithus", "Schließe die letzten Außenquests ab, sammle Endgame-Vorquests und bereite den Stufe-60-Übergang vor.", "Winterspring / Silithus"),
    step(prefix.."21", 60, "Stufe 60: Endgame-Freischaltung", "Prüfe Attunements, Dungeon-Schlüssel, Legacy-Ziele, Berufe und die nächsten Forever-Endgame-Gebiete.", "Endgame"),
  }
  local dungeon = {
    step(prefix.."D01", 10, "Dungeon-Modus: Vorbereitung", "Gasthof setzen, reparieren, Verbrauchsgüter kaufen, Questlog leeren und alle erreichbaren Dungeonaufgaben sammeln.", capital),
    step(prefix.."D02", 15, "Früher Dungeon-Lauf", "Passenden Dungeon auswählen, Aufgaben vor dem Eingang abholen und einen vollständigen Gruppenlauf planen.", early[1][1]),
    step(prefix.."D03", 20, "Wailing Caverns / Deadmines-Fenster", "Je nach Fraktion und Gruppe den frühen Dungeon einmal vollständig laufen; danach Aufgaben abgeben und Ausrüstung prüfen.", "Dungeon-Hub"),
    step(prefix.."D04", 26, "Blackfathom Deeps / Razorfen Kraul", "Dungeonaufgaben bündeln, nur bei stabiler Gruppe mehrfach laufen und die Außenroute zwischen den Wartezeiten fortsetzen.", "Dungeon-Hub"),
    step(prefix.."D05", 30, "Scarlet Monastery / Gnomeregan", "Alle Vorquests vor dem Eingang sammeln und die passenden Flügel bzw. den Dungeon in einem organisierten Lauf erledigen.", "Dungeon-Hub"),
    step(prefix.."D06", 35, "Maraudon / Uldaman", "Vorquests aus den umliegenden Zonen zuerst erledigen; beim Rückweg alle Abgaben und Trainingspunkte mitnehmen.", "Dungeon-Hub"),
    step(prefix.."D07", 38, "Riverglades: Krol'Dok Stronghold", "Neue Forever-Dungeonaufgaben vor dem Eingang sammeln und den Lauf mit der Riverglades-Questschleife verbinden.", "Riverglades"),
    step(prefix.."D08", 42, "Zul'Farrak / Sunken Temple", "Aufgaben aus Tanaris und den vorgelagerten Hubs zusammenführen, bevor die Gruppe startet.", "Tanaris / Swamp of Sorrows"),
    step(prefix.."D09", 48, "Blackrock Depths", "Vorquests, Schlüsselschritte und Dungeonaufgaben in einer Reise bündeln; Laufziel vorab mit der Gruppe absprechen.", "Blackrock Mountain"),
    step(prefix.."D10", 52, "Lower Blackrock Spire", "Außenquests in Burning Steppes abschließen, dann die Dungeonaufgaben und Ausrüstungs-Upgrades priorisieren.", "Burning Steppes"),
    step(prefix.."D11", 58, "Scholomance / Stratholme", "Endlevel-Dungeonrunde mit allen gesammelten Aufgaben. Danach Endgame-Checkliste und Attunements öffnen.", "Plaguelands"),
  }
  local discovery, legacy = {}, {}
  local zones = { startZone, early[1][1], early[2][1], early[3][1], mid[1][1], mid[2][1], mid[3][1], "Stranglethorn Vale", "Riverglades", late[1][1], late[2][1], "Searing Gorge", "Un'Goro Crater", "Felwood", "Winterspring", "Silithus" }
  for i, zone in ipairs(zones) do
    discovery[#discovery+1] = step(prefix.."X"..i, math.min(60, i * 4), zone..": Entdeckung", "Hole den Flugpunkt, erkunde die Hauptorte und schließe mindestens eine Nebenroute oder Höhle ab.", zone)
    legacy[#legacy+1] = step(prefix.."L"..i, math.min(60, i * 4), zone..": Legacy-Prüfung", "Prüfe Erfolge, Erkundung, offene Aufgaben und Instanzfortschritt dieser Zone. Fehlendes für später markieren.", zone)
  end
  return { speed=speed, dungeon=dungeon, discovery=discovery, legacy=legacy }
end

NS.routes = {
  alliance = sideData("A", "Zephras Isle / Allianz-Startgebiet", "Stormwind / Ironforge / Darnassus", {
    {"Westfall",10}, {"Loch Modan",10}, {"Darkshore",10},
  }, {
    {"Redridge Mountains",15}, {"Duskwood",18}, {"Wetlands",20},
  }, {
    {"Arathi Highlands",30}, {"Stranglethorn Vale",30}, {"Desolace",30},
  }),
  horde = sideData("H", "Zephras Isle / Horde-Startgebiet", "Orgrimmar / Thunder Bluff / Undercity", {
    {"Silverpine Forest",10}, {"The Barrens",10}, {"Stonetalon Mountains",15},
  }, {
    {"Ashenvale",18}, {"Hillsbrad Foothills",20}, {"Thousand Needles",25},
  }, {
    {"Arathi Highlands",30}, {"Stranglethorn Vale",30}, {"Desolace",30},
  }),
}
