local NS = ForeverPath

local function place(button)
  local angle = NS.db and NS.db.minimapAngle or 45
  local radians = math.rad(angle)
  button:ClearAllPoints()
  button:SetPoint("CENTER", Minimap, "CENTER", math.cos(radians) * 80, math.sin(radians) * 80)
end

function NS:CreateMinimapButton()
  if self.minimapButton then place(self.minimapButton); return end
  local b = CreateFrame("Button", "ForeverPathMinimapButton", Minimap)
  b:SetSize(34, 34); b:SetFrameStrata("MEDIUM"); b:SetMovable(true); b:EnableMouse(true); b:RegisterForClicks("LeftButtonUp", "RightButtonUp"); b:RegisterForDrag("LeftButton")
  b:SetNormalTexture("Interface\\Icons\\INV_Misc_Map_01")
  b:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
  b:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress")
  local border = b:CreateTexture(nil, "OVERLAY"); border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder"); border:SetSize(54, 54); border:SetPoint("CENTER")
  b:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT"); GameTooltip:AddLine("ForeverPath", 0.84, 0.66, 0.29); GameTooltip:AddLine("Linksklick: Guide öffnen", 0.85, 0.85, 0.85); GameTooltip:AddLine("Rechtsklick: Route analysieren", 0.70, 0.80, 0.90); GameTooltip:AddLine("Ziehen: Icon verschieben", 0.70, 0.80, 0.90); GameTooltip:Show()
  end)
  b:SetScript("OnLeave", function() GameTooltip:Hide() end)
  b:SetScript("OnClick", function(_, mouseButton) if mouseButton == "RightButton" then NS:PrintRecommendation() else NS:Toggle() end end)
  b:SetScript("OnDragStart", function(self) if NS.db and NS.db.ui and NS.db.ui.lockFrames then return end; self.dragging = true end)
  b:SetScript("OnDragStop", function(self)
    if not self.dragging then return end
    self.dragging = nil
    local cx, cy = Minimap:GetCenter(); local x, y = GetCursorPosition(); local scale = UIParent:GetEffectiveScale()
    x, y = x / scale, y / scale
    NS.db.minimapAngle = math.deg(math.atan2(y - cy, x - cx)); place(self)
  end)
  self.minimapButton = b; place(b)
end
