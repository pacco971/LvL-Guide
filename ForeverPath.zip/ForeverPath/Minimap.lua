local NS = ForeverPath

local function place(button)
  local angle = NS.db and NS.db.minimapAngle or 45
  local radians = math.rad(angle)
  button:ClearAllPoints()
  button:SetPoint("CENTER", Minimap, "CENTER", math.cos(radians) * 80, math.sin(radians) * 80)
end

local function applyScale(button)
  local scale = NS.db and NS.db.ui and NS.db.ui.minimapScale or 1
  scale = math.max(0.70, math.min(1.45, tonumber(scale) or 1))
  button:SetScale(scale)
end

function NS:SetMinimapScale(delta)
  self:EnsureSettings()
  self.db.ui.minimapScale = math.max(0.70, math.min(1.45, (self.db.ui.minimapScale or 1) + delta))
  if self.minimapButton then applyScale(self.minimapButton) end
  if self.RefreshSettings then self:RefreshSettings() end
  self:Print(string.format("Minimap-Icon: %.2fx", self.db.ui.minimapScale))
end

function NS:CreateMinimapButton()
  if self.minimapButton then place(self.minimapButton); applyScale(self.minimapButton); return end
  local b = CreateFrame("Button", "ForeverPathMinimapButton", Minimap)
  b:SetSize(32, 32); b:SetFrameStrata("MEDIUM"); b:SetFrameLevel(20); b:SetMovable(true); b:EnableMouse(true); b:RegisterForClicks("LeftButtonUp", "RightButtonUp"); b:RegisterForDrag("LeftButton")
  b:SetClampedToScreen(true); b:SetToplevel(true)
  -- Keep the minimap button compact and self-contained. The old generic map
  -- icon plus an oversized tracking border was clipped by the minimap and
  -- looked like a broken double icon at non-100% UI scales.
  b.icon = b:CreateTexture(nil, "ARTWORK")
  b.icon:SetTexture("Interface\\AddOns\\ForeverPath\\Assets\\ForeverPath-icon")
  b.icon:SetTexCoord(0.04, 0.96, 0.04, 0.96)
  b.icon:SetSize(24, 24); b.icon:SetPoint("CENTER")
  b.icon:SetVertexColor(1.00, 1.00, 1.00, 1)
  b.ring = b:CreateTexture(nil, "OVERLAY")
  b.ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
  b.ring:SetSize(32, 32); b.ring:SetPoint("CENTER")
  b.ring:SetVertexColor(0.98, 0.72, 0.18, 0.90)
  b:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
  b:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress")
  applyScale(b)
  b:SetScript("OnEnter", function(self)
    self.ring:SetVertexColor(1.00, 0.86, 0.35, 1)
    self.icon:SetVertexColor(1.00, 1.00, 1.00, 1)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT"); GameTooltip:AddLine("ForeverPath", 0.84, 0.66, 0.29); GameTooltip:AddLine("Linksklick: Guide öffnen", 0.85, 0.85, 0.85); GameTooltip:AddLine("Rechtsklick: Route analysieren", 0.70, 0.80, 0.90); GameTooltip:AddLine("Ziehen: Icon verschieben", 0.70, 0.80, 0.90); GameTooltip:Show()
  end)
  b:SetScript("OnLeave", function(self)
    self.ring:SetVertexColor(0.98, 0.72, 0.18, 0.90)
    self.icon:SetVertexColor(1.00, 1.00, 1.00, 1)
    GameTooltip:Hide()
  end)
  b:SetScript("OnClick", function(self, mouseButton)
    if self.dragMoved then self.dragMoved = nil; return end
    if mouseButton == "RightButton" then NS:PrintRecommendation() else NS:Toggle() end
  end)
  b:SetScript("OnDragStart", function(self) if NS.db and NS.db.ui and NS.db.ui.lockFrames then return end; self.dragging = true end)
  b:SetScript("OnDragStop", function(self)
    if not self.dragging then return end
    self.dragging = nil
    self.dragMoved = true
    local cx, cy = Minimap:GetCenter(); local x, y = GetCursorPosition(); local scale = UIParent:GetEffectiveScale()
    x, y = x / scale, y / scale
    NS.db.minimapAngle = math.deg(math.atan2(y - cy, x - cx)); place(self)
  end)
  self.minimapButton = b; place(b)
end
