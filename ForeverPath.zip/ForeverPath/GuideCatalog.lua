local NS = ForeverPath

-- Independent guide catalog.
--
-- The catalog describes coverage and our own route instructions.  It is not a
-- parser or a runtime loader for another addon.  Quest state, objectives and
-- coordinates still come from the Forever client/local open data at runtime.

local function step(id, order, level, zone, title, body, titleEN, bodyEN)
  return {
    kind = "route", id = id, order = order, level = level, zone = zone,
    title = title, body = body, instruction = body,
    titleEN = titleEN, bodyEN = bodyEN,
  }
end

local function makeRoute(prefix, startZone, hub, nextZone, factionWord)
  local side = factionWord == "Horde" and "Horde" or "Allianz"
  return {
    step(prefix .. ":01", 1, 1, startZone,
      "Start und Klassenlehrer",
      "Heimatort setzen, Klassenlehrer öffnen, bezahlbare Fähigkeiten lernen und Erste Hilfe prüfen.",
      "Start and class trainer",
      "Set your home, visit the class trainer, learn affordable abilities and check First Aid."),
    step(prefix .. ":02", 2, 2, startZone,
      "Startquests annehmen",
      "Alle passenden Startquests beim aktuellen Hub annehmen. Ziele aus demselben Gebiet in einer Runde bündeln.",
      "Accept starting quests",
      "Accept the relevant starting quests at the current hub. Bundle objectives from the same area into one loop."),
    step(prefix .. ":03", 3, 4, startZone,
      "Erste Zielrunde",
      "Zuerst nahe Gegner- und Sammelziele erledigen, dann zur Abgabe zurückkehren. Gruppen- und Eliteziele markieren.",
      "First objective loop",
      "Complete nearby kill and collection objectives first, then return for turn-ins. Mark group and elite objectives."),
    step(prefix .. ":04", 4, 6, hub,
      "Hub-Abgabe und Training",
      "Fertige Quests abgeben, Folgequests prüfen, reparieren und neue Fähigkeiten lernen, bevor du weiterziehst.",
      "Hub turn-ins and training",
      "Turn in completed quests, check follow-ups, repair and learn new abilities before moving on."),
    step(prefix .. ":05", 5, 8, nextZone,
      "Zonenwechsel vorbereiten",
      "Questlog aufräumen, Taschen leeren, Flugpunkt oder Bindepunkt sichern und die nächste Zone als zusammenhängende Reise starten.",
      "Prepare the zone transition",
      "Clean up the quest log, clear bag space, secure the flight path or hearth bind, then start one continuous trip to the next zone."),
    step(prefix .. ":06", 6, 10, nextZone,
      "Neue Zone: Questschleife",
      "Quests nach Zielgebiet sortieren. Erst die gemeinsame Gegner- und Sammelrunde erledigen, danach die Abgaben bündeln.",
      "New zone: quest loop",
      "Sort quests by objective area. Complete shared kill and collection loops first, then bundle the turn-ins."),
    step(prefix .. ":07", 7, 12, nextZone,
      "Trainer- und Versorgungsstopp",
      "Beim nächsten sinnvollen Hub Trainer, Händler, Reparatur, Gasthof und Flugpunkt in einem Stopp verbinden.",
      "Trainer and supply stop",
      "At the next useful hub, combine trainer, vendor, repair, hearth and flight-path tasks into one stop."),
    step(prefix .. ":08", 8, 15, nextZone,
      "Live-Questlog priorisieren",
      "ForeverPath setzt deine offenen und abgabebereiten Quests vor allgemeine Routenhinweise. Folgequests werden danach neu bewertet.",
      "Prioritize the live quest log",
      "ForeverPath puts your active and turn-in-ready quests before broad route hints. Follow-ups are scored again afterward."),
  }
end

local function cloneRoute(rows, prefix, zone, title, detail, titleEN, detailEN)
  local result = {}
  result[#result + 1] = step(prefix .. ":00", 1, 1, zone, title, detail, titleEN, detailEN)
  for index, row in ipairs(rows) do
    local copy = {}
    for key, value in pairs(row) do copy[key] = value end
    copy.id = prefix .. ":" .. string.format("%02d", index)
    copy.order = index + 1
    result[#result + 1] = copy
  end
  return result
end

local common = makeRoute("catalog:common", "Startgebiet", "Hauptstadt / Questhub", "Nächster Questhub", "Allianz")

NS.guideCatalog = {
  {
    key="skyborne", faction="both", minLevel=1, maxLevel=22, priority=80,
    title="Skyborne · Startinsel 1–22", titleEN="Skyborne · Starting island 1–22",
    summary="Geführter Start mit früher Klassen- und Reiseplanung.", summaryEN="Guided start with early class and travel planning.",
    steps=cloneRoute(common, "guide:skyborne", "Zephras Isle", "Startinsel vorbereiten", "Die Startinsel als zusammenhängende Runde spielen und erst nach dem lokalen Training abreisen.", "Prepare the starting island", "Play the starting island as one continuous loop and leave only after local training."),
  },
  {
    key="alliance_nightelf", faction="alliance", race="Night Elf", minLevel=1, maxLevel=20, priority=90,
    title="Nachtelf · Teldrassil 1–20", titleEN="Night Elf · Teldrassil 1–20",
    summary="Solo-Route für Nachtelfen mit Teldrassil-Start und sauberem Übergang.", summaryEN="Solo route for Night Elves with a Teldrassil start and clean transition.",
    steps=makeRoute("guide:alliance:nightelf", "Teldrassil", "Darnassus / Teldrassil", "Darkshore", "Allianz"),
  },
  {
    key="alliance_human", faction="alliance", race="Human", minLevel=1, maxLevel=20, priority=95,
    title="Mensch · Northshire 1–20", titleEN="Human · Northshire 1–20",
    summary="Solo-Route für Menschen mit Northshire- und Elwynn-Hubs.", summaryEN="Solo route for Humans using Northshire and Elwynn hubs.",
    steps=makeRoute("guide:alliance:human", "Elwynn Forest", "Stormwind / Goldshire", "Westfall", "Allianz"),
  },
  {
    key="alliance_dwarf", faction="alliance", race="Dwarf", minLevel=1, maxLevel=20, priority=92,
    title="Zwerg/Gnom · Dun Morogh 1–20", titleEN="Dwarf/Gnome · Dun Morogh 1–20",
    summary="Solo-Route für den Dun-Morogh-Start mit gebündelten Trainerstopps.", summaryEN="Solo route for a Dun Morogh start with bundled trainer stops.",
    steps=makeRoute("guide:alliance:dwarf", "Dun Morogh", "Ironforge", "Loch Modan", "Allianz"),
  },
  {
    key="alliance_mid", faction="alliance", minLevel=11, maxLevel=20, priority=70,
    title="Allianz · Questwechsel 11–20", titleEN="Alliance · Quest transition 11–20",
    summary="Flexible Anschlussroute für Allianzcharaktere nach dem Startgebiet.", summaryEN="Flexible follow-up route for Alliance characters after the starting zone.",
    steps=makeRoute("guide:alliance:mid", "Westfall / Darkshore", "Stormwind / Ironforge", "Redridge / Loch Modan", "Allianz"),
  },
  {
    key="alliance_mage_early", faction="alliance", class="MAGE", minLevel=1, maxLevel=12, priority=110,
    title="Magier · Allianz 1–12", titleEN="Mage · Alliance 1–12",
    summary="Magierroute mit Wasser/Essen, Trainerfenstern und sicheren Solo-Pulls.", summaryEN="Mage route with food/water, trainer windows and safe solo pulls.",
    steps=makeRoute("guide:alliance:mage:early", "Allianz-Startgebiet", "Stormwind / Darnassus", "Westfall / Darkshore", "Allianz"),
  },
  {
    key="alliance_mage_mid", faction="alliance", class="MAGE", minLevel=12, maxLevel=22, priority=105,
    title="Magier · Allianz 12–22", titleEN="Mage · Alliance 12–22",
    summary="Magier-Anschlussroute mit Reisezaubern und XP-pro-Minute-Prüfung.", summaryEN="Mage follow-up route with travel spells and XP-per-minute checks.",
    steps=makeRoute("guide:alliance:mage:mid", "Allianz-Questhub", "Stormwind / Darnassus", "Redridge / Wetlands", "Allianz"),
  },
  {
    key="alliance_mage_aoe", faction="alliance", class="MAGE", minLevel=1, maxLevel=22, priority=108,
    title="Magier · sichere AoE-Variante 1–22", titleEN="Mage · safe AoE variant 1–22",
    summary="Separate Auswahl für sichere AoE-Fenster; gefährliche Pulls bleiben optional.", summaryEN="Separate selection for safe AoE windows; dangerous pulls stay optional.",
    steps=makeRoute("guide:alliance:mage:aoe", "Allianz-Startgebiet", "Stormwind / Darnassus", "Redridge / Wetlands", "Allianz"),
  },
  {
    key="horde_durotar", faction="horde", race="Orc", minLevel=1, maxLevel=20, priority=95,
    title="Orc/Troll · Durotar 1–20", titleEN="Orc/Troll · Durotar 1–20",
    summary="Solo-Route für Orcs und Trolle mit Durotar-Start und frühem Hub-Loop.", summaryEN="Solo route for Orcs and Trolls with a Durotar start and early hub loops.",
    steps=makeRoute("guide:horde:durotar", "Durotar", "Orgrimmar", "The Barrens", "Horde"),
  },
  {
    key="horde_undead", faction="horde", race="Undead", minLevel=1, maxLevel=20, priority=100,
    title="Untote · Tirisfal 1–20", titleEN="Undead · Tirisfal 1–20",
    summary="Solo-Route für Untote mit Tirisfal-Start, Training und Silberwald-Übergang.", summaryEN="Solo route for Undead with a Tirisfal start, training and Silverpine transition.",
    steps=makeRoute("guide:horde:undead", "Tirisfal Glades", "Undercity", "Silverpine Forest", "Horde"),
  },
  {
    key="horde_tauren", faction="horde", race="Tauren", minLevel=1, maxLevel=20, priority=92,
    title="Tauren · Mulgore 1–20", titleEN="Tauren · Mulgore 1–20",
    summary="Solo-Route für Tauren mit Mulgore-Loop und Thunder-Bluff-Stopp.", summaryEN="Solo route for Tauren with a Mulgore loop and Thunder Bluff stop.",
    steps=makeRoute("guide:horde:tauren", "Mulgore", "Thunder Bluff", "The Barrens", "Horde"),
  },
  {
    key="horde_barrens", faction="horde", minLevel=12, maxLevel=22, priority=75,
    title="Horde · Brachland 12–22", titleEN="Horde · Barrens 12–22",
    summary="Flexible Horde-Anschlussroute für Brachland, Stonetalon und Ashenvale.", summaryEN="Flexible Horde follow-up route for Barrens, Stonetalon and Ashenvale.",
    steps=makeRoute("guide:horde:barrens", "The Barrens", "Orgrimmar / Crossroads", "Stonetalon / Ashenvale", "Horde"),
  },
  {
    key="horde_mage", faction="horde", class="MAGE", minLevel=12, maxLevel=22, priority=105,
    title="Magier · Horde 12–22", titleEN="Mage · Horde 12–22",
    summary="Horde-Magierroute mit Reisezaubern und sicheren Solo-Fenstern.", summaryEN="Horde Mage route with travel spells and safe solo windows.",
    steps=makeRoute("guide:horde:mage", "Horde-Questhub", "Undercity / Orgrimmar", "Silverpine / Barrens", "Horde"),
  },
}

local function lower(value)
  return string.lower(tostring(value or ""))
end

local function raceMatches(expected, actual)
  if not expected or expected == "" then return true end
  actual = lower(actual):gsub("[%s%-]", "")
  for choice in string.gmatch(lower(expected), "[^/]+") do
    choice = choice:gsub("[%s%-]", "")
    if string.find(actual, choice, 1, true) ~= nil then return true end
    if choice == "dwarf" and string.find(actual, "zwerg", 1, true) ~= nil then return true end
    if choice == "gnome" and string.find(actual, "gnom", 1, true) ~= nil then return true end
    if choice == "nightelf" and string.find(actual, "nachtelf", 1, true) ~= nil then return true end
    if choice == "undead" and (string.find(actual, "untot", 1, true) ~= nil or string.find(actual, "scourge", 1, true) ~= nil) then return true end
  end
  return false
end

function NS:GetPlayerRaceName()
  if not UnitRace then return "" end
  local ok, localized, english = pcall(UnitRace, "player")
  if not ok then return "" end
  return tostring(english or localized or "")
end

function NS:GetGuideLabel(entry)
  if not entry then return self:L("Guide automatisch") end
  local english = self.db and self.db.ui and self.db.ui.language == "en"
  return (english and entry.titleEN or entry.title) or entry.key
end

function NS:GetGuideSummary(entry)
  if not entry then return self:L("Guide automatisch") end
  local english = self.db and self.db.ui and self.db.ui.language == "en"
  return (english and entry.summaryEN or entry.summary) or ""
end

function NS:GetGuideCatalogForContext(context)
  context = context or (self.GetPlanningContext and self:GetPlanningContext()) or {}
  local faction = lower(context.faction or (UnitFactionGroup and UnitFactionGroup("player")))
  local class = context.class or (self.GetClassToken and self:GetClassToken()) or ""
  local race = context.race or self:GetPlayerRaceName()
  local level = tonumber(context.level) or 1
  local result = {}
  for _, entry in ipairs(self.guideCatalog or {}) do
    local factionOK = entry.faction == "both" or entry.faction == faction
    local classOK = not entry.class or entry.class == class
    -- Race-specific routes stay selectable for any character of the same
    -- faction, while the matching race receives the automatic recommendation
    -- bonus.  This mirrors the useful choice of following another starting
    -- zone without pretending it is the default path for this character.
    local raceOK = raceMatches(entry.race, race)
    local levelOK = level >= (entry.minLevel or 1) - 4 and level <= (entry.maxLevel or 60) + 4
    if factionOK and classOK and levelOK then
      local score = entry.priority or 0
      if entry.race and raceMatches(entry.race, race) then score = score + 35 end
      if entry.class and entry.class == class then score = score + 45 end
      if level >= (entry.minLevel or 1) and level <= (entry.maxLevel or 60) then score = score + 15 end
      entry._score = score
      result[#result + 1] = entry
    end
  end
  table.sort(result, function(a, b)
    if a.key == (self.db and self.db.guideKey) then return true end
    if b.key == (self.db and self.db.guideKey) then return false end
    if (a._score or 0) ~= (b._score or 0) then return (a._score or 0) > (b._score or 0) end
    return tostring(a.key) < tostring(b.key)
  end)
  return result
end

function NS:GetActiveGuide(context)
  context = context or (self.GetPlanningContext and self:GetPlanningContext()) or {}
  local available = self:GetGuideCatalogForContext(context)
  local selected = self.db and self.db.guideKey
  if selected then
    for _, entry in ipairs(available) do
      if entry.key == selected then return entry, false end
    end
  end
  return available[1], true
end

function NS:SelectGuide(key)
  self:EnsureSettings()
  if key == "auto" or key == nil then
    self.db.guideKey = nil
  else
    local available = self:GetGuideCatalogForContext()
    local found
    for _, entry in ipairs(available) do if entry.key == key then found = entry; break end end
    if not found then return false end
    self.db.guideKey = key
  end
  self.db.step = 1
  self.db.selectedStepID = nil
  if self.InvalidateQuestPlan then self:InvalidateQuestPlan() end
  if self.guideChooser then self.guideChooser:Hide() end
  self:Refresh()
  local guide = self:GetActiveGuide()
  self:Print(string.format(self:L("Guide aktiviert: %s"), self:GetGuideLabel(guide)))
  return true
end

function NS:BuildGuideSpecs(context)
  local guide, automatic = self:GetActiveGuide(context)
  if not guide then return {}, nil, automatic end
  local mode = self.db and self.db.mode or "speed"
  if mode == "dungeon" and guide.dungeonSteps then return guide.dungeonSteps, guide, automatic end
  return guide.steps or {}, guide, automatic
end
