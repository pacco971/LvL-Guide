local NS = ForeverPath

-- Kleine, defensive Beobachtungsschicht für NPC-Tooltips und Rufmeldungen.
-- Sie speichert nur lokale Spielwerte in SavedVariables; es werden keine
-- geschützten Kampfwerte gelesen und keine externen Anfragen ausgeführt.
local function safe(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a, b, c, d = pcall(fn, ...)
  if not ok then return nil end
  return a, b, c, d
end

local function number(value)
  if type(value) ~= "number" then return nil end
  if type(issecretvalue) == "function" then
    local ok, secret = pcall(issecretvalue, value)
    if ok and secret then return nil end
  end
  return value
end

local function stringValue(value)
  return type(value) == "string" and value ~= "" and value or nil
end

local RANKS = {
  worldboss = "Weltboss", rareelite = "Seltener Elite", elite = "Elite",
  rare = "Selten", boss = "Boss", trivial = "Trivial", normal = "Normal",
}

local function relationLabel(reaction)
  reaction = number(reaction)
  if not reaction then return "unbekannt" end
  if reaction >= 5 then return "freundlich" end
  if reaction <= 2 then return "feindlich" end
  return "neutral"
end

function NS:GetUnitObservation(unit)
  unit = unit or "mouseover"
  local exists = safe(UnitExists, unit)
  if not exists then return nil end
  local name = stringValue(safe(UnitName, unit))
  local guid = stringValue(safe(UnitGUID, unit))
  local key = guid or name
  if not key then return nil end

  local classification = stringValue(safe(UnitClassification, unit)) or "normal"
  local level = number(safe(UnitLevel, unit))
  local minLevel = number(safe(UnitEffectiveLevel, unit)) or level
  local maxLevel = number(safe(UnitMaxLevel, unit)) or level
  local reaction = number(safe(UnitReaction, "player", unit))
  local mapID = C_Map and number(safe(C_Map.GetBestMapForUnit, unit)) or nil
  local record = {
    key=key, guid=guid, name=name or key, level=level,
    minLevel=minLevel, maxLevel=maxLevel, classification=classification,
    rank=RANKS[classification] or classification,
    reaction=reaction, friendlyToFaction=reaction and reaction >= 5 or nil,
    relationship=relationLabel(reaction), mapID=mapID,
    observedAt=time and time() or nil,
  }

  self.db = self.db or {}
  self.db.npcObservations = self.db.npcObservations or {}
  self.db.npcObservations[key] = record
  self.db.npcObservationsByName = self.db.npcObservationsByName or {}
  self.db.npcObservationsByName[record.name] = record
  return record
end

function NS:GetLastUnitObservation(unit)
  local name = stringValue(safe(UnitName, unit or "mouseover"))
  local db = self.db or {}
  return name and db.npcObservationsByName and db.npcObservationsByName[name] or nil
end

local function parseSignedAmount(message)
  if type(message) ~= "string" then return nil end
  local amount = string.match(message, "([%+%-]%s*[%d%.%,]+)")
  if not amount then return nil end
  amount = amount:gsub("%s", ""):gsub("[^%+%-%d]", "")
  return tonumber(amount)
end

function NS:GetWatchedReputation()
  if C_Reputation and C_Reputation.GetWatchedFactionData then
    local data = safe(C_Reputation.GetWatchedFactionData)
    if type(data) == "table" then
      return {
        name=stringValue(data.name), standingID=number(data.reaction),
        current=number(data.currentStanding), min=number(data.reactionThreshold),
        max=number(data.nextReactionThreshold),
      }
    end
  end
  if GetWatchedFactionInfo then
    local name, standingID, min, max, value = safe(GetWatchedFactionInfo)
    return {name=stringValue(name), standingID=number(standingID), min=number(min), max=number(max), current=number(value)}
  end
  return nil
end

function NS:RecordReputationMessage(message)
  local amount = parseSignedAmount(message)
  if not amount or amount == 0 then return end
  self.db = self.db or {}
  self.db.reputationLog = self.db.reputationLog or {}
  local watched = self:GetWatchedReputation() or {}
  local session = self.session or {}
  local questID = session.lastTurnInQuestID
  local turnInAt = number(session.lastTurnInAt)
  if questID and turnInAt and GetTime and GetTime() - turnInAt > 5 then questID = nil end
  local row = {
    amount=amount, message=tostring(message), faction=watched.name,
    current=watched.current, min=watched.min, max=watched.max,
    questID=questID, source=questID and "quest" or "game",
    at=GetTime and GetTime() or 0,
  }
  table.insert(self.db.reputationLog, row)
  while #self.db.reputationLog > 120 do table.remove(self.db.reputationLog, 1) end
  if questID then
    self.db.questReputation = self.db.questReputation or {}
    local questRow = self.db.questReputation[questID] or {amount=0, samples=0, faction=watched.name}
    questRow.amount = (questRow.amount or 0) + amount
    questRow.samples = (questRow.samples or 0) + 1
    questRow.faction = watched.name or questRow.faction
    questRow.lastSeen = time and time() or nil
    self.db.questReputation[questID] = questRow
  end
end

function NS:GetQuestReputationText(questID)
  local row = self.db and self.db.questReputation and self.db.questReputation[tonumber(questID)]
  if not row or not row.amount then return nil end
  local sign = row.amount >= 0 and "+" or ""
  return string.format("%s%d Ruf%s", sign, row.amount, row.faction and (" · " .. row.faction) or "")
end

function NS:GetTelemetrySummary()
  local db = self.db or {}
  local npcCount, repCount = 0, 0
  for _ in pairs(db.npcObservations or {}) do npcCount = npcCount + 1 end
  for _ in pairs(db.questReputation or {}) do repCount = repCount + 1 end
  return string.format("NPC-Beobachtungen: %d · Quest-Rufwerte: %d", npcCount, repCount)
end

function NS:RecordTelemetryEvent(event, ...)
  if event == "PLAYER_TARGET_CHANGED" or event == "UPDATE_MOUSEOVER_UNIT" then
    self:GetUnitObservation(event == "PLAYER_TARGET_CHANGED" and "target" or "mouseover")
  elseif event == "CHAT_MSG_COMBAT_FACTION_CHANGE" then
    self:RecordReputationMessage((...))
  elseif event == "QUEST_TURNED_IN" then
    local questID = number((...))
    self.session = self.session or {}
    self.session.lastTurnInQuestID = questID
    self.session.lastTurnInAt = GetTime and GetTime() or 0
  end
end
