local NS = ForeverPath

-- Eigenständige, redaktionelle Guide-Schritte. Die Questdaten selbst kommen
-- weiterhin aus ForeverDB/den offenen lokalen Daten; diese Datei beschreibt
-- nur die Reihenfolge und die Handlung, die ForeverPath daraus machen soll.

local function quest(id, order, zone, instruction)
  return {
    kind="quest", questID=id, order=order, zone=zone,
    instruction=instruction or "Quest annehmen, Ziele im Questlog verfolgen und gebündelt abgeben.",
    items={"Questgegenstände aus dem Questlog verfolgen"},
  }
end

local function travel(id, order, level, zone, title, body)
  return {kind="travel", id=id, order=order, level=level, zone=zone, title=title, body=body}
end

NS.authoredGuides = {
  horde = {
    travel("guide:horde:deathknell", 10, 1, "Tirisfal Glades", "Deathknell: Start und Klassenlehrer", "Heimatort setzen, Klassenlehrer besuchen, Taschen/Verbrauchsgüter prüfen und die Startkette beginnen."),
    quest(363, 20, "Tirisfal Glades", "Bei Novice Elreth annehmen, die Startziele erledigen und zur Abgabe zurückkehren."),
    quest(364, 30, "Tirisfal Glades", "Mindless Ones im markierten Bereich erledigen; danach beim Questgeber abgeben."),
    quest(365, 40, "Tirisfal Glades", "Fields of Grief als Sammel-/Gebietsrunde erledigen, bevor du weiterziehst."),
    quest(376, 50, "Tirisfal Glades", "The Damned annehmen, die Ziele in einer Runde erledigen und die Folgequests am selben Hub prüfen."),
    quest(380, 60, "Tirisfal Glades", "Night Web's Hollow mit den übrigen Deathknell-Zielen bündeln; keine einzelne Rückreise erzwingen."),
    quest(381, 70, "Tirisfal Glades", "Scarlet-Ziele erledigen und die Abgabe mit Red-Messenger-/Vital-Intelligence-Schritten verbinden."),
    quest(382, 80, "Tirisfal Glades", "Red Messenger annehmen, Zielgebiet verfolgen und beim passenden NPC abgeben."),
    quest(383, 90, "Tirisfal Glades", "Vital Intelligence abgeben und die nächste Kette sofort am Hub übernehmen."),
    quest(367, 100, "Tirisfal Glades", "A New Plague als Kettenrunde führen; Folgequests erst nach der aktuellen Abgabe priorisieren."),
    quest(368, 110, "Tirisfal Glades", "A-New-Plague-Folgequest mit dem aktuellen Questlog und den örtlichen Gegnerzielen kombinieren."),
    quest(369, 120, "Tirisfal Glades", "Die dritte Plague-Stufe abschließen und erst danach den Zonenwechsel vorbereiten."),
    quest(370, 130, "Tirisfal Glades", "Scarlet-Crusade-Ziele in einer sicheren Runde erledigen; Eliteziele nur mit Gruppe."),
    quest(371, 140, "Tirisfal Glades", "Die Folgeziele der Scarlet-Kette ohne unnötigen Hauptstadtumweg abarbeiten."),
    quest(372, 150, "Tirisfal Glades", "Kettenabschluss abgeben und die nächste Zone nach Level, Questlog und Reisezeit wählen."),
    quest(374, 160, "Tirisfal Glades", "Proof of Demise zusammen mit den übrigen offenen Abgaben abgeben."),
    quest(375, 170, "Tirisfal Glades", "The Chill of Death als letzte lokale Runde vor dem Übergang abschließen."),
    quest(3902, 180, "Tirisfal Glades", "Scavenging Deathknell nur in derselben Deathknell-Runde erledigen; keine Einzelreise."),
    quest(6395, 190, "Tirisfal Glades", "Marla's Last Wish annehmen oder abgeben, sobald der Questgeber auf der aktuellen Route liegt."),
    travel("guide:horde:undercity", 200, 6, "Tirisfal Glades", "Undercity: Training und Reise bündeln", "Klassenfähigkeiten, Erste Hilfe, Reparatur, Händler und Flugpunkt in einem Stopp zusammenfassen; danach Silberwald vorbereiten."),
    travel("guide:horde:silverpine", 210, 10, "Silverpine Forest", "Silverpine Forest: nächster Questhub", "Flugpunkt sichern, verfügbare Aufgaben sammeln und die lokale Questschleife vor dem nächsten Zonenwechsel abschließen."),
  },
  alliance = {
    travel("guide:alliance:northshire", 10, 1, "Elwynn Forest", "Northshire: Start und Klassenlehrer", "Heimatort setzen, Klassenlehrer besuchen, Taschen/Verbrauchsgüter prüfen und die Startkette beginnen."),
    quest(783, 20, "Elwynn Forest", "A Threat Within annehmen und die Startziele im Northshire-Hub erledigen."),
    quest(7, 30, "Elwynn Forest", "Kobold Camp Cleanup als Nahbereichsrunde erledigen und die Folgequests am selben NPC prüfen."),
    quest(18, 40, "Elwynn Forest", "Brotherhood of Thieves annehmen, Ziele bündeln und Bounty-/Milly-Folgequests vorbereiten."),
    quest(6, 50, "Elwynn Forest", "Bounty on Garrick Padfoot auf dem Weg erledigen, statt dafür separat zurückzulaufen."),
    quest(15, 60, "Elwynn Forest", "Investigate Echo Ridge mit dem Northshire-Questlog verbinden und die Folgequest offen halten."),
    quest(21, 70, "Elwynn Forest", "Skirmish at Echo Ridge abschließen und Report to Goldshire als nächsten Reiseanker setzen."),
    quest(54, 80, "Elwynn Forest", "Report to Goldshire annehmen/abgeben und Training, Händler und Gasthof bündeln."),
    quest(59, 90, "Elwynn Forest", "Cloth and Leather Armor nur zusammen mit dem Goldshire-Stopp erledigen."),
    quest(60, 100, "Elwynn Forest", "Kobold Candles in derselben Fargodeep-Runde sammeln und anschließend gebündelt abgeben."),
    quest(62, 110, "Elwynn Forest", "Fargodeep MineEx als lokale Zielrunde erledigen; den Wegpunkt aus dem Questlog bevorzugen."),
    quest(52, 120, "Elwynn Forest", "Protect the Frontier annehmen und Ziele auf dem Übergang nach Westfall bündeln."),
    travel("guide:alliance:goldshire", 130, 6, "Elwynn Forest", "Goldshire: Training und Reise bündeln", "Klassenfähigkeiten, Erste Hilfe, Reparatur, Händler und Flugpunkt in einem Stopp zusammenfassen."),
    travel("guide:alliance:westfall", 140, 10, "Westfall", "Westfall: nächster Questhub", "Flugpunkt sichern, Aufgaben sammeln und die Westfall-Runde nach Zielen statt nach Einzelquests laufen."),
  },
}

local function factionKey()
  return UnitFactionGroup and UnitFactionGroup("player") == "Horde" and "horde" or "alliance"
end

function NS:GetAuthoredGuideSpec(questID)
  questID = tonumber(questID)
  if not questID then return nil end
  local guide = self.authoredGuides and self.authoredGuides[factionKey()] or {}
  for _, entry in ipairs(guide) do
    if entry.kind == "quest" and entry.questID == questID then return entry end
  end
  return nil
end

local function recentTrainerSeen(self)
  local newest
  for _, stop in pairs(self.db and self.db.stops or {}) do
    if stop.kind == "trainer" and (not newest or (stop.at or 0) > (newest.at or 0)) then newest = stop end
  end
  return newest
end

function NS:GetAuthoredGuideSpecs(context)
  context = context or (self.GetPlanningContext and self:GetPlanningContext()) or {level=1, zone=""}
  local level = tonumber(context.level) or 1
  local output = {}
  local guide = self.authoredGuides and self.authoredGuides[factionKey()] or {}
  for _, entry in ipairs(guide) do
    local entryLevel = entry.level
    if entry.kind == "quest" then
      local record = self.questDB and self.questDB[entry.questID]
      entryLevel = entryLevel or (record and (record.requiredLevel or record.level)) or 1
      if entryLevel <= level + 6 and entryLevel >= level - 5 then output[#output + 1] = entry end
    elseif entryLevel and entryLevel <= level + 2 and entryLevel >= level - 3 then
      output[#output + 1] = entry
    end
  end

  -- Other Forever starts and non-quest modes use the existing independent
  -- route tables as a safe fallback. They remain explicit guide stops until
  -- the live quest log supplies a more precise quest step.
  if #output == 0 and self.routes then
    local routeSet = self.routes[factionKey()] or self.routes.alliance or {}
    local route = routeSet[(self.db and self.db.mode) or "speed"] or routeSet.speed or {}
    for index, entry in ipairs(route) do
      if entry and entry.id and (not entry.level or entry.level <= level + 8) and (not entry.level or entry.level >= level - 6) then
        output[#output + 1] = {
          kind="route", id="guide:" .. factionKey() .. ":" .. tostring(entry.id), order=entry.level * 10 + index,
          level=entry.level, zone=entry.zone, title=entry.title, body=entry.body,
          instruction=entry.body, source="eigene ForeverPath-Routentabelle",
        }
      end
    end
  end

  -- Exact spell names come from the live trainer window when opened.
  local token = self.GetClassToken and self:GetClassToken() or "DEFAULT"
  local plan = self.classLevelPlans and (self.classLevelPlans[token] or self.classLevelPlans.DEFAULT) or {}
  local observed = recentTrainerSeen(self)
  for index, milestone in ipairs(plan) do
    local milestoneLevel, hint, place = milestone[1], milestone[2], milestone[3]
    if milestoneLevel and milestoneLevel <= level + 4 and milestoneLevel >= level - 2 then
      local id = "guide:trainer:" .. token .. ":" .. tostring(milestoneLevel)
      local completed = self.db and self.db.completed and self.db.completed[id]
      local alreadyObserved = observed and observed.at and observed.at >= (self.session and self.session.started or 0) and milestoneLevel <= level
      if not completed and not alreadyObserved then
        output[#output + 1] = {
          kind="trainer", id=id, order=500 + index, level=milestoneLevel,
          class=token, zone=place, title="Klassenlehrer · Stufe " .. tostring(milestoneLevel),
          body=hint .. "\nOrt: " .. tostring(place),
          abilitySource="live trainer window",
          instruction="Trainerfenster öffnen; ForeverPath übernimmt nur tatsächlich verfügbare Fähigkeiten.",
        }
      end
    end
  end
  table.sort(output, function(a, b)
    if (a.order or 0) == (b.order or 0) then return tostring(a.id or "") < tostring(b.id or "") end
    return (a.order or 0) < (b.order or 0)
  end)
  return output
end

function NS:GetAuthoredInstruction(step)
  local guide = step and (step.authored or step.guide)
  return guide and guide.instruction or nil
end

function NS:GetAuthoredAbilities()
  local summary = self.GetTrainerSummary and self:GetTrainerSummary() or ""
  if summary and summary ~= "" then return summary end
  return self.L and self:L("Noch kein Trainerfenster besucht. Beim Öffnen werden verfügbare Fähigkeiten automatisch erfasst.") or "Noch kein Trainerfenster besucht. Beim Öffnen werden verfügbare Fähigkeiten automatisch erfasst."
end
