local NS = ForeverPath

-- Eigenständige, redaktionelle Guide-Schritte. Die Questdaten selbst kommen
-- weiterhin aus ForeverDB/den offenen lokalen Daten; diese Datei beschreibt
-- nur die Reihenfolge und die Handlung, die ForeverPath daraus machen soll.

local function quest(id, order, zone, instruction)
  return {
    kind="quest", questID=id, order=order, zone=zone,
    instruction=instruction or "Quest annehmen, Ziele im Questlog verfolgen und gebündelt abgeben.",
    items={"Questgegenstände aus dem Questlog verfolgen"},
  }
end

local function travel(id, order, level, zone, title, body)
  return {kind="travel", id=id, order=order, level=level, zone=zone, title=title, body=body}
end

local function action(id, order, level, zone, title, body)
  return {kind="route", id=id, order=order, level=level, zone=zone, title=title, body=body, instruction=body}
end

NS.authoredGuides = {
  horde = {
    action("guide:horde:01", 1, 1, "Tirisfal Glades", "Startpunkt prüfen", "Heimatort setzen, Munition/Verbrauchsgüter prüfen und den lokalen Flugpunkt für später markieren."),
    action("guide:horde:02", 2, 1, "Tirisfal Glades", "Klassenlehrer besuchen", "Beim Klassenlehrer verfügbare Fähigkeiten prüfen und alle bezahlbaren Zauber direkt lernen."),
    action("guide:horde:03", 3, 1, "Tirisfal Glades", "Erste Aufgabe annehmen", "Zum Questgeber gehen, das Gespräch öffnen und die passende Startquest annehmen."),
    travel("guide:horde:deathknell", 10, 1, "Tirisfal Glades", "Deathknell: Start und Klassenlehrer", "Heimatort setzen, Klassenlehrer besuchen, Taschen/Verbrauchsgüter prüfen und die Startkette beginnen."),
    action("guide:horde:11", 11, 1, "Tirisfal Glades", "Startziele erledigen", "Die Gegner- und Sammelziele aus dem Questlog in einer kurzen Runde erledigen; unnötige Umwege vermeiden."),
    quest(363, 20, "Tirisfal Glades", "Bei Novice Elreth annehmen, die Startziele erledigen und zur Abgabe zurückkehren."),
    action("guide:horde:21", 21, 2, "Tirisfal Glades", "Queststatus prüfen", "Nach jeder Runde den Questlog öffnen: erfüllte Ziele zuerst abgeben, offene Ziele für die nächste Schleife markieren."),
    quest(364, 30, "Tirisfal Glades", "Mindless Ones im markierten Bereich erledigen; danach beim Questgeber abgeben."),
    action("guide:horde:31", 31, 2, "Tirisfal Glades", "Folgequests am Hub prüfen", "Nach der Abgabe beim selben Hub nach einer Folgequest schauen und sie nur bei passendem Level annehmen."),
    quest(365, 40, "Tirisfal Glades", "Fields of Grief als Sammel-/Gebietsrunde erledigen, bevor du weiterziehst."),
    action("guide:horde:41", 41, 3, "Tirisfal Glades", "Gebietsrunde bündeln", "Sammelziele und Gegnerziele im selben Gebiet kombinieren; erst danach zur Abgabe zurückkehren."),
    quest(376, 50, "Tirisfal Glades", "The Damned annehmen, die Ziele in einer Runde erledigen und die Folgequests am selben Hub prüfen."),
    action("guide:horde:51", 51, 4, "Tirisfal Glades", "Abgabe und Folgequest", "Quest beim Hub abgeben, Folgequest prüfen und die nächste Zielgruppe auf der Karte ansteuern."),
    quest(380, 60, "Tirisfal Glades", "Night Web's Hollow mit den übrigen Deathknell-Zielen bündeln; keine einzelne Rückreise erzwingen."),
    action("guide:horde:61", 61, 4, "Tirisfal Glades", "Gefährliche Ziele markieren", "Elite- oder dicht besetzte Ziele für eine Gruppe markieren; sichere Soloziele zuerst abschließen."),
    quest(381, 70, "Tirisfal Glades", "Scarlet-Ziele erledigen und die Abgabe mit Red-Messenger-/Vital-Intelligence-Schritten verbinden."),
    action("guide:horde:71", 71, 5, "Tirisfal Glades", "Rückweg vermeiden", "Abgaben nach NPC-Position bündeln und keine einzelne Quest für einen separaten Rückweg einplanen."),
    quest(382, 80, "Tirisfal Glades", "Red Messenger annehmen, Zielgebiet verfolgen und beim passenden NPC abgeben."),
    quest(383, 90, "Tirisfal Glades", "Vital Intelligence abgeben und die nächste Kette sofort am Hub übernehmen."),
    action("guide:horde:91", 91, 6, "Tirisfal Glades", "Training vor dem Zonenwechsel", "Vor dem Verlassen des Startgebiets den Trainer, Händler, Reparatur und Gasthof in einem Stopp erledigen."),
    quest(367, 100, "Tirisfal Glades", "A New Plague als Kettenrunde führen; Folgequests erst nach der aktuellen Abgabe priorisieren."),
    quest(368, 110, "Tirisfal Glades", "A-New-Plague-Folgequest mit dem aktuellen Questlog und den örtlichen Gegnerzielen kombinieren."),
    quest(369, 120, "Tirisfal Glades", "Die dritte Plague-Stufe abschließen und erst danach den Zonenwechsel vorbereiten."),
    quest(370, 130, "Tirisfal Glades", "Scarlet-Crusade-Ziele in einer sicheren Runde erledigen; Eliteziele nur mit Gruppe."),
    quest(371, 140, "Tirisfal Glades", "Die Folgeziele der Scarlet-Kette ohne unnötigen Hauptstadtumweg abarbeiten."),
    quest(372, 150, "Tirisfal Glades", "Kettenabschluss abgeben und die nächste Zone nach Level, Questlog und Reisezeit wählen."),
    quest(374, 160, "Tirisfal Glades", "Proof of Demise zusammen mit den übrigen offenen Abgaben abgeben."),
    quest(375, 170, "Tirisfal Glades", "The Chill of Death als letzte lokale Runde vor dem Übergang abschließen."),
    quest(3902, 180, "Tirisfal Glades", "Scavenging Deathknell nur in derselben Deathknell-Runde erledigen; keine Einzelreise."),
    quest(6395, 190, "Tirisfal Glades", "Marla's Last Wish annehmen oder abgeben, sobald der Questgeber auf der aktuellen Route liegt."),
    action("guide:horde:191", 191, 6, "Tirisfal Glades", "Questlog aufräumen", "Niedrige Abgaben abschließen, Questgegenstände prüfen und freien Taschenplatz für den Zonenwechsel schaffen."),
    travel("guide:horde:undercity", 200, 6, "Tirisfal Glades", "Undercity: Training und Reise bündeln", "Klassenfähigkeiten, Erste Hilfe, Reparatur, Händler und Flugpunkt in einem Stopp zusammenfassen; danach Silberwald vorbereiten."),
    action("guide:horde:201", 201, 6, "Undercity", "Stadtstopp abschließen", "Neue Fähigkeiten lernen, Erste Hilfe aktualisieren, reparieren, verkaufen und den Gasthof setzen."),
    travel("guide:horde:silverpine", 210, 10, "Silverpine Forest", "Silverpine Forest: nächster Questhub", "Flugpunkt sichern, verfügbare Aufgaben sammeln und die lokale Questschleife vor dem nächsten Zonenwechsel abschließen."),
  },
  alliance = {
    action("guide:alliance:01", 1, 1, "Elwynn Forest", "Startpunkt prüfen", "Heimatort setzen, Taschen prüfen und den Weg zum Northshire-Hub beginnen."),
    action("guide:alliance:02", 2, 1, "Elwynn Forest", "Klassenlehrer besuchen", "Beim Klassenlehrer verfügbare Fähigkeiten prüfen und die bezahlbaren Zauber direkt lernen."),
    action("guide:alliance:03", 3, 1, "Elwynn Forest", "Erste Aufgabe annehmen", "Zum Questgeber gehen, das Gespräch öffnen und die passende Startquest annehmen."),
    travel("guide:alliance:northshire", 10, 1, "Elwynn Forest", "Northshire: Start und Klassenlehrer", "Heimatort setzen, Klassenlehrer besuchen, Taschen/Verbrauchsgüter prüfen und die Startkette beginnen."),
    action("guide:alliance:11", 11, 1, "Elwynn Forest", "Startziele erledigen", "Die Northshire-Ziele in einer Runde abarbeiten und nach jedem Ziel den Queststatus prüfen."),
    quest(783, 20, "Elwynn Forest", "A Threat Within annehmen und die Startziele im Northshire-Hub erledigen."),
    action("guide:alliance:21", 21, 2, "Elwynn Forest", "Questabgabe bündeln", "Quest beim Hub abgeben, die Folgequest prüfen und keine einzelne Aufgabe für einen Rückweg laufen."),
    quest(7, 30, "Elwynn Forest", "Kobold Camp Cleanup als Nahbereichsrunde erledigen und die Folgequests am selben NPC prüfen."),
    action("guide:alliance:31", 31, 2, "Elwynn Forest", "Ziele im Nahbereich bündeln", "Kobold- und Sammelziele in derselben Runde erledigen; Questgeber erst nach dem vollständigen Loop besuchen."),
    quest(18, 40, "Elwynn Forest", "Brotherhood of Thieves annehmen, Ziele bündeln und Bounty-/Milly-Folgequests vorbereiten."),
    quest(6, 50, "Elwynn Forest", "Bounty on Garrick Padfoot auf dem Weg erledigen, statt dafür separat zurückzulaufen."),
    action("guide:alliance:51", 51, 3, "Elwynn Forest", "Folgequest prüfen", "Nach der Abgabe die Kette am gleichen Hub fortsetzen und neue Questziele in die Rückrunde aufnehmen."),
    quest(15, 60, "Elwynn Forest", "Investigate Echo Ridge mit dem Northshire-Questlog verbinden und die Folgequest offen halten."),
    quest(21, 70, "Elwynn Forest", "Skirmish at Echo Ridge abschließen und Report to Goldshire als nächsten Reiseanker setzen."),
    action("guide:alliance:71", 71, 4, "Elwynn Forest", "Goldshire vorbereiten", "Vor dem Aufbruch Questlog sortieren, Taschen leeren und den nächsten Trainer-/Händlerstopp einplanen."),
    quest(54, 80, "Elwynn Forest", "Report to Goldshire annehmen/abgeben und Training, Händler und Gasthof bündeln."),
    quest(59, 90, "Elwynn Forest", "Cloth and Leather Armor nur zusammen mit dem Goldshire-Stopp erledigen."),
    quest(60, 100, "Elwynn Forest", "Kobold Candles in derselben Fargodeep-Runde sammeln und anschließend gebündelt abgeben."),
    action("guide:alliance:101", 101, 5, "Elwynn Forest", "Trainer und Erste Hilfe", "Beim Goldshire-Stopp Klassenfähigkeiten und Erste Hilfe lernen, reparieren und den Flugpunkt sichern."),
    quest(62, 110, "Elwynn Forest", "Fargodeep MineEx als lokale Zielrunde erledigen; den Wegpunkt aus dem Questlog bevorzugen."),
    quest(52, 120, "Elwynn Forest", "Protect the Frontier annehmen und Ziele auf dem Übergang nach Westfall bündeln."),
    action("guide:alliance:121", 121, 6, "Elwynn Forest", "Übergang nach Westfall", "Abgaben am Hub abschließen, nur passende Folgequests mitnehmen und den Zonenwechsel als eine Reise planen."),
    travel("guide:alliance:goldshire", 130, 6, "Elwynn Forest", "Goldshire: Training und Reise bündeln", "Klassenfähigkeiten, Erste Hilfe, Reparatur, Händler und Flugpunkt in einem Stopp zusammenfassen."),
    action("guide:alliance:131", 131, 6, "Elwynn Forest", "Stadtstopp abschließen", "Neue Fähigkeiten lernen, Erste Hilfe aktualisieren, reparieren, verkaufen und den Gasthof setzen."),
    travel("guide:alliance:westfall", 140, 10, "Westfall", "Westfall: nächster Questhub", "Flugpunkt sichern, Aufgaben sammeln und die Westfall-Runde nach Zielen statt nach Einzelquests laufen."),
  },
}

local function factionKey()
  return UnitFactionGroup and UnitFactionGroup("player") == "Horde" and "horde" or "alliance"
end

function NS:GetAuthoredGuideSpec(questID)
  questID = tonumber(questID)
  if not questID then return nil end
  local guide = self.authoredGuides and self.authoredGuides[factionKey()] or {}
  for _, entry in ipairs(guide) do
    if entry.kind == "quest" and entry.questID == questID then return entry end
  end
  return nil
end

local function recentTrainerSeen(self)
  local newest
  for _, stop in pairs(self.db and self.db.stops or {}) do
    if stop.kind == "trainer" and (not newest or (stop.at or 0) > (newest.at or 0)) then newest = stop end
  end
  return newest
end

function NS:GetAuthoredGuideSpecs(context)
  context = context or (self.GetPlanningContext and self:GetPlanningContext()) or {level=1, zone=""}
  local level = tonumber(context.level) or 1
  local output = {}
  local selectedGuide, activeGuide
  if self.BuildGuideSpecs then
    selectedGuide, activeGuide = self:BuildGuideSpecs(context)
  end
  local guide = selectedGuide and #selectedGuide > 0 and selectedGuide or (self.authoredGuides and self.authoredGuides[factionKey()] or {})
  -- The original authored quest anchors remain useful for the two starter
  -- paths where ForeverPath already has its own quest-ID mapping.  Other
  -- race starts use their own catalog steps plus the live quest log, so a
  -- Tirisfal/Elwynn quest must never leak into Durotar, Mulgore or Teldrassil.
  local baseGuide = self.authoredGuides and self.authoredGuides[factionKey()] or {}
  local includeBaseQuests = not activeGuide or activeGuide.key == "horde_undead" or activeGuide.key == "alliance_human"
  for _, entry in ipairs(guide) do
    local entryLevel = entry.level
    if entry.kind == "quest" then
      local record = self.questDB and self.questDB[entry.questID]
      entryLevel = entryLevel or (record and (record.requiredLevel or record.level)) or 1
      if entryLevel <= level + 6 and entryLevel >= level - 5 then output[#output + 1] = entry end
    elseif entryLevel and entryLevel <= level + 2 and entryLevel >= level - 3 then
      output[#output + 1] = entry
    end
  end

  if includeBaseQuests and guide ~= baseGuide then
    for _, entry in ipairs(baseGuide) do
      if entry.kind == "quest" then
        local record = self.questDB and self.questDB[entry.questID]
        local entryLevel = entry.level or (record and (record.requiredLevel or record.level)) or 1
        if entryLevel <= level + 6 and entryLevel >= level - 5 then output[#output + 1] = entry end
      end
    end
  end

  -- Other Forever starts and non-quest modes use the existing independent
  -- route tables as a safe fallback. They remain explicit guide stops until
  -- the live quest log supplies a more precise quest step. Keep a few route
  -- rows available when the authored starter segment is no longer level-nearby
  -- (for example at level 16+), otherwise the guide would look empty apart
  -- from a single trainer milestone.
  if #output < 3 and self.routes then
    local routeSet = self.routes[factionKey()] or self.routes.alliance or {}
    local route = routeSet[(self.db and self.db.mode) or "speed"] or routeSet.speed or {}
    for index, entry in ipairs(route) do
      if entry and entry.id and (not entry.level or entry.level <= level + 8) and (not entry.level or entry.level >= level - 6) then
        output[#output + 1] = {
          kind="route", id="guide:" .. factionKey() .. ":" .. tostring(entry.id), order=entry.level * 10 + index,
          level=entry.level, zone=entry.zone, title=entry.title, body=entry.body,
          instruction=entry.body, source="eigene ForeverPath-Routentabelle",
        }
      end
    end
  end

  -- Exact spell names come from the live trainer window when opened.
  local token = self.GetClassToken and self:GetClassToken() or "DEFAULT"
  local plan = self.classLevelPlans and (self.classLevelPlans[token] or self.classLevelPlans.DEFAULT) or {}
  local observed = recentTrainerSeen(self)
  for index, milestone in ipairs(plan) do
    local milestoneLevel, hint, place = milestone[1], milestone[2], milestone[3]
    if milestoneLevel and milestoneLevel <= level + 4 and milestoneLevel >= level - 2 then
      local id = "guide:trainer:" .. token .. ":" .. tostring(milestoneLevel)
      local completed = self.db and self.db.completed and self.db.completed[id]
      local alreadyObserved = observed and observed.at and observed.at >= (self.session and self.session.started or 0) and milestoneLevel <= level
      if not completed and not alreadyObserved then
        output[#output + 1] = {
          kind="trainer", id=id, order=500 + index, level=milestoneLevel,
          class=token, zone=place, title="Klassenlehrer · Stufe " .. tostring(milestoneLevel),
          body=hint .. "\nOrt: " .. tostring(place),
          abilitySource="live trainer window",
          instruction="Trainerfenster öffnen; ForeverPath übernimmt nur tatsächlich verfügbare Fähigkeiten.",
        }
      end
    end
  end
  table.sort(output, function(a, b)
    if (a.order or 0) == (b.order or 0) then return tostring(a.id or "") < tostring(b.id or "") end
    return (a.order or 0) < (b.order or 0)
  end)
  return output
end

function NS:GetAuthoredInstruction(step)
  local guide = step and (step.authored or step.guide)
  return guide and guide.instruction or nil
end

function NS:GetAuthoredAbilities()
  local summary = self.GetTrainerSummary and self:GetTrainerSummary() or ""
  if summary and summary ~= "" then return summary end
  return self.L and self:L("Noch kein Trainerfenster besucht. Beim Öffnen werden verfügbare Fähigkeiten automatisch erfasst.") or "Noch kein Trainerfenster besucht. Beim Öffnen werden verfügbare Fähigkeiten automatisch erfasst."
end

-- Small, reusable visual vocabulary for the in-game guide. These are Blizzard
-- interface textures, not copied addon assets; the surrounding layout remains
-- ForeverPath's own design.
function NS:GetGuideIcon(step, entry)
  step = step or entry
  local kind = step and (step.kind or step.phase) or ""
  local title = string.lower(tostring((step and (step.title or step.instruction)) or ""))
  if kind == "trainer" or string.find(title, "trainer", 1, true) or string.find(title, "fähigkeit", 1, true) or string.find(title, "spell", 1, true) then
    return "Interface\\Icons\\Trade_Engineering"
  end
  if kind == "travel" or string.find(title, "reise", 1, true) or string.find(title, "flug", 1, true) or string.find(title, "zeppelin", 1, true) or string.find(title, "stadtstopp", 1, true) then
    return "Interface\\Minimap\\Tracking\\FlightMaster"
  end
  if kind == "quest" and step.phase == "turnin" or string.find(title, "abgabe", 1, true) or string.find(title, "abgeben", 1, true) then
    return "Interface\\GossipFrame\\ActiveQuestIcon"
  end
  if kind == "quest" and step.phase == "accept" or string.find(title, "annehmen", 1, true) or string.find(title, "questgeber", 1, true) then
    return "Interface\\GossipFrame\\AvailableQuestIcon"
  end
  if kind == "route" or kind == "travel" or string.find(title, "startpunkt", 1, true) or string.find(title, "prüfen", 1, true) then
    return "Interface\\Icons\\INV_Misc_Map_01"
  end
  return "Interface\\Icons\\INV_Misc_Note_01"
end

function NS:GetGuideIconMarkup(step, entry, size)
  local icon = self:GetGuideIcon(step, entry)
  size = tonumber(size) or 14
  return string.format("|T%s:%d:%d:0:0|t", icon, size, size)
end
