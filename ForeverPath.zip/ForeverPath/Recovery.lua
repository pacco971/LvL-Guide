local NS=ForeverPath
function NS:GetRouteRecovery()
  for _,r in ipairs(self:GetRecommendations(3)) do
    if r.index~=self.db.step then return r end
  end
end
function NS:ApplyRouteRecovery()
  local recovery=self:GetRouteRecovery(); if not recovery then return false end
  local current=self:GetCurrentStep()
  self.db.returnStepID=current and current.id; self:SelectStep(recovery.index); return true
end
function NS:ReturnToRoute()
  local id=self.db.returnStepID; self.db.returnStepID=nil
  for i,s in ipairs(self:GetSteps()) do if s.id==id then self:SelectStep(i); return end end
  self.db.selectedStepID=nil; self:InvalidateQuestPlan(); self:Refresh()
end
