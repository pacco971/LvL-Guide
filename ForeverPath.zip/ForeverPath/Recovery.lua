local NS = ForeverPath

local function sameZone(a, b)
  if not a or not b then return false end
  a, b = string.lower(a), string.lower(b)
  return string.find(a, b, 1, true) or string.find(b, a, 1, true)
end

function NS:GetRouteRecovery()
  if not self.db or not self.GetSteps or not self.GetPlayerZone then return nil end
  local zone = self:GetPlayerZone()
  if zone == "Unbekannt" then return nil end
  local steps = self:GetSteps()
  local current = self.db.step or 1
  local best, bestScore = nil, -math.huge
  for index = current + 1, #steps do
    local step = steps[index]
    if step and not self.db.completed[step.id] and sameZone(step.zone, zone) then
      local score = self.ScoreStep and select(1, self:ScoreStep(step)) or 0
      if score > bestScore then best, bestScore = { index=index, step=step, skipped=index-current-1 }, score end
    end
  end
  return best
end

function NS:ApplyRouteRecovery()
  local recovery = self:GetRouteRecovery()
  if not recovery then return false end
  self.db.step = recovery.index
  self:Refresh()
  self:Print("Route synchronisiert: " .. recovery.step.title)
  return true
end
