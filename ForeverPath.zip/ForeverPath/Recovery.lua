local NS = ForeverPath

local function sameZone(a, b)
  if not a or not b then return false end
  a, b = string.lower(a), string.lower(b)
  return string.find(a, b, 1, true) or string.find(b, a, 1, true)
end

function NS:GetRouteRecovery()
  if not self.db or not self.GetSteps or not self.GetPlayerZone then return nil end
  if self.NormalizeProgress then self:NormalizeProgress() end
  local zone = self:GetPlayerZone()
  if zone == "Unbekannt" then return nil end
  local steps = self:GetSteps()
  local current = self.db.step or 1
  local best, bestScore = nil, -math.huge
  for index = current + 1, #steps do
    local step = steps[index]
    if step and not self.db.completed[step.id] and sameZone(step.zone, zone) then
      local score = self.ScoreStep and select(1, self:ScoreStep(step)) or 0
      if score > bestScore then best, bestScore = { index=index, step=step, skipped=index-current-1 }, score end
    end
  end
  if best then best.reason = "Aktuelle Zone"; return best end

  -- Wenn die aktuelle Zone nicht mehr zur linearen Route passt, wird eine
  -- passende Alternative aus dem Score-Ranking angeboten. Die Route bleibt
  -- dabei unverändert; nach dem Alternativschritt geht es normal weiter.
  if self.GetRecommendations then
    local ranked = self:GetRecommendations(5); local currentScore = -math.huge
    local currentStep = self:GetCurrentStep()
    if currentStep and self.ScoreStep then currentScore = select(1, self:ScoreStep(currentStep)) end
    for _, candidate in ipairs(ranked) do
      if candidate.index ~= current and candidate.step and candidate.score >= currentScore - 8 then
        return { index=candidate.index, step=candidate.step, skipped=math.max(0, candidate.index-current-1), dynamic=true, reason="Score-Alternative", returnIndex=current + 1, score=candidate.score }
      end
    end
  end
  return nil
end

function NS:ApplyRouteRecovery()
  local recovery = self:GetRouteRecovery()
  if not recovery then return false end
  self.db.step = recovery.index
  if recovery.dynamic then self.db.recoveryReturnStep = recovery.returnIndex end
  self:Refresh()
  self:Print((recovery.dynamic and "Alternative Route gewählt: " or "Route synchronisiert: ") .. recovery.step.title)
  return true
end
