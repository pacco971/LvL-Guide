local NS=ForeverPath
local phases={accept="Annehmen",objective="Ziele",turnin="Abgeben"}
local function contains(t,v)
  if not t or not next(t) then return true end
  if v and (t[v] or t[string.lower(tostring(v))]) then return true end
  for _,x in pairs(t) do if x==v then return true end end
  for k in pairs(t) do if k==v or string.lower(tostring(k))==string.lower(tostring(v)) then return true end end
  return false
end
local function lower(value) return value and string.lower(tostring(value)) or "" end
local function asIDs(value)
  if not value then return {} end
  if type(value)=="number" then return {value} end
  if type(value)~="table" then return {} end
  local result={}; for _,entry in pairs(value) do
    local id=type(entry)=="table" and (entry.questID or entry.id) or entry
    if tonumber(id) then result[#result+1]=tonumber(id) end
  end
  return result
end
local function zoneMatches(a,b)
  a,b=lower(a),lower(b); if a=="" or b=="" then return false end
  return a==b or string.find(a,b,1,true)~=nil or string.find(b,a,1,true)~=nil
end
function NS:GetPlanningContext()
  local map=C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
  local zone=self.GetPlayerZone and self:GetPlayerZone() or "Unbekannt"
  local info=map and C_Map.GetMapInfo and C_Map.GetMapInfo(map)
  return {mapID=map,zone=zone,mapName=info and info.name or zone,level=self:GetPlayerLevel(),faction=UnitFactionGroup and UnitFactionGroup("player") or "",class=self:GetClassToken()}
end
function NS:IsRecordInCurrentZone(record,context)
  if not record or not context then return false end
  if record.mapID and context.mapID and record.mapID==context.mapID then return true end
  return zoneMatches(record.zone,context.zone) or zoneMatches(record.zone,context.mapName)
end
function NS:IsQuestTurnedIn(id)
  if self.db.turnedIn[id] then return true end
  local fn=C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted or IsQuestFlaggedCompleted
  return fn and fn(id)==true or false
end
function NS:GetQuestPhase(id)
  local live=self:GetLiveQuest(id)
  if not live then return self:IsQuestTurnedIn(id) and "done" or "accept" end
  if live.isComplete then return "turnin" end
  local objectives=live.objectives or {}
  if #objectives==0 then return "objective" end
  for _,o in ipairs(objectives) do
    if not o.finished and not ((o.numRequired or 0)>0 and (o.numFulfilled or 0)>=o.numRequired) then return "objective" end
  end
  return "turnin"
end
function NS:IsQuestEligible(r)
  if self.db.skippedQuests[r.id] then return false,"übersprungen" end
  if self:GetLiveQuest(r.id) then return true end
  if self:IsQuestTurnedIn(r.id) or r.repeatable then return false,"abgegeben / wiederholbar" end
  local faction=UnitFactionGroup("player")
  local requiredFaction=lower(r.faction)
  if requiredFaction~="" and requiredFaction~="both" and requiredFaction~="b" and requiredFaction~="neutral" then
    local wanted=requiredFaction=="a" and "alliance" or requiredFaction=="h" and "horde" or requiredFaction
    if lower(faction)~=wanted then return false,"Fraktion" end
  end
  local _,class=UnitClass("player"); local _,race=UnitRace("player")
  if not contains(r.classes,class) or not contains(r.races,race) then return false,"Klasse / Volk" end
  local level=self:GetPlayerLevel()
  if (r.requiredLevel or r.minLevel or 1)>level or (r.level or r.minLevel or level)>level+3 or (r.level or r.minLevel or level)<level-5 then return false,"Level" end
  local raw=self.Quests and self.Quests[r.id] or r
  for _,id in ipairs(asIDs(raw.sourceQuestGroup)) do if not self:IsQuestTurnedIn(id) then return false,"Vorquest" end end
  local single=asIDs(raw.sourceQuestSingle)
  if #single>0 then
    local count=0; for _,id in ipairs(single) do if self:IsQuestTurnedIn(id) then count=count+1 end end
    if count<(raw.sourceQuestNumRequired or 1) then return false,"Vorquest" end
  elseif #asIDs(r.chainPrevious)>0 then
    for _,id in ipairs(asIDs(r.chainPrevious)) do if not self:IsQuestTurnedIn(id) then return false,"Kettenvorgänger" end end
  end
  return true
end
function NS:GetPlannedWaypoint(s)
  if not s or not s.questID then return nil end
  local r=s.record or self.questDB[s.questID] or {}
  local phase=s.phase
  local live=self:GetLiveQuest(s.questID)
  -- The live quest log is authoritative for the current objective.  ForeverDB
  -- supplies the stable NPC/hand-in data, while the client POI can point to
  -- the actual mob, object or item location for this character.
  if phase=="objective" and live and live.logWaypoint then
    local kind="objective"
    for _,o in ipairs(live.objectives or {}) do
      if not o.finished then
        if o.type=="item" then kind="item" elseif o.type=="monster" then kind="enemy" end
        break
      end
    end
    return {mapID=live.logWaypoint.mapID,x=live.logWaypoint.x,y=live.logWaypoint.y,name=live.logWaypoint.name,title=r.title or live.title,hint=live.logWaypoint.name or live.title,kind=kind,questID=s.questID,source=live.logWaypoint.source or "WoW Forever Quest POI"}
  end
  local p=phase=="accept" and r.startPoint or phase=="turnin" and r.turnInPoint or nil
  if not p and phase=="accept" and r.qg then p={mapID=r.mapID,x=r.x,y=r.y,id=r.qg} end
  if not p then
    for _,route in ipairs(self.externalRoutesByQuest[s.questID] or {}) do
      if not route.class or route.class==self:GetClassToken() then
        local candidate=phase=="accept" and route.giver or phase=="turnin" and route.turnin or phase=="objective" and route.objective
        if candidate and not string.find(string.lower(candidate.name or ""),"verify",1,true) and not string.find(string.lower(candidate.name or ""),"unconfirmed",1,true) then p=candidate; break end
      end
    end
  end
  if not p or not p.mapID or not p.x or not p.y or p.x<0 or p.x>100 or p.y<0 or p.y>100 then return nil end
  local kind=phase=="accept" and "giver" or phase=="turnin" and "turnin" or "objective"
  for _,o in ipairs(live and live.objectives or {}) do if not o.finished then kind=phase=="objective" and (o.type=="item" and "item" or o.type=="monster" and "enemy" or kind) or kind; break end end
  return {mapID=p.mapID,x=p.x,y=p.y,name=p.name,title=r.title,hint=p.name or r.title,kind=kind,questID=s.questID,source=p.source or (r.foreverDB and "ForeverDB.net" or "QuestieDB / Evergreen")}
end
function NS:InvalidateQuestPlan() self.questPlan=nil; self.questPlanSignature=nil; self.upcomingWaypointsCache=nil end
function NS:GetQuestPlanSignature()
  local c=self:GetPlanningContext(); local state=self.questState or self:RefreshQuestState(); local active=0; for _ in pairs(state.quests or {}) do active=active+1 end
  local turned=0; for _ in pairs(self.db.turnedIn or {}) do turned=turned+1 end
  return table.concat({c.mapID or 0,lower(c.zone),c.level or 0,c.faction or "",c.class or "",active,turned,self.questStateRevision or 0,self.db.selectedStepID or ""},"|")
end
function NS:BuildQuestPlan()
  local result={}; local context=self:GetPlanningContext(); local selected=self.db.selectedStepID; local selectedID=selected and tonumber(selected:match("^[^:]+:(%d+):")); local seen={}; local liveCount=0; local localCandidates=0
  local state=self.questState or self:RefreshQuestState()

  local function makeStep(id, record, phase, live, priority)
    if not id or not record then return nil end
    local s={id="q:"..id..":"..phase,questID=id,questIDs={id},phase=phase,title=phases[phase]..": "..(record.title or tostring(id)),record=record,level=record.level or record.minLevel or (live and live.level),zone=record.zone or (live and live.zone) or "Unbekannt",mapID=record.mapID}
    local point=self:GetPlannedWaypoint(s); s.mapID=point and point.mapID or record.mapID
    s.currentZone=self:IsRecordInCurrentZone(record,context) or (live and zoneMatches(live.zone,context.zone)) or (point and point.mapID and point.mapID==context.mapID)
    s.priority=priority or 0
    s.priority=s.priority+(s.currentZone and 180 or -80)+(s.mapID==context.mapID and 35 or 0)-math.abs((s.level or context.level)-context.level)*3
    if point then s.priority=s.priority+30 else s.priority=s.priority-20 end
    if record.chainNext then s.priority=s.priority+math.min(18,#asIDs(record.chainNext)*6) end
    if record.chainPrevious then s.priority=s.priority+8 end
    if record.classes and next(record.classes) then s.priority=s.priority+8 end
    return s
  end

  -- First and always: quests that are actually in the player's quest log.
  -- This prevents a generic guide step from hiding the player's real work.
  for key, live in pairs(state.quests or {}) do
    local id=live.id or (type(key)=="number" and key)
    local record=(id and self.questDB[id]) or live.record or self:FindQuestRecordByTitle(live.title)
    if id and not record then
      record={id=id,title=live.title,level=live.level,zone=live.zone}
      self.questDB[id]=record
    end
    if id and record and not self.questDB[id] then self.questDB[id]=record end
    if id and record and not seen[id] then
      seen[id]=true; liveCount=liveCount+1
      local phase=self:GetQuestPhase(id)
      if phase~="done" then result[#result+1]=makeStep(id,record,phase,live,phase=="turnin" and 1000 or 760) end
    end
  end

  -- With active quests, only show nearby/follow-up offers next.  The full
  -- database remains available, but it must not become the active route.
  local followUp={}
  for id in pairs(seen) do
    local record=self.questDB[id]
    for _,nextID in ipairs(asIDs(record and record.chainNext)) do followUp[nextID]=true end
  end
  for id, record in pairs(self.questDB or {}) do
    if type(id)=="number" and not seen[id] and self:IsQuestEligible(record) then
      local phase=self:GetQuestPhase(id)
      if phase=="accept" then
        local point=self:GetPlannedWaypoint({questID=id,phase="accept",record=record})
        local nearby=self:IsRecordInCurrentZone(record,context) or (point and point.mapID==context.mapID)
        if liveCount==0 or nearby or followUp[id] then
          local priority=followUp[id] and 430 or 250
          local step=makeStep(id,record,"accept",nil,priority)
          if step then
            if step.currentZone then localCandidates=localCandidates+1 end
            result[#result+1]=step
          end
        end
      end
    end
  end

  -- If no quest is active and no nearby offers exist, keep the old broad guide
  -- as a safe fallback instead of showing an empty route.
  if #result==0 then
    for id, record in pairs(self.questDB or {}) do
      if type(id)=="number" and self:IsQuestEligible(record) and self:GetQuestPhase(id)=="accept" then
        local step=makeStep(id,record,"accept",nil,120)
        if step then result[#result+1]=step end
      end
    end
  end

  table.sort(result,function(a,b) if a.priority==b.priority then return a.questID<b.questID end return a.priority>b.priority end)
  self.db.step=1
  for i,s in ipairs(result) do if s.id==selected or s.questID==selectedID then self.db.step=i; break end end
  self.db.selectedStepID=result[self.db.step] and result[self.db.step].id or nil
  self.questPlan=result; self.questPlanSignature=self:GetQuestPlanSignature()
  return result
end
function NS:GetQuestPlan()
  local signature=self:GetQuestPlanSignature()
  if self.questPlan and self.questPlanSignature==signature then return self.questPlan end
  return self:BuildQuestPlan()
end
function NS:IsPlannedStepComplete(s)
  local phase=self:GetQuestPhase(s.questID)
  return phase=="done" or s.phase=="accept" and phase~="accept" or s.phase=="objective" and phase=="turnin"
end
function NS:GetPlannedObjective(s)
  local q=self:GetLiveQuest(s.questID); if not q then return nil end
  local done,total=0,0
  local first
  for _,o in ipairs(q.objectives or {}) do
    local required=math.max(1,o.numRequired or 0)
    total=total+required; done=done+(o.finished and required or math.min(required,o.numFulfilled or 0))
    if not first and not o.finished and (o.numFulfilled or 0)<required then first=o.text end
  end
  return {quest=q,text=first or (self:GetQuestPhase(s.questID)=="turnin" and "Quest kann abgegeben werden" or q.title),done=done,required=total}
end
function NS:GetPlannedText(s)
  local p=self:GetPlannedWaypoint(s); local o=self:GetPlannedObjective(s)
  local text=string.format("%s · Quest-ID %s",phases[s.phase] or s.phase,s.questID and tostring(s.questID) or "unbekannt")
  if o then text=text.."\n"..o.text end
  text=text.."\n"..(p and string.format("%s · %.1f / %.1f",p.hint or "Ziel",p.x,p.y) or "Zielkoordinaten fehlen – Questbeschreibung prüfen.")
  local nexts={}
  for _,n in ipairs(s.record.chainNext or {}) do nexts[#nexts+1]=tostring(n.questID) end
  if #nexts>0 then text=text.."\nFolgequests: "..table.concat(nexts,", ").." (Voraussetzungen prüfen)" end
  if self.GetTravelAdvice then text=text.."\n"..self:GetTravelAdvice(s) end
  return text.."\nQuelle: "..(s.record.foreverDB and "https://foreverdb.net" or "QuestieDB-Forever / Live-Questlog")
end
local oldPoint,oldText,oldObjective=NS.GetBestWaypoint,NS.GetQuestTrackerText,NS.GetTrackedObjective
function NS:GetBestWaypoint(s) if s and s.phase then return self:GetPlannedWaypoint(s) end return oldPoint(self,s) end
function NS:GetQuestTrackerText(s) if s and s.phase then return self:GetPlannedText(s) end return oldText(self,s) end
function NS:GetTrackedObjective(s) if s and s.phase then return self:GetPlannedObjective(s) end return oldObjective(self,s) end
function NS:IsStepComplete(s) return s and s.phase and self:IsPlannedStepComplete(s) or false end
function NS:AutoAdvanceQuestSteps() self:InvalidateQuestPlan(); self:GetQuestPlan() end
