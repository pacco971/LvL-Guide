local NS=ForeverPath
local phases={accept="Annehmen",objective="Ziele",turnin="Abgeben"}
local function contains(t,v)
  if not t or not next(t) then return true end
  for _,x in pairs(t) do if x==v then return true end end
  return false
end
function NS:IsQuestTurnedIn(id)
  if self.db.turnedIn[id] then return true end
  local fn=C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted or IsQuestFlaggedCompleted
  return fn and fn(id)==true or false
end
function NS:GetQuestPhase(id)
  local live=self:GetLiveQuest(id)
  if not live then return self:IsQuestTurnedIn(id) and "done" or "accept" end
  if live.isComplete then return "turnin" end
  local objectives=live.objectives or {}
  if #objectives==0 then return "objective" end
  for _,o in ipairs(objectives) do
    if not o.finished and not ((o.numRequired or 0)>0 and (o.numFulfilled or 0)>=o.numRequired) then return "objective" end
  end
  return "turnin"
end
function NS:IsQuestEligible(r)
  if self.db.skippedQuests[r.id] then return false,"übersprungen" end
  if self:GetLiveQuest(r.id) then return true end
  if self:IsQuestTurnedIn(r.id) or r.repeatable then return false,"abgegeben / wiederholbar" end
  local faction=UnitFactionGroup("player")
  if r.faction and r.faction~="both" and r.faction~="b" and r.faction~="Neutral" and r.faction~=faction then return false,"Fraktion" end
  local _,class=UnitClass("player"); local _,race=UnitRace("player")
  if not contains(r.classes,class) or not contains(r.races,race) then return false,"Klasse / Volk" end
  local level=self:GetPlayerLevel()
  if (r.requiredLevel or r.minLevel or 1)>level or (r.level or r.minLevel or level)>level+3 or (r.level or r.minLevel or level)<level-5 then return false,"Level" end
  local raw=self.Quests and self.Quests[r.id] or r
  for _,id in pairs(raw.sourceQuestGroup or {}) do if not self:IsQuestTurnedIn(id) then return false,"Vorquest" end end
  local single=raw.sourceQuestSingle or {}
  if #single>0 then
    local count=0; for _,id in ipairs(single) do if self:IsQuestTurnedIn(id) then count=count+1 end end
    if count<(raw.sourceQuestNumRequired or 1) then return false,"Vorquest" end
  elseif #((r.chainPrevious) or {})>0 then
    for _,p in ipairs(r.chainPrevious) do if p.questID and not self:IsQuestTurnedIn(p.questID) then return false,"Kettenvorgänger" end end
  end
  return true
end
function NS:GetPlannedWaypoint(s)
  if not s or not s.questID then return nil end
  local r=s.record or self.questDB[s.questID] or {}
  local phase=s.phase
  local p=phase=="accept" and r.startPoint or phase=="turnin" and r.turnInPoint or nil
  if not p and phase=="accept" and r.qg then p={mapID=r.mapID,x=r.x,y=r.y,id=r.qg} end
  if not p then
    for _,route in ipairs(self.externalRoutesByQuest[s.questID] or {}) do
      if not route.class or route.class==self:GetClassToken() then
        local candidate=phase=="accept" and route.giver or phase=="turnin" and route.turnin or phase=="objective" and route.objective
        if candidate and not string.find(string.lower(candidate.name or ""),"verify",1,true) and not string.find(string.lower(candidate.name or ""),"unconfirmed",1,true) then p=candidate; break end
      end
    end
  end
  if not p or not p.mapID or not p.x or not p.y or p.x<0 or p.x>100 or p.y<0 or p.y>100 then return nil end
  local live=self:GetLiveQuest(s.questID); local kind=phase=="accept" and "giver" or phase=="turnin" and "turnin" or "objective"
  for _,o in ipairs(live and live.objectives or {}) do if not o.finished then kind=phase=="objective" and (o.type=="item" and "item" or o.type=="monster" and "enemy" or kind) or kind; break end end
  return {mapID=p.mapID,x=p.x,y=p.y,name=p.name,title=r.title,hint=p.name or r.title,kind=kind,questID=s.questID,source=p.source or (r.foreverDB and "ForeverDB.net" or "QuestieDB / Evergreen")}
end
function NS:InvalidateQuestPlan() self.questPlan=nil end
function NS:BuildQuestPlan()
  local result={}; local map=C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
  for id,r in pairs(self.questDB) do
    if type(id)=="number" and self:IsQuestEligible(r) then
      local phase=self:GetQuestPhase(id)
      if phase~="done" then
        local s={id="q:"..id..":"..phase,questID=id,questIDs={id},phase=phase,title=phases[phase]..": "..(r.title or tostring(id)),record=r,level=r.level or r.minLevel,zone=r.zone or "Unbekannt",mapID=r.mapID}
        local point=self:GetPlannedWaypoint(s); s.mapID=point and point.mapID or r.mapID
        s.priority=(phase=="turnin" and 80 or phase=="objective" and 45 or 10)+(s.mapID==map and 30 or 0)-math.abs((s.level or self:GetPlayerLevel())-self:GetPlayerLevel())*2
        if r.classes and next(r.classes) then s.priority=s.priority+8 end
        if not point then s.priority=s.priority-12 end
        result[#result+1]=s
      end
    end
  end
  -- Live quests missing from the imported database are still trackable.
  for id,q in pairs((self.questState or {}).quests or {}) do
    if not self.questDB[id] then self.questDB[id]={id=id,title=q.title,level=q.level,zone=q.zone}; return self:BuildQuestPlan() end
  end
  table.sort(result,function(a,b) if a.priority==b.priority then return a.questID<b.questID end return a.priority>b.priority end)
  local selected=self.db.selectedStepID; local selectedID=selected and tonumber(selected:match("^q:(%d+):"))
  self.db.step=1
  for i,s in ipairs(result) do if s.id==selected or s.questID==selectedID then self.db.step=i; break end end
  self.questPlan=result
  self.db.selectedStepID=result[self.db.step] and result[self.db.step].id or nil
  return result
end
function NS:GetQuestPlan() return self.questPlan or self:BuildQuestPlan() end
function NS:IsPlannedStepComplete(s)
  local phase=self:GetQuestPhase(s.questID)
  return phase=="done" or s.phase=="accept" and phase~="accept" or s.phase=="objective" and phase=="turnin"
end
function NS:GetPlannedObjective(s)
  local q=self:GetLiveQuest(s.questID); if not q then return nil end
  local done,total=0,0
  local first
  for _,o in ipairs(q.objectives or {}) do
    local required=math.max(1,o.numRequired or 0)
    total=total+required; done=done+(o.finished and required or math.min(required,o.numFulfilled or 0))
    if not first and not o.finished and (o.numFulfilled or 0)<required then first=o.text end
  end
  return {quest=q,text=first or (self:GetQuestPhase(s.questID)=="turnin" and "Quest kann abgegeben werden" or q.title),done=done,required=total}
end
function NS:GetPlannedText(s)
  local p=self:GetPlannedWaypoint(s); local o=self:GetPlannedObjective(s)
  local text=string.format("%s · Quest-ID %d",phases[s.phase] or s.phase,s.questID)
  if o then text=text.."\n"..o.text end
  text=text.."\n"..(p and string.format("%s · %.1f / %.1f",p.hint or "Ziel",p.x,p.y) or "Zielkoordinaten fehlen – Questbeschreibung prüfen.")
  local nexts={}
  for _,n in ipairs(s.record.chainNext or {}) do nexts[#nexts+1]=tostring(n.questID) end
  if #nexts>0 then text=text.."\nFolgequests: "..table.concat(nexts,", ").." (Voraussetzungen prüfen)" end
  return text.."\nQuelle: "..(s.record.foreverDB and "https://foreverdb.net" or "QuestieDB-Forever / Live-Questlog")
end
local oldPoint,oldText,oldObjective=NS.GetBestWaypoint,NS.GetQuestTrackerText,NS.GetTrackedObjective
function NS:GetBestWaypoint(s) if s and s.phase then return self:GetPlannedWaypoint(s) end return oldPoint(self,s) end
function NS:GetQuestTrackerText(s) if s and s.phase then return self:GetPlannedText(s) end return oldText(self,s) end
function NS:GetTrackedObjective(s) if s and s.phase then return self:GetPlannedObjective(s) end return oldObjective(self,s) end
function NS:IsStepComplete(s) return s and s.phase and self:IsPlannedStepComplete(s) or false end
function NS:AutoAdvanceQuestSteps() self:InvalidateQuestPlan(); self:GetQuestPlan() end
