local NS=ForeverPath
function NS:GetPlayerLevel() return UnitLevel("player") or 1 end
function NS:GetPlayerZone()
  local id=C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
  local info=id and C_Map.GetMapInfo(id); return info and info.name or (GetRealZoneText and GetRealZoneText()) or "Unbekannt"
end
function NS:ScanQuestLog() return self:RefreshQuestState() end
function NS:GetQuestState() return self.questState or self:RefreshQuestState() end
function NS:GetBestDungeon()
  local best,score; local level=self:GetPlayerLevel()
  for _,d in ipairs(self.dungeonDB or {}) do
    if d.min and d.max and level>=d.min and level<=d.max and d.kind~="raid" then
      local value=30-math.abs(level-(d.min+d.max)/2)
      if not score or value>score then best,score=d,value end
    end
  end
  return best,score
end
function NS:ScoreStep(s)
  local level=self:GetPlayerLevel()
  local c={xpPerMinute=0,travel=0,combat=0,risk=0,wait=0,class=0,dungeon=0,gear=0,chain=0,followup=0}
  local reasons={}; local score=s.priority or (30-math.abs((s.level or level)-level)*3)
  local point=self:GetBestWaypoint(s)
  local m=point and self.GetNavigationMeasurement and self:GetNavigationMeasurement(point)
  if m and m.fraction then c.travel=math.min(30,m.fraction*30) elseif m and not m.sameMap then c.travel=20; reasons[#reasons+1]="Reisezeit unbekannt" end
  local metric=self.db.questMetrics and self.db.questMetrics[s.questID]
  if metric and metric.seconds and metric.seconds>0 and metric.xp then c.xpPerMinute=metric.xp*60/metric.seconds; score=score+math.min(15,c.xpPerMinute/100); reasons[#reasons+1]="eigene Messwerte" end
  if s.record and s.record.classes and next(s.record.classes) then c.class=8 end
  if s.record and s.record.chainNext then c.followup=math.min(6,#s.record.chainNext*2) end
  local group=self.GetGroupState and self:GetGroupState()
  if s.record and s.record.isInstanceQuest then c.dungeon=group and 12 or 0; c.wait=group and 0 or 20 end
  if self.db.completed[s.id] then score=score-200 end
  return score-c.travel-c.wait+c.class+c.followup+c.dungeon,reasons,c
end
function NS:GetRecommendations(limit)
  local ranked={}
  for i,s in ipairs(self:GetSteps()) do
    if not self.db.completed[s.id] then local score,reasons,c=self:ScoreStep(s); ranked[#ranked+1]={step=s,index=i,score=score,reasons=reasons,components=c} end
  end
  table.sort(ranked,function(a,b) if a.score==b.score then return a.step.id<b.step.id end return a.score>b.score end)
  local out={}; for i=1,math.min(limit or 3,#ranked) do out[i]=ranked[i] end
  return out
end
function NS:GetSmartAdvice(s)
  local text="\n\n"..self:GetGearAdvice()
  if self.GetRewardAdvice then text=text.."\n"..self:GetRewardAdvice() end
  if self.GetGroupAdvice then text=text.."\n"..self:GetGroupAdvice() end
  local best=self:GetRecommendations(1)[1]
  if best then text=text..string.format("\nAlternative: %s · Priorität %.0f (heuristisch)",best.step.title,best.score) end
  if self.GetStopAdvice then text=text.."\n"..self:GetStopAdvice() end
  return text
end
function NS:PrintRecommendation()
  local best=self:GetRecommendations(1)[1]
  self:Print(best and (best.step.title.." · Priorität "..math.floor(best.score).." (heuristisch)") or "Keine passende Quest im Datenstand.")
end
