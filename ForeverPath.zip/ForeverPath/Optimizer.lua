local NS=ForeverPath
local function tr(text) return NS.L and NS:L(text) or text end
function NS:GetPlayerLevel() return UnitLevel("player") or 1 end
function NS:GetPlayerZone()
  local id=C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
  local info=id and C_Map.GetMapInfo(id); return info and info.name or (GetRealZoneText and GetRealZoneText()) or "Unbekannt"
end
function NS:ScanQuestLog() return self:RefreshQuestState() end
function NS:GetQuestState() return self.questState or self:RefreshQuestState() end
function NS:GetBestDungeon()
  local best,score; local level=self:GetPlayerLevel()
  for _,d in ipairs(self.dungeonDB or {}) do
    if d.min and d.max and level>=d.min and level<=d.max and d.kind~="raid" then
      local value=30-math.abs(level-(d.min+d.max)/2)
      if not score or value>score then best,score=d,value end
    end
  end
  return best,score
end
function NS:ScoreStep(s)
  local level=self:GetPlayerLevel()
  local c={xpPerMinute=0,travel=0,combat=0,risk=0,wait=0,class=0,dungeon=0,dungeonKillXPMultiplier=1,gear=0,chain=0,followup=0,gold=0}
  local reasons={}; local score=s.priority or (30-math.abs((s.level or level)-level)*3)
  local point=self:GetBestWaypoint(s)
  local m=point and self.GetNavigationMeasurement and self:GetNavigationMeasurement(point)
  if m and m.fraction then c.travel=math.min(30,m.fraction*30) elseif m and not m.sameMap then c.travel=20; reasons[#reasons+1]="Reisezeit unbekannt" end
  if point and C_Map and C_Map.GetBestMapForUnit and point.mapID~=C_Map.GetBestMapForUnit("player") then
    local kind=self.GetTravelKind and self:GetTravelKind(s) or "flight"
    c.travel=c.travel+(kind=="hearth" and 5 or kind=="portal" and 3 or kind=="boat" and 16 or 12)
    reasons[#reasons+1]="Gebietsreise: "..kind
  end
  local metric=self.db.questMetrics and self.db.questMetrics[s.questID]
  if metric and metric.seconds and metric.seconds>0 and metric.xp then c.xpPerMinute=metric.xp*60/metric.seconds; score=score+math.min(15,c.xpPerMinute/100); reasons[#reasons+1]="eigene Messwerte" end
  if s.record and s.record.classes and next(s.record.classes) then c.class=8 end
  if s.record and s.record.chainNext then c.followup=math.min(6,#s.record.chainNext*2) end
  if self.GetQuestGoldForStep and s.questID then
    local gold, source = self:GetQuestGoldForStep(s)
    c.gold = math.min(25, gold or 0)
    if c.gold > 0 then
      score = score + c.gold
      reasons[#reasons+1] = string.format("%s %.2fg", tr("Questgold"), gold)
    end
  end
  local group=self.GetGroupState and self:GetGroupState()
  if s.record and s.record.isInstanceQuest then
    local dungeonXPState = self.GetDungeonKillXPState and self:GetDungeonKillXPState(s) or {multiplier=1}
    local multiplier = dungeonXPState.multiplier or 1
    c.dungeonKillXPMultiplier = multiplier
    -- The November 8 hotfix affects dungeon enemy kill XP, not dungeon quest
    -- XP. Apply it only to the dungeon component of the route score.
    c.dungeon = group and 12 * multiplier or 0
    c.wait = group and 0 or 20
    if dungeonXPState.trivial then
      reasons[#reasons+1] = "Dungeon-Mob-XP 0x · trivial für die Gruppe"
    elseif multiplier ~= 1 then
      reasons[#reasons+1] = string.format("Dungeon-Mob-XP %.1fx", multiplier)
    end
  end
  if self.db.completed[s.id] then score=score-200 end
  return score-c.travel-c.wait+c.class+c.followup+c.dungeon,reasons,c
end
function NS:GetRecommendations(limit)
  local ranked={}
  for i,s in ipairs(self:GetSteps()) do
    if not self.db.completed[s.id] then local score,reasons,c=self:ScoreStep(s); ranked[#ranked+1]={step=s,index=i,score=score,reasons=reasons,components=c} end
  end
  table.sort(ranked,function(a,b) if a.score==b.score then return a.step.id<b.step.id end return a.score>b.score end)
  local out={}; for i=1,math.min(limit or 3,#ranked) do out[i]=ranked[i] end
  return out
end
function NS:GetRouteAlternatives(step,limit)
  local alternatives={}
  for _,entry in ipairs(self:GetRecommendations((limit or 3)+1)) do
    if not step or entry.step.id~=step.id then alternatives[#alternatives+1]=entry end
    if #alternatives>=(limit or 2) then break end
  end
  return alternatives
end
function NS:GetSmartAdvice(s)
  local text="\n\n"..self:GetGearAdvice()
  if self.GetRewardAdvice then text=text.."\n"..self:GetRewardAdvice() end
  if self.GetGroupAdvice then text=text.."\n"..self:GetGroupAdvice() end
  if self.GetTravelAdvice then text=text.."\n"..self:GetTravelAdvice(s) end
  local best=self:GetRecommendations(1)[1]
  if best and (not s or best.step.id~=s.id) then text=text..string.format("\nAlternative: %s · Priorität %.0f (heuristisch)",best.step.title,best.score) end
  if self.GetStopAdvice then text=text.."\n"..self:GetStopAdvice() end
  return text
end
function NS:PrintRecommendation()
  local best=self:GetRecommendations(1)[1]
  self:Print(best and (best.step.title.." · Priorität "..math.floor(best.score).." (heuristisch)") or "Keine passende Quest im Datenstand.")
end
