local NS = ForeverPath

function NS:GetPlayerLevel()
  return UnitLevel and (UnitLevel("player") or 1) or 1
end
function NS:GetPlayerZone()
  if C_Map and C_Map.GetBestMapForUnit and C_Map.GetMapInfo then
    local id = C_Map.GetBestMapForUnit("player"); local info = id and C_Map.GetMapInfo(id)
    return info and info.name or "Unbekannt"
  end
  return "Unbekannt"
end
function NS:ScanQuestLog()
  local result = { active=0, ids={}, titles={}, completed=0 }
  if not C_QuestLog or not C_QuestLog.GetNumQuestLogEntries or not C_QuestLog.GetInfo then return result end
  local count = C_QuestLog.GetNumQuestLogEntries() or 0
  for i = 1, count do
    local ok, info = pcall(C_QuestLog.GetInfo, i)
    if ok and info and not info.isHeader and info.questID and info.questID > 0 then
      result.active = result.active + 1; result.ids[info.questID] = true; result.titles[#result.titles+1] = info.title or ("Quest " .. info.questID)
    end
  end
  self.questState = result; return result
end
function NS:GetQuestState()
  return self.questState or self:ScanQuestLog()
end
function NS:GetGearBonus(level)
  if not GetAverageItemLevel then return 0 end
  local ok, avg = pcall(GetAverageItemLevel)
  if not ok or type(avg) ~= "number" then return 0 end
  return math.max(-5, math.min(8, (avg - level * 2.2) / 3))
end
function NS:GetGroupState()
  local inGroup = IsInGroup and IsInGroup() or false
  local role = UnitGroupRolesAssigned and UnitGroupRolesAssigned("player") or "NONE"
  return inGroup, role
end
function NS:GetExternalRouteForStep(s)
  local candidates
  if s and s.questIDs and self.externalRoutesByQuest then
    candidates = self.externalRoutesByQuest[s.questIDs[1]]
  end
  if not candidates and s and s.title and self.externalRoutesByTitle then
    candidates = self.externalRoutesByTitle[s.title]
  end
  if not candidates then return nil end
  local classToken = self.GetClassToken and self:GetClassToken() or "UNKNOWN"
  for _, route in ipairs(candidates) do
    if not route.class or route.class == classToken then return route end
  end
  return candidates[1]
end
function NS:GetBestDungeon()
  local level = self:GetPlayerLevel(); local inGroup, role = self:GetGroupState(); local best, bestScore = nil, -math.huge
  for _, dungeon in ipairs(self.dungeonDB or {}) do
    local center = (dungeon.min + dungeon.max) / 2
    local score = 20 - math.abs(level - center)
    if level >= dungeon.min and level <= dungeon.max then score = score + 18 else score = score - 20 end
    if dungeon.forever then score = score + 4 end
    if inGroup then score = score + 8 elseif role == "TANK" or role == "HEALER" then score = score + 3 end
    if score > bestScore then best, bestScore = dungeon, score end
  end
  return best, bestScore
end
function NS:ScoreStep(s)
  local level, zone, meta = self:GetPlayerLevel(), self:GetPlayerZone(), self.questDB and self.questDB[s.zone]
  local reasons = {}; local delta = (s.level or level) - level
  local xpPerMinute = 52 + (meta and meta.density or 0)
  if delta > 5 then xpPerMinute = xpPerMinute - delta * 8; reasons[#reasons+1] = "noch zu hoch" elseif delta >= 0 then xpPerMinute = xpPerMinute + 12 - delta * 2 elseif delta < -5 then xpPerMinute = xpPerMinute - 6 end
  local travelPenalty = (meta and meta.travel or 1) * 8 + (s.flightTime or 0) + (s.hearthstoneTime or 0)
  local riskPenalty = 4; local p = self:GetClassProfile()
  if p.speed == "S" or p.speed == "A" then riskPenalty = 2 elseif p.speed == "C" then riskPenalty = 7 end
  if delta > 3 then riskPenalty = riskPenalty + 5 end
  local waitPenalty = 0; local inGroup, groupRole = self:GetGroupState()
  if self.db.mode == "dungeon" or string.find(string.lower(s.title or ""), "dungeon", 1, true) then waitPenalty = inGroup and 0 or ((groupRole == "TANK" or groupRole == "HEALER") and 3 or 12) end
  local combatPenalty = s.combatTime or (p.speed == "C" and 8 or 4)
  local classBonus = ({S=12, A=9, B=5, C=1})[p.speed] or 0
  local dungeonQuestBonus = (self.db.mode == "dungeon" and 10 or 0)
  if string.find(string.lower(s.title or ""), "dungeon", 1, true) then dungeonQuestBonus = dungeonQuestBonus + 6 end
  local gearInfo = self.GetEquipmentSummary and self:GetEquipmentSummary() or nil
  local gearBonus = self:GetGearBonus(level)
  if gearInfo and gearInfo.state == "schwach" then reasons[#reasons+1] = "Ausrüstung verbessern" end
  local questChainBonus = s.chainBonus or (s.questIDs and 4 or 0)
  local followupBonus = s.followupBonus or 0
  local external = self:GetExternalRouteForStep(s)
  if external then
    if external.questID and external.questID > 0 then questChainBonus = questChainBonus + 3 end
    if external.objective and external.turnin then followupBonus = followupBonus + 2 end
    if external.class and external.class == self:GetClassToken() then classBonus = classBonus + 4 end
  end
  if s.zone and zone ~= "Unbekannt" and string.find(s.zone, zone, 1, true) then travelPenalty = math.max(0, travelPenalty - 10); reasons[#reasons+1] = "du bist bereits dort" end
  if self.db.completed[s.id] then xpPerMinute = xpPerMinute - 100; reasons[#reasons+1] = "bereits erledigt" end
  local score = xpPerMinute - travelPenalty - combatPenalty - riskPenalty - waitPenalty + classBonus + dungeonQuestBonus + gearBonus + questChainBonus + followupBonus
  return score, reasons, { xpPerMinute=xpPerMinute, travel=travelPenalty, combat=combatPenalty, risk=riskPenalty, wait=waitPenalty, class=classBonus, dungeon=dungeonQuestBonus, gear=gearBonus, chain=questChainBonus, followup=followupBonus, gearState=gearInfo and gearInfo.state or "unbekannt" }
end
function NS:GetRecommendations(limit)
  local steps = self:GetSteps(); local ranked = {}
  for i, s in ipairs(steps) do if not self.db.completed[s.id] then local score, reasons, components = self:ScoreStep(s); ranked[#ranked+1] = {step=s, index=i, score=score, reasons=reasons, components=components} end end
  table.sort(ranked, function(a,b) return a.score > b.score end); local out = {}
  for i = 1, math.min(limit or 3, #ranked) do out[#out+1] = ranked[i] end
  return out
end
function NS:GetSmartAdvice(step)
  self:ScanQuestLog(); local q = self:GetQuestState(); local ranked = self:GetRecommendations(1); local best = ranked[1]
  local advice = string.format("Live: %d aktive Quests · Zone: %s", q.active, self:GetPlayerZone())
  if best and best.step then
    local c = best.components
    advice = advice .. string.format("\nEmpfehlung: %s (Score %.0f)", best.step.title, best.score)
    advice = advice .. string.format("\nXP/min %.0f - Reise %.0f - Kampf %.0f - Risiko %.0f - Gruppe %.0f + Klasse %.0f + Dungeon %.0f + Gear %.0f + Kette %.0f + Folge %.0f", c.xpPerMinute, c.travel, c.combat, c.risk, c.wait, c.class, c.dungeon, c.gear, c.chain, c.followup)
  end
  if q.active >= 20 then advice = advice .. "\nQuestlog fast voll: zuerst Abgaben bündeln." end
  local recovery = self.GetRouteRecovery and self:GetRouteRecovery()
  if recovery then advice = advice .. string.format("\nRoute-Recovery: %s ist in deiner aktuellen Zone verfügbar.", recovery.step.title) end
  if self.GetGearAdvice then advice = advice .. "\n" .. self:GetGearAdvice() end
  if self.GetRewardAdvice then local reward = self:GetRewardAdvice(); if reward then advice = advice .. "\n" .. reward end end
  if self.db.mode == "dungeon" and self.GetBestDungeon then
    local dungeon, dungeonScore = self:GetBestDungeon(); if dungeon then advice = advice .. string.format("\nDungeon-Fenster: %s (%.0f)", dungeon.name, dungeonScore) end
  end
  return "\n\n" .. advice
end
function NS:PrintRecommendation()
  self:ScanQuestLog(); local best = self:GetRecommendations(1)[1]
  if best then local c = best.components; self:Print(string.format("Empfehlung: %s | Score %.0f | XP/min %.0f - Reise %.0f - Kampf %.0f - Risiko %.0f - Wartezeit %.0f + Klasse %.0f + Dungeon %.0f + Gear %.0f + Kette %.0f + Folge %.0f", best.step.title, best.score, c.xpPerMinute, c.travel, c.combat, c.risk, c.wait, c.class, c.dungeon, c.gear, c.chain, c.followup)) else self:Print("Keine offene Empfehlung.") end
end
