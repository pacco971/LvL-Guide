local NS=ForeverPath

local function sameMap(a,b) return a and b and a==b end
local function label(kind)
  return ({walk="Zu Fuß / Reittier",flight="Flugpunkt",hearth="Hearthstone",boat="Boot / Zeppelinstrecke",portal="Klassenreise"})[kind] or "Reise"
end

function NS:GetTravelOptions(step)
  local target=self.GetBestWaypoint and self:GetBestWaypoint(step)
  if not target or not target.mapID then return {{kind="walk",name="Zielkoordinaten fehlen",score=-20,known=false}} end
  local current=C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
  if sameMap(current,target.mapID) then return {{kind="walk",name=label("walk"),score=55,known=true}} end
  local options={{kind="flight",name=label("flight"),score=45,known=false},{kind="boat",name=label("boat"),score=35,known=false}}
  if self.db and self.db.bindLocation then options[#options+1]={kind="hearth",name=label("hearth").." nach "..tostring(self.db.bindLocation),score=30,known=true} end
  local class=self.GetClassToken and self:GetClassToken()
  if class=="MAGE" then options[#options+1]={kind="portal",name=label("portal").." / Teleport",score=60,known=false} end
  table.sort(options,function(a,b) return a.score>b.score end); return options
end

function NS:GetTravelAdvice(step)
  local options=self:GetTravelOptions(step); local best=options[1]
  if not best then return "Reiseweg unbekannt" end
  local suffix=#options>1 and " · Alternative: "..options[2].name or ""
  if best.known==false and best.kind~="walk" then
    return "Reise: "..best.name.." (Flug-/Bootszeit wird im Client gemessen)"..suffix
  end
  return "Reise: "..best.name..suffix
end

function NS:GetTravelKind(step)
  local options=self:GetTravelOptions(step); return options[1] and options[1].kind or "walk"
end
