local NS = ForeverPath

local function tr(text) return NS.L and NS:L(text) or text end
local function lower(value) return value and string.lower(tostring(value)) or "" end
local function sameZone(a, b)
  a, b = lower(a), lower(b)
  return a ~= "" and b ~= "" and (a == b or string.find(a, b, 1, true) or string.find(b, a, 1, true))
end

local function travelLabel(kind)
  return ({
    walk=tr("Zu Fuß / Reittier"), flight=tr("Flugpunkt"), hearth=tr("Hearthstone"),
    boat=tr("Schiff / Zeppelin"), portal=tr("Klassenreise"), zone=tr("Zonenwechsel")
  })[kind] or tr("Reise")
end

local function numeric(value)
  if type(value) ~= "number" then return nil end
  if issecretvalue then
    local ok, secret = pcall(issecretvalue, value)
    if ok and secret then return nil end
  end
  return value
end

local function currentMap()
  if not C_Map or not C_Map.GetBestMapForUnit then return nil end
  local ok, map = pcall(C_Map.GetBestMapForUnit, "player")
  return ok and numeric(map) or nil
end

local function bindLocation()
  if not GetBindLocation then return nil end
  local ok, location = pcall(GetBindLocation)
  return ok and type(location) == "string" and location ~= "" and location or nil
end

-- Build a transparent travel plan instead of pretending that every flight or
-- ship route is known. Transport nodes become confirmed only after the client
-- exposes them; until then walking/mounting remains the safe fallback.
function NS:GetTravelPlan(step)
  local target = step and self.GetBestWaypoint and self:GetBestWaypoint(step) or nil
  local playerMap = currentMap()
  local playerZone = GetRealZoneText and GetRealZoneText() or self.GetPlayerZone and self:GetPlayerZone() or ""
  local targetZone = step and (step.zone or step.record and step.record.zone) or ""
  local options = {}
  local same = target and playerMap and target.mapID == playerMap
  if same or sameZone(playerZone, targetZone) then
    options[#options + 1] = {kind="walk", name=travelLabel("walk"), score=100, known=true, detail=tr("Direkter Weg zum aktiven Questziel")}
  else
    options[#options + 1] = {kind="flight", name=travelLabel("flight"), score=84, known=false, detail=tr("Nächsten bekannten Flugpunkt prüfen")}
    options[#options + 1] = {kind="boat", name=travelLabel("boat"), score=72, known=false, detail=tr("Schiff- oder Zeppelinstrecke prüfen")}
    local bind = bindLocation() or self.db and self.db.bindLocation
    if bind then options[#options + 1] = {kind="hearth", name=travelLabel("hearth") .. " · " .. bind, score=66, known=true, detail=tr("Bindepunkt des Charakters") } end
    if self:GetClassToken() == "MAGE" then options[#options + 1] = {kind="portal", name=travelLabel("portal"), score=92, known=false, detail=tr("Magier-Teleport nur bei passendem Zauber") } end
    options[#options + 1] = {kind="zone", name=travelLabel("zone"), score=42, known=true, detail=tr("Zielzone wechseln und dort weiter navigieren")}
  end
  table.sort(options, function(a, b) return (a.score or 0) > (b.score or 0) end)
  local best = options[1]
  local reason
  if best and best.kind == "walk" then
    reason = tr("Gleiche Zone/Karte: direkte Navigation zum aktiven Questziel.")
  elseif best then
    reason = tr("Gebietswechsel erkannt: Transportoptionen werden nach Nutzen sortiert; unbekannte Strecken werden im Client bestätigt.")
  else
    reason = tr("Keine bestätigte Transportoption – sichere Fallback-Navigation aktiv.")
  end
  return {
    options=options, best=best, target=target, targetName=target and (target.hint or target.name or target.title) or nil,
    sameMap=same, reason=reason,
    warning=tr("Keine automatische Flug-, Schiffs- oder Hearthstone-Aktion wird ausgelöst. Der Reiseweg bleibt nachvollziehbar und manuell kontrollierbar.")
  }
end

function NS:GetTravelOptions(step)
  local plan = self:GetTravelPlan(step)
  return plan.options or {}
end

function NS:GetTravelAdvice(step)
  local plan = self:GetTravelPlan(step)
  local best = plan.best
  if not best then return tr("Reiseweg unbekannt") end
  local alternative = plan.options and plan.options[2]
  local suffix = alternative and (" · " .. tr("Alternative: ") .. alternative.name) or ""
  return tr("Reise: ") .. best.name .. suffix
end

function NS:GetTravelKind(step)
  local plan = self:GetTravelPlan(step)
  return plan.best and plan.best.kind or "walk"
end
