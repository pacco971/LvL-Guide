local ADDON, NS = ...
NS = NS or {}
ForeverPath = NS
NS.version = "0.4.0"
NS.modes = { speed = "Speedrun", dungeon = "Dungeon", discovery = "Discovery", legacy = "Legacy" }

local defaults = { mode = "speed", route = "alliance", step = 1, completed = {} }
local function copyDefaults(target)
  for k, v in pairs(defaults) do
    if target[k] == nil then target[k] = type(v) == "table" and {} or v end
  end
end
function NS:Print(message) DEFAULT_CHAT_FRAME:AddMessage("|cffd7a84bForeverPath|r: " .. tostring(message)) end
function NS:GetSteps() local route = self.routes[self.db.route] or self.routes.alliance; return route[self.db.mode] or route.speed or {} end
function NS:GetCurrentStep() return self:GetSteps()[self.db.step] end
function NS:GetClassToken()
  if UnitClass then local _, token = UnitClass("player"); return token or "UNKNOWN" end
  return "UNKNOWN"
end
function NS:GetClassProfile()
  return (self.classProfiles and self.classProfiles[self:GetClassToken()]) or self.classProfiles and self.classProfiles.DEFAULT or { name="Unbekannt", spec="flexibel", note="Spiele nach Ausrüstung und Gruppensituation." }
end
function NS:GetCurrentBody(step)
  local profile = self:GetClassProfile()
  local extra = profile and profile.note and ("\n\nKlassenhinweis (" .. profile.name .. "): " .. profile.note) or ""
  local questText = self.GetQuestTrackerText and self:GetQuestTrackerText(step) or (step.body or "")
  local advice = self.GetSmartAdvice and self:GetSmartAdvice(step) or ""
  return questText .. extra .. advice
end
function NS:SetMode(mode)
  if not self.modes[mode] then return false end
  self.db.mode, self.db.step = mode, 1; self:Refresh(); self:Print("Modus: " .. self.modes[mode]); return true
end
function NS:CompleteCurrent(silent)
  local step = self:GetCurrentStep(); if not step then return end
  self.db.completed[step.id] = true; if self.db.step < #self:GetSteps() then self.db.step = self.db.step + 1 end
  if self.RecordStepEvent then self:RecordStepEvent("complete", step) end
  if self.RecordStepEvent then self:RecordStepEvent("start", self:GetCurrentStep()) end
  self:Refresh(); if not silent then self:Print("Erledigt: " .. step.title) end
end
function NS:ResetProgress() self.db.step, self.db.completed = 1, {}; self:Refresh(); self:Print("Fortschritt zurückgesetzt.") end
function NS:SetWaypoint(step)
  if not step or not step.mapID or not step.x or not step.y or not C_Map or not C_Map.SetUserWaypoint or not UiMapPoint then return false end
  C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(step.mapID, step.x, step.y))
  if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then C_SuperTrack.SetSuperTrackedUserWaypoint(true) end
  return true
end
function NS:Refresh()
  if self.frame and self.frame.Refresh then self.frame:Refresh() end
  if self.RefreshTracker then self:RefreshTracker() end
end
function NS:AutoScan(showChat)
  if not self.db or not self.ScanQuestLog or not self.GetRecommendations then return end
  self:ScanQuestLog(); self.lastRecommendations = self:GetRecommendations(3); self:Refresh()
  if showChat and self.PrintRecommendation then self:PrintRecommendation() end
end
function NS:StartAutoScan()
  if self.autoScanTicker or not C_Timer or not C_Timer.NewTicker then return end
  self.autoScanTicker = C_Timer.NewTicker(300, function() if NS.db then NS:AutoScan(true) end end)
end

local function onEvent(_, event, ...)
  if event == "ADDON_LOADED" and ... == ADDON then
    ForeverPathDB = ForeverPathDB or {}; copyDefaults(ForeverPathDB); NS.db = ForeverPathDB; if NS.InitLearning then NS:InitLearning() end; NS:CreateMinimapButton(); NS:CreateTracker(); NS:Refresh()
    if C_Timer and C_Timer.After then C_Timer.After(2, function() NS:AutoScan(true); NS:StartAutoScan() end) end
  elseif NS.db and NS.OnGameEvent then
    NS:OnGameEvent(event, ...)
  end
  if NS.db and (event == "QUEST_LOG_UPDATE" or event == "QUEST_ACCEPTED" or event == "QUEST_TURNED_IN" or event == "QUEST_REMOVED" or event == "ZONE_CHANGED_NEW_AREA" or event == "PLAYER_LEVEL_CHANGED" or event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_DEAD" or event == "UNIT_XP") then
    NS.questState = nil; NS:Refresh()
  end
end
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
for _, event in ipairs({"QUEST_LOG_UPDATE", "QUEST_ACCEPTED", "QUEST_TURNED_IN", "QUEST_REMOVED", "ZONE_CHANGED_NEW_AREA", "PLAYER_LEVEL_CHANGED", "PLAYER_ENTERING_WORLD", "PLAYER_DEAD", "UNIT_XP"}) do pcall(eventFrame.RegisterEvent, eventFrame, event) end
eventFrame:SetScript("OnEvent", onEvent)

SLASH_FOREVERPATH1 = "/fp"
SlashCmdList.FOREVERPATH = function(message)
  local command, argument = message:match("^(%S*)%s*(.-)%s*$"); command = string.lower(command or "")
  if command == "next" or command == "weiter" then NS:CompleteCurrent()
  elseif command == "prev" or command == "zurueck" then NS.db.step = math.max(1, NS.db.step - 1); NS:Refresh()
  elseif command == "mode" or command == "modus" then NS:SetMode(argument)
  elseif command == "route" or command == "fraktion" then if NS.routes[argument] then NS.db.route, NS.db.step = argument, 1; NS:Refresh() end
  elseif command == "scan" or command == "empfehlung" then NS:PrintRecommendation()
  elseif command == "data" then NS:Print(NS.GetLearningSummary and NS:GetLearningSummary() or "Noch keine Lernmetriken verfügbar.")
  elseif command == "reset" then NS:ResetProgress()
  elseif command == "help" then NS:Print("/fp – Fenster | /fp next | /fp prev | /fp scan | /fp data | /fp mode speed|dungeon|discovery|legacy | /fp route alliance|horde | /fp reset")
  else NS:Toggle() end
end
