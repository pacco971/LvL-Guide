local ADDON, NS = ...
ForeverPath = NS
NS.version = "0.9.2"
NS.modes = {speed="Solo / Quests", dungeon="Dungeon", discovery="Entdeckung", legacy="Legacy"}
function NS:Print(message) DEFAULT_CHAT_FRAME:AddMessage("|cffd7a84bForeverPath|r: " .. tostring(message)) end
function NS:EnsureSettings()
  self.db=self.db or {}; local d=self.db
  d.mode=d.mode or "speed"; d.step=d.step or 1
  d.route=d.route or (UnitFactionGroup and UnitFactionGroup("player")=="Horde" and "horde" or "alliance")
  d.completed=d.completed or {}; d.turnedIn=d.turnedIn or {}; d.skippedQuests=d.skippedQuests or {}
  d.navigation=d.navigation or {}; d.ui=d.ui or {}; d.ui.positions=d.ui.positions or {}; d.layouts=d.layouts or {}
  local defaults={trackerScale=1,navigationScale=1,opacity=0.96,fontScale=1,trackerCollapsed=false,lockFrames=false,minimal=false,streamer=false,gearRole="AUTO",theme="gold",layout="large",trackerShown=true}
  for k,v in pairs(defaults) do if d.ui[k]==nil then d.ui[k]=v end end
  if d.questMode==nil then d.questMode=true end
  if d.autoSolo==nil then d.autoSolo=true end
end
function NS:GetSteps()
  if self.db.questMode and self.GetQuestPlan then return self:GetQuestPlan() end
  local route=self.routes[self.db.route] or self.routes.alliance
  return route[self.db.mode] or route.speed or {}
end
function NS:GetCurrentStep() return self:GetSteps()[self.db.step or 1] end
function NS:GetClassToken() local _,token=UnitClass("player"); return token or "UNKNOWN" end
function NS:GetClassProfile() return self.classProfiles[self:GetClassToken()] or self.classProfiles.DEFAULT end
function NS:GetCurrentBody(step)
  if not step then return "Keine passenden Quests. Datenstatus und Filter prüfen." end
  return self:GetQuestTrackerText(step) .. (self.GetSmartAdvice and self:GetSmartAdvice(step) or "")
end
function NS:SelectStep(index)
  local s=self:GetSteps()[index]; if not s then return end
  self.db.step=index; self.db.selectedStepID=s.id; self:Refresh()
end
function NS:SetMode(mode)
  if not self.modes[mode] then return false end
  self.db.mode=mode; self.db.step=1; self.db.selectedStepID=nil
  if self.InvalidateQuestPlan then self:InvalidateQuestPlan() end
  self:Refresh(); return true
end
function NS:CompleteCurrent(silent)
  local s=self:GetCurrentStep(); if not s then return end
  if s.phase then
    if not self:IsPlannedStepComplete(s) then
      if not silent then self:Print("Questschritte werden durch Spielereignisse abgehakt. Zum Auslassen: Überspringen.") end
      return false
    end
    self.db.selectedStepID=nil; self:InvalidateQuestPlan()
  else self.db.completed[s.id]=true; self.db.step=self.db.step+1 end
  if self.RecordStepEvent then self:RecordStepEvent("complete",s) end
  self:Refresh(); return true
end
function NS:SkipCurrent()
  local s=self:GetCurrentStep(); if not s then return end
  if s.questID then self.db.skippedQuests[s.questID]=true; self:InvalidateQuestPlan()
  else self.db.step=self.db.step+1 end
  self.db.selectedStepID=nil; self:Refresh()
end
function NS:NormalizeProgress()
  if self.db.questMode then return end
  local steps=self:GetSteps()
  while steps[self.db.step] and self.db.completed[steps[self.db.step].id] do self.db.step=self.db.step+1 end
end
function NS:ResetProgress()
  self.db.step,self.db.selectedStepID,self.db.completed,self.db.skippedQuests=1,nil,{},{}
  if self.InvalidateQuestPlan then self:InvalidateQuestPlan() end
  self:Refresh()
end
function NS:SaveFramePosition(frame,key)
  local x,y=frame:GetCenter(); if not x or not y then return end
  local ratio=frame:GetEffectiveScale()/UIParent:GetEffectiveScale()
  self.db.ui.positions[key]={point="CENTER",relativePoint="BOTTOMLEFT",x=x*ratio/frame:GetScale(),y=y*ratio/frame:GetScale()}
end
function NS:RestoreFramePosition(frame,key,point,parent,x,y)
  local saved=self.db.ui.positions[key]; frame:ClearAllPoints(); frame:SetClampedToScreen(true)
  if saved then frame:SetPoint(saved.point,UIParent,saved.relativePoint,saved.x,saved.y)
  else frame:SetPoint(point or "CENTER",parent or UIParent,point or "CENTER",x or 0,y or 0) end
end
function NS:SetFrameLock(value)
  if value==nil then value=not self.db.ui.lockFrames end
  self.db.ui.lockFrames=value; self:Refresh()
end
function NS:SetWaypoint(point)
  if not point or not point.mapID or not point.x or not point.y or not C_Map or not C_Map.SetUserWaypoint or not UiMapPoint then return false end
  C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(point.mapID,point.x/100,point.y/100))
  if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then C_SuperTrack.SetSuperTrackedUserWaypoint(true) end
  return true
end
function NS:Refresh()
  if not self.db or self.refreshing then return end
  self.refreshing=true; self:EnsureSettings(); self:NormalizeProgress()
  if self.RefreshUI then self:RefreshUI() end
  if self.RefreshTracker then self:RefreshTracker() end
  if self.RefreshNavigation then self:RefreshNavigation() end
  if self.RefreshWorldMapOverlay then self:RefreshWorldMapOverlay() end
  self.refreshing=false
end
function NS:AutoScan(showChat)
  self:RefreshQuestState(); if self.InvalidateQuestPlan then self:InvalidateQuestPlan() end
  self:Refresh(); if showChat then self:PrintRecommendation() end
end
function NS:StartAutoScan()
  if self.autoScanTicker or not C_Timer or not C_Timer.NewTicker then return end
  self.autoScanTicker=C_Timer.NewTicker(300,function() NS:AutoScan(false) end)
end
local function initialize()
  ForeverPathDB=ForeverPathDB or {}; ForeverPathDB.characters=ForeverPathDB.characters or {}
  local key=UnitGUID and UnitGUID("player") or (UnitName("player") .. "-" .. GetRealmName())
  ForeverPathDB.characters[key]=ForeverPathDB.characters[key] or {}
  NS.db=ForeverPathDB.characters[key]; NS:EnsureSettings()
  NS:InitSession(); NS:InitLearning(); NS:RefreshQuestState()
  NS:CreateMinimapButton(); NS:CreateTracker(); NS:CreateNavigation(); NS:StartAutoScan(); NS:Refresh()
  if C_Timer and C_Timer.After then C_Timer.After(1,function() NS:CreateWorldMapOverlay(); if not NS.db.onboarded then NS:ShowOnboarding() end end) end
end
local events={"PLAYER_LOGIN","ADDON_LOADED","PLAYER_ENTERING_WORLD","QUEST_LOG_UPDATE","QUEST_ACCEPTED","QUEST_TURNED_IN","QUEST_REMOVED","QUEST_COMPLETE","QUEST_FINISHED","QUEST_DETAIL","PLAYER_LEVEL_UP","PLAYER_LEVEL_CHANGED","PLAYER_XP_UPDATE","PLAYER_DEAD","PLAYER_ALIVE","PLAYER_UNGHOST","PLAYER_LOGOUT","ZONE_CHANGED_NEW_AREA","UNIT_INVENTORY_CHANGED","GET_ITEM_INFO_RECEIVED","ITEM_DATA_LOAD_RESULT","GROUP_ROSTER_UPDATE","PLAYER_ROLES_ASSIGNED","LFG_UPDATE","LFG_PROPOSAL_SHOW","LFG_PROPOSAL_SUCCEEDED","LFG_PROPOSAL_FAILED","TRAINER_SHOW","TRAINER_UPDATE","TRAINER_CLOSED","SKILL_LINES_CHANGED","SPELLS_CHANGED","MERCHANT_SHOW","GOSSIP_SHOW","TAXIMAP_OPENED","HEARTHSTONE_BOUND","PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED"}
local f=CreateFrame("Frame"); NS.eventFrame=f; NS.registeredEvents={}
for _,event in ipairs(events) do NS.registeredEvents[event]=pcall(f.RegisterEvent,f,event) end
f:SetScript("OnEvent",function(_,event,...)
  if event=="PLAYER_LOGIN" then initialize(); return end
  if not NS.db then return end
  if NS.db.debug then
    NS.debugEvents=NS.debugEvents or {}; table.insert(NS.debugEvents,event)
    if #NS.debugEvents>30 then table.remove(NS.debugEvents,1) end
  end
  if NS.OnGameEvent then NS:OnGameEvent(event,...) end
  if event=="ADDON_LOADED" or event=="PLAYER_ENTERING_WORLD" then NS:CreateWorldMapOverlay() end
  if not NS.refreshQueued and C_Timer and C_Timer.After then
    NS.refreshQueued=true; C_Timer.After(0.12,function() NS.refreshQueued=false; NS:Refresh() end)
  end
end)
