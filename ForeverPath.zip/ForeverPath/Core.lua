local ADDON, NS = ...
NS = NS or {}
ForeverPath = NS
NS.version = "0.8.0"
NS.modes = { speed = "Speedrun", dungeon = "Dungeon", discovery = "Discovery", legacy = "Legacy" }

local defaults = { mode = "speed", route = "alliance", step = 1, completed = {}, navigation = {}, ui = { trackerScale=1, navigationScale=1, opacity=0.96, fontScale=1, trackerCollapsed=false, lockFrames=false, minimal=false, gearRole="AUTO", positions={} } }
local function copyDefaults(target)
  for k, v in pairs(defaults) do
    if target[k] == nil then target[k] = type(v) == "table" and {} or v end
  end
end
function NS:Print(message) DEFAULT_CHAT_FRAME:AddMessage("|cffd7a84bForeverPath|r: " .. tostring(message)) end
function NS:EnsureSettings()
  self.db = self.db or {}
  self.db.navigation = self.db.navigation or {}
  self.db.ui = self.db.ui or {}
  local ui = self.db.ui
  if ui.trackerScale == nil then ui.trackerScale = 1 end
  if ui.navigationScale == nil then ui.navigationScale = 1 end
  if ui.opacity == nil then ui.opacity = 0.96 end
  if ui.fontScale == nil then ui.fontScale = 1 end
  if ui.trackerCollapsed == nil then ui.trackerCollapsed = false end
  if ui.lockFrames == nil then ui.lockFrames = false end
  if ui.minimal == nil then ui.minimal = false end
  if ui.gearRole == nil then ui.gearRole = "AUTO" end
  ui.positions = ui.positions or {}
end
function NS:GetSteps() local route = self.routes[self.db.route] or self.routes.alliance; return route[self.db.mode] or route.speed or {} end
function NS:GetCurrentStep() return self:GetSteps()[self.db.step] end
function NS:GetClassToken()
  if UnitClass then local _, token = UnitClass("player"); return token or "UNKNOWN" end
  return "UNKNOWN"
end
function NS:GetClassProfile()
  return (self.classProfiles and self.classProfiles[self:GetClassToken()]) or self.classProfiles and self.classProfiles.DEFAULT or { name="Unbekannt", spec="flexibel", note="Spiele nach Ausrüstung und Gruppensituation." }
end
function NS:GetCurrentBody(step)
  local profile = self:GetClassProfile()
  local extra = profile and profile.note and ("\n\nKlassenhinweis (" .. profile.name .. "): " .. profile.note) or ""
  local questText = self.GetQuestTrackerText and self:GetQuestTrackerText(step) or (step.body or "")
  local advice = self.GetSmartAdvice and self:GetSmartAdvice(step) or ""
  return questText .. extra .. advice
end
function NS:SetMode(mode)
  if not self.modes[mode] then return false end
  self.db.mode, self.db.step = mode, 1; self:Refresh(); self:Print("Modus: " .. self.modes[mode]); return true
end
function NS:CompleteCurrent(silent)
  local step = self:GetCurrentStep(); if not step then return end
  self.db.completed[step.id] = true; if self.db.step < #self:GetSteps() then self.db.step = self.db.step + 1 end
  if self.RecordStepEvent then self:RecordStepEvent("complete", step) end
  if self.RecordStepEvent then self:RecordStepEvent("start", self:GetCurrentStep()) end
  self:Refresh(); if not silent then self:Print("Erledigt: " .. step.title) end
end
function NS:NormalizeProgress()
  if not self.db or self._normalizing then return false end
  self._normalizing = true; local changed = false; local steps = self:GetSteps()
  while self.db.step <= #steps and steps[self.db.step] and self.db.completed[steps[self.db.step].id] do self.db.step = self.db.step + 1; changed = true end
  self._normalizing = false; return changed
end
function NS:ResetProgress() self.db.step, self.db.completed = 1, {}; self:Refresh(); self:Print("Fortschritt zurückgesetzt.") end
function NS:SaveFramePosition(frame, key)
  if not frame or not self.db then return end
  self:EnsureSettings(); local point, _, relativePoint, x, y = frame:GetPoint(1)
  self.db.ui.positions[key] = { point=point or "CENTER", relativePoint=relativePoint or "CENTER", x=x or 0, y=y or 0 }
end
function NS:RestoreFramePosition(frame, key, defaultPoint, defaultRelative, defaultX, defaultY)
  if not frame or not self.db then return end
  self:EnsureSettings(); local saved = self.db.ui.positions[key]; frame:ClearAllPoints()
  if saved then frame:SetPoint(saved.point, UIParent, saved.relativePoint, saved.x, saved.y) else frame:SetPoint(defaultPoint, defaultRelative or UIParent, defaultX or 0, defaultY or 0) end
end
function NS:SetFrameLock(locked)
  self:EnsureSettings(); self.db.ui.lockFrames = locked == nil and not self.db.ui.lockFrames or locked
  if self.Print then self:Print(self.db.ui.lockFrames and "UI-Frames gesperrt." or "UI-Frames entsperrt.") end
  if self.Refresh then self:Refresh() end
end
function NS:SetWaypoint(step)
  if not step or not step.mapID or not step.x or not step.y or not C_Map or not C_Map.SetUserWaypoint or not UiMapPoint then return false end
  C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(step.mapID, step.x, step.y))
  if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then C_SuperTrack.SetSuperTrackedUserWaypoint(true) end
  return true
end
function NS:Refresh()
  self:EnsureSettings(); self:NormalizeProgress()
  if self.frame and self.frame.Refresh then self.frame:Refresh() end
  if self.RefreshTracker then self:RefreshTracker() end
  if self.RefreshNavigation then self:RefreshNavigation() end
  if self.RefreshWorldMapOverlay then self:RefreshWorldMapOverlay() end
end
function NS:AutoScan(showChat)
  if not self.db or not self.ScanQuestLog or not self.GetRecommendations then return end
  self:ScanQuestLog(); self.lastRecommendations = self:GetRecommendations(3); self:Refresh()
  if showChat and self.PrintRecommendation then self:PrintRecommendation() end
end
function NS:StartAutoScan()
  if self.autoScanTicker or not C_Timer or not C_Timer.NewTicker then return end
  self.autoScanTicker = C_Timer.NewTicker(300, function() if NS.db then NS:AutoScan(true) end end)
end

local function onEvent(_, event, ...)
  if event == "ADDON_LOADED" and ... == ADDON then
    ForeverPathDB = ForeverPathDB or {}; copyDefaults(ForeverPathDB); NS.db = ForeverPathDB; NS:EnsureSettings(); if NS.InitSession then NS:InitSession() end; if NS.InitLearning then NS:InitLearning() end; NS:CreateMinimapButton(); NS:CreateTracker(); NS:CreateNavigation(); if C_Timer and C_Timer.After then C_Timer.After(1, function() if NS.CreateWorldMapOverlay then NS:CreateWorldMapOverlay() end end) end; NS:Refresh()
    if C_Timer and C_Timer.After then C_Timer.After(2, function() NS:AutoScan(true); NS:StartAutoScan() end) end
  elseif NS.db and NS.OnGameEvent then
    NS:OnGameEvent(event, ...)
  end
  if NS.db and (event == "QUEST_LOG_UPDATE" or event == "QUEST_ACCEPTED" or event == "QUEST_TURNED_IN" or event == "QUEST_REMOVED" or event == "ZONE_CHANGED_NEW_AREA" or event == "PLAYER_LEVEL_CHANGED" or event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_DEAD" or event == "UNIT_XP" or event == "PLAYER_XP_UPDATE" or event == "UNIT_INVENTORY_CHANGED") then
    NS.questState = nil; NS:Refresh()
  end
end
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
for _, event in ipairs({"QUEST_LOG_UPDATE", "QUEST_ACCEPTED", "QUEST_TURNED_IN", "QUEST_REMOVED", "ZONE_CHANGED_NEW_AREA", "PLAYER_LEVEL_CHANGED", "PLAYER_ENTERING_WORLD", "PLAYER_DEAD", "UNIT_XP", "PLAYER_XP_UPDATE", "UNIT_INVENTORY_CHANGED"}) do pcall(eventFrame.RegisterEvent, eventFrame, event) end
eventFrame:SetScript("OnEvent", onEvent)

