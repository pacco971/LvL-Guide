local ADDON, NS = ...
ForeverPath = NS
NS.version = "0.9.38-beta"
NS.modes = {speed="Solo / Quests", dungeon="Dungeon", discovery="Entdeckung", legacy="Legacy"}
function NS:Print(message) DEFAULT_CHAT_FRAME:AddMessage("|cffd7a84bForeverPath|r: " .. tostring(message)) end
function NS:EnsureSettings()
  self.db=self.db or {}; local d=self.db
  d.mode=d.mode or "speed"; d.step=d.step or 1
  d.route=d.route or (UnitFactionGroup and UnitFactionGroup("player")=="Horde" and "horde" or "alliance")
  d.completed=d.completed or {}; d.turnedIn=d.turnedIn or {}; d.skippedQuests=d.skippedQuests or {}
  d.navigation=d.navigation or {}; d.navigation.mobPriority = d.navigation.mobPriority ~= false; d.ui=d.ui or {}; d.ui.positions=d.ui.positions or {}; d.layouts=d.layouts or {}
  local defaults={trackerScale=1,navigationScale=1,arrowScale=1,minimapScale=1,language="de",arrowColor=1,arrowStyle=1,opacity=0.96,fontScale=1,trackerCollapsed=false,guideList=true,lockFrames=false,minimal=false,streamer=false,gearRole="AUTO",theme="gold",layout="large",trackerShown=true,xpProjection=true,xpProjectionLocked=false,xpBarWidth=560,xpBarHeight=64,xpBarScale=1,layerHints=true,autoQuestActions=true,showAllQuestLog=true,questMarkers=true,questMarkerItems=true,questMarkerObjectives=true,questMarkerTurnins=true,questMarkerLabels=false,questMarkerRadius=0.22,questMarkerLimit=6}
  for k,v in pairs(defaults) do if d.ui[k]==nil then d.ui[k]=v end end
  if d.ui.xpHUDVersion ~= "0.9.30" then
    if d.ui.xpBarWidth == 420 then d.ui.xpBarWidth=560 end
    if d.ui.xpBarHeight == 28 or d.ui.xpBarHeight == 58 then d.ui.xpBarHeight=64 end
    d.ui.xpHUDVersion="0.9.30"
  end
  -- One-time migration for the visible navigation HUD. Older builds could
  -- save it hidden or outside the screen after a scale change.
  if d.ui.navigationHUDVersion ~= self.version then
    d.ui.positions.navigation=nil
    d.ui.positions.navigationArrow=nil
    d.navigation.point=nil; d.navigation.relativePoint=nil; d.navigation.x=nil; d.navigation.y=nil
    d.navigation.show=true
    d.ui.navigationHUDVersion=self.version
  end
  if d.questMode==nil then d.questMode=true end
  if d.autoSolo==nil then d.autoSolo=true end
  if d.routeStrategy==nil then d.routeStrategy="balanced" end
end
function NS:GetSteps()
  if self.db.questMode and self.GetQuestPlan then return self:GetQuestPlan() end
  local route=self.routes[self.db.route] or self.routes.alliance
  return route[self.db.mode] or route.speed or {}
end
function NS:GetCurrentStep() return self:GetSteps()[self.db.step or 1] end
function NS:GetClassToken() local _,token=UnitClass("player"); return token or "UNKNOWN" end
function NS:GetClassProfile()
  local profiles=self.classProfiles or {}
  return profiles[self:GetClassToken()] or profiles.DEFAULT or {name="Unbekannt",spec="flexibel",speed="?",role="flexibel",note="Keine Klassenprofildaten geladen."}
end
function NS:GetCurrentBody(step)
  if not step then return "Keine passenden Quests. Datenstatus und Filter prüfen." end
  return self:GetQuestTrackerText(step) .. (self.GetSmartAdvice and self:GetSmartAdvice(step) or "")
end
function NS:SelectStep(index)
  local s=self:GetSteps()[index]; if not s then return end
  self.db.step=index; self.db.selectedStepID=s.id; self:Refresh()
end
function NS:SetFocusQuest(questID)
  self:EnsureSettings()
  questID=tonumber(questID)
  self.db.focusQuestID=questID
  if self.InvalidateQuestPlan then self:InvalidateQuestPlan() end
  self:Refresh()
  if questID then self:Print("Questfokus gesetzt: "..tostring(questID)) end
end
function NS:ClearFocusQuest()
  self:EnsureSettings(); self.db.focusQuestID=nil
  if self.InvalidateQuestPlan then self:InvalidateQuestPlan() end
  self:Refresh()
end
function NS:OpenQuestLogFor(questID, logIndex)
  local opened=false
  if C_QuestLog and C_QuestLog.SetSelectedQuest and questID then pcall(C_QuestLog.SetSelectedQuest, questID) end
  if QuestLog_OpenToQuest and questID then opened=pcall(QuestLog_OpenToQuest, questID) end
  if not opened and ShowQuestLog then opened=pcall(ShowQuestLog) end
  if not opened and ToggleQuestLog then opened=pcall(ToggleQuestLog) end
  return opened
end
function NS:SetMode(mode)
  if not self.modes[mode] then return false end
  self.db.mode=mode; self.db.step=1; self.db.selectedStepID=nil
  if self.InvalidateQuestPlan then self:InvalidateQuestPlan() end
  if self.InvalidateFastRoute then self:InvalidateFastRoute() end
  self:Refresh(); return true
end
function NS:CompleteCurrent(silent)
  local s=self:GetCurrentStep(); if not s then return end
  if s.phase and s.questID then
    if not self:IsPlannedStepComplete(s) then
      if not silent then self:Print("Questschritte werden durch Spielereignisse abgehakt. Zum Auslassen: Überspringen.") end
      return false
    end
    self.db.selectedStepID=nil; self:InvalidateQuestPlan()
  elseif s.phase then
    -- Authored travel/trainer steps are deliberate guide stops, not quests.
    self.db.completed[s.id]=true; self.db.step=self.db.step+1
    self.db.selectedStepID=nil; self:InvalidateQuestPlan()
  else self.db.completed[s.id]=true; self.db.step=self.db.step+1 end
  if self.RecordStepEvent then self:RecordStepEvent("complete",s) end
  self:Refresh(); return true
end
function NS:SkipCurrent()
  local s=self:GetCurrentStep(); if not s then return end
  if s.questID then self.db.skippedQuests[s.questID]=true; self:InvalidateQuestPlan()
  else self.db.step=self.db.step+1 end
  self.db.selectedStepID=nil; self:Refresh()
end
function NS:NormalizeProgress()
  if self.db.questMode then return end
  local steps=self:GetSteps()
  while steps[self.db.step] and self.db.completed[steps[self.db.step].id] do self.db.step=self.db.step+1 end
end
function NS:ResetProgress()
  self.db.step,self.db.selectedStepID,self.db.completed,self.db.skippedQuests=1,nil,{},{}
  if self.InvalidateQuestPlan then self:InvalidateQuestPlan() end
  self:Refresh()
end
function NS:SaveFramePosition(frame,key)
  local x,y=frame:GetCenter(); if not x or not y then return end
  local ratio=frame:GetEffectiveScale()/UIParent:GetEffectiveScale()
  self.db.ui.positions[key]={point="CENTER",relativePoint="BOTTOMLEFT",x=x*ratio/frame:GetScale(),y=y*ratio/frame:GetScale()}
end
function NS:RestoreFramePosition(frame,key,point,parent,x,y)
  local saved=self.db.ui.positions[key]; frame:ClearAllPoints(); frame:SetClampedToScreen(true)
  if saved then frame:SetPoint(saved.point,UIParent,saved.relativePoint,saved.x,saved.y)
  else frame:SetPoint(point or "CENTER",parent or UIParent,point or "CENTER",x or 0,y or 0) end
end
function NS:SetFrameLock(value)
  if value==nil then value=not self.db.ui.lockFrames end
  self.db.ui.lockFrames=value; self:Refresh()
end
function NS:GetStorageKey()
  -- UnitGUID can become a secret value in restricted states.  A character name
  -- is stable for SavedVariables and safe to use as a Lua table key.
  local name, realm
  if UnitFullName then
    local ok, n, r = pcall(UnitFullName, "player")
    if ok then name, realm = n, r end
  end
  if not name and UnitName then
    local ok, n = pcall(UnitName, "player")
    if ok then name = n end
  end
  if not realm and GetRealmName then
    local ok, r = pcall(GetRealmName)
    if ok then realm = r end
  end
  if name == nil or type(name) ~= "string" then name = "Unbekannt" end
  if realm == nil or type(realm) ~= "string" then realm = "Realm" end
  return name .. "-" .. realm
end

function NS:GetClientInfo()
  if not GetBuildInfo then return nil, nil, nil, nil end
  local version, build, date, interface = GetBuildInfo()
  return version, build, date, interface
end

function NS:GetCompatibilityStatus()
  local version, build, date, interface = self:GetClientInfo()
  local okForever = self:IsForeverClient()
  return {
    forever = okForever,
    interface = tonumber(interface) or 0,
    version = version or "unbekannt",
    build = build or "unbekannt",
    status = okForever and "Forever-Interface erkannt" or "Forever-Interface nicht bestätigt",
  }
end

function NS:IsForeverClient()
  local _, _, _, interface = self:GetClientInfo()
  interface = tonumber(interface)
  return interface and interface >= 16000 and interface < 17000 or false
end

function NS:SetWaypoint(point)
  if not point or not point.mapID or not point.x or not point.y or not C_Map or not C_Map.SetUserWaypoint or not UiMapPoint then return false end
  if C_Map.CanSetUserWaypointOnMap then
    local ok, allowed = pcall(C_Map.CanSetUserWaypointOnMap, point.mapID)
    if not ok or allowed == false then return false end
  end
  local okPoint, mapPoint = pcall(UiMapPoint.CreateFromCoordinates, point.mapID, point.x / 100, point.y / 100)
  if not okPoint or not mapPoint then return false end
  local okWaypoint = pcall(C_Map.SetUserWaypoint, mapPoint)
  if not okWaypoint then return false end
  if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then pcall(C_SuperTrack.SetSuperTrackedUserWaypoint, true) end
  return true
end
function NS:Refresh()
  if not self.db or self.refreshing then return end
  self.refreshing=true; self:EnsureSettings(); self:NormalizeProgress()
  if self.RefreshUI then self:RefreshUI() end
  if self.RefreshTracker then self:RefreshTracker() end
  if self.RefreshNavigation then self:RefreshNavigation() end
  if self.RefreshWorldMapOverlay then self:RefreshWorldMapOverlay() end
  if self.RefreshXPProjection then self:RefreshXPProjection() end
  self.refreshing=false
end
function NS:AutoScan(showChat)
  self:RefreshQuestState(); if self.InvalidateQuestPlan then self:InvalidateQuestPlan() end
  self:Refresh(); if showChat then self:PrintRecommendation() end
end
function NS:StartAutoScan()
  if self.autoScanTicker or not C_Timer or not C_Timer.NewTicker then return end
  self.autoScanTicker=C_Timer.NewTicker(300,function() NS:AutoScan(false) end)
end
local function initialize()
  ForeverPathDB=ForeverPathDB or {}; ForeverPathDB.characters=ForeverPathDB.characters or {}
  local key=NS:GetStorageKey()
  ForeverPathDB.characters[key]=ForeverPathDB.characters[key] or {}
  NS.db=ForeverPathDB.characters[key]; NS:EnsureSettings()
  NS.db.runtime=NS.db.runtime or {}
  NS.db.runtime.savedVariablesLoaded=true
  NS.db.runtime.lastInitializedAt=time and time() or nil
  NS.db.runtime.profileKey=key
  NS:InitSession(); NS:InitLearning(); NS:InitLayerRouting(); NS:RefreshQuestState()
  NS:CreateMinimapButton(); NS:CreateTracker(); NS:CreateNavigation(); NS:CreateQuestMarkers(); NS:CreateTargeting(); NS:CreateXPProjection(); NS:StartAutoScan(); NS:Refresh()
  if C_Timer and C_Timer.After then C_Timer.After(1,function() NS:CreateWorldMapOverlay(); if not NS.db.onboarded then NS:ShowOnboarding() end end) end
end
local events={"PLAYER_LOGIN","ADDON_LOADED","PLAYER_ENTERING_WORLD","QUEST_LOG_UPDATE","QUEST_ACCEPTED","QUEST_TURNED_IN","QUEST_REMOVED","QUEST_COMPLETE","QUEST_FINISHED","QUEST_DETAIL","PLAYER_LEVEL_UP","PLAYER_LEVEL_CHANGED","PLAYER_XP_UPDATE","PLAYER_DEAD","PLAYER_ALIVE","PLAYER_UNGHOST","PLAYER_LOGOUT","ZONE_CHANGED_NEW_AREA","ZONE_CHANGED","UNIT_INVENTORY_CHANGED","GET_ITEM_INFO_RECEIVED","ITEM_DATA_LOAD_RESULT","GROUP_ROSTER_UPDATE","PLAYER_ROLES_ASSIGNED","LFG_UPDATE","LFG_PROPOSAL_SHOW","LFG_PROPOSAL_SUCCEEDED","LFG_PROPOSAL_FAILED","TRAINER_SHOW","TRAINER_UPDATE","TRAINER_CLOSED","SKILL_LINES_CHANGED","SPELLS_CHANGED","MERCHANT_SHOW","GOSSIP_SHOW","TAXIMAP_OPENED","HEARTHSTONE_BOUND","PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","PLAYER_TARGET_CHANGED","UPDATE_MOUSEOVER_UNIT","CHAT_MSG_COMBAT_FACTION_CHANGE","UPDATE_FACTION","UNIT_AURA","PLAYER_CONTROL_GAINED"}
local f=CreateFrame("Frame"); NS.eventFrame=f; NS.registeredEvents={}
for _,event in ipairs(events) do NS.registeredEvents[event]=pcall(f.RegisterEvent,f,event) end
f:SetScript("OnEvent",function(_,event,...)
  if event=="PLAYER_LOGIN" then initialize(); return end
  if not NS.db then return end
  if event=="PLAYER_LOGOUT" then
    NS.db.runtime=NS.db.runtime or {}
    NS.db.runtime.lastLogoutAt=time and time() or nil
  end
  if NS.db.debug then
    NS.debugEvents=NS.debugEvents or {}; table.insert(NS.debugEvents,event)
    if #NS.debugEvents>30 then table.remove(NS.debugEvents,1) end
  end
  if NS.TryAutoQuestAction then NS:TryAutoQuestAction(event,...) end
  if NS.RecordTelemetryEvent then NS:RecordTelemetryEvent(event,...) end
  if NS.OnGameEvent then NS:OnGameEvent(event,...) end
  if event=="ADDON_LOADED" or event=="PLAYER_ENTERING_WORLD" then NS:CreateWorldMapOverlay() end
  if not NS.refreshQueued and C_Timer and C_Timer.After then
    NS.refreshQueued=true; C_Timer.After(0.12,function() NS.refreshQueued=false; NS:Refresh() end)
  end
end)
