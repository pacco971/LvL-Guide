# Eingebundene offene Daten

ForeverPath enthält öffentliche Quest- und Routendaten aus zwei Community-Projekten.

## QuestieDB-Forever

`QuestieForeverQuests.lua` und `QuestieForeverMetadata.lua` stammen aus **Forever Quest Pins**.

- Quelle: https://github.com/TylerAkins/forever-quest-markers
- Upstream-Datenquelle: QuestieDB Forever
- Datenstand: siehe `QuestieForeverMetadata.lua`
- Lizenz: GPL-3.0; vollständiger Text: `GPL-3.0.txt`
- Attribution: `ATTRIBUTION.md`

Die Daten werden als öffentliche, offen lizenzierte Datenquelle eingebunden. ForeverPath wird deshalb zusammen mit den GPL-Hinweisen und dem Quelltext verteilt. Es erfolgt kein Verkauf der Daten.

Die Questdatensätze enthalten je nach Quest unter anderem ID, Titel, Level, Fraktion, Questgeber, Abgabeziele, Kettenvorgänger, Karte und Koordinaten. Fehlende Forever-Bestätigungen bleiben als unbekannt/ungeprüft markiert und werden nicht erfunden.

## Evergreen-Routen

`EvergreenRoutes.lua` ist eine normalisierte, automatisch erzeugte Auswahl aus den öffentlichen Routendateien von **Evergreen for WoW Forever**. Enthalten sind Questnamen, bekannte Quest-IDs, Klassen-/Rassenhinweise sowie Wegpunkte für Questgeber, Ziele und Abgabe-NPCs.

- Quelle: https://github.com/Dj2Swagittarius/evergreen-wow-forever
- Lizenz: GPL-2.0-or-later; vollständiger Text: `GPL-2.0.txt`
- Die Datei ist ein unabhängiger Import; Evergreen-Code, UI und Grafiken werden nicht übernommen.
- Routen mit fehlender Quest-ID werden nur als Titel-/Wegpunkt-Hinweis verwendet und nicht als verifizierte Quest-ID ausgegeben.

Da GPL-lizenzierte Daten enthalten sind, müssen diese Hinweise, die jeweiligen Lizenztexte und der zugehörige Quelltext bei einer Weitergabe erhalten bleiben. Das Addon wird nicht als verkauftes Produkt beworben.

## ForeverDB-Questdaten

`ForeverDBQuests.lua` ist ein lokaler Build-Import der Questdaten aus der [ForeverDB API](https://foreverdb.net/developers). Der verwendete Datensatz enthält Questnamen, Level, Fraktion, Zone, Forever-Status, Questgeber-/Abgabeorte und Kettenbeziehungen.

Die vorgeschriebene sichtbare Attribution lautet: **Data from ForeverDB.net (https://foreverdb.net)**. Sie steht im Einstellungen-Tab und bei im Tracker angezeigten ForeverDB-Questdaten. Der API-Schlüssel wurde nur zum Erzeugen des lokalen Imports verwendet und ist nicht Bestandteil des Addons.
