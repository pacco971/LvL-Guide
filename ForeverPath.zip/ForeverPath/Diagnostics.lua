local NS = ForeverPath

function NS:GetDiagnosticsText()
  local build, clientVersion, interface = "unbekannt", "unbekannt", "unbekannt"
  if GetBuildInfo then local version, clientBuild, _, toc = GetBuildInfo(); clientVersion, build, interface = version or clientVersion, clientBuild or build, toc or interface end
  local step = self.GetCurrentStep and self:GetCurrentStep() or nil
  local quest = self.GetQuestState and self:GetQuestState() or { active=0 }
  local gear = self.GetEquipmentSummary and self:GetEquipmentSummary() or { average=0, state="unbekannt" }
  local session = self.GetSessionDetail and self:GetSessionDetail() or "nicht verfügbar"
  local lines = {
    "ForeverPath Fehlerbericht",
    "-------------------------",
    "Addon-Version: " .. tostring(self.version or "unbekannt"),
    "Client-Build: " .. tostring(build or "unbekannt"),
    "Interface: " .. tostring(interface or "unbekannt"),
    "WoW-Version: " .. tostring(clientVersion or "unbekannt"),
    "Forever-Client: " .. tostring(self.IsForeverClient and self:IsForeverClient() or false),
    "Kompatibilität: " .. tostring(self.GetCompatibilityStatus and self:GetCompatibilityStatus().status or "unbekannt"),
    "SavedVariables: " .. tostring(self.db and self.db.runtime and self.db.runtime.savedVariablesLoaded and "geladen" or "nicht bestätigt"),
    "Profil-Key: " .. tostring(self.db and self.db.runtime and self.db.runtime.profileKey or "unbekannt"),
    "Zone: " .. tostring(self.GetPlayerZone and self:GetPlayerZone() or "unbekannt"),
    "Level: " .. tostring(self.GetPlayerLevel and self:GetPlayerLevel() or "unbekannt"),
    "Route: " .. tostring(self.db and self.db.route or "unbekannt") .. " / " .. tostring(self.db and self.db.mode or "unbekannt"),
    "Schritt: " .. tostring(self.db and self.db.step or "unbekannt") .. " · " .. tostring(step and step.title or "unbekannt"),
    "Aktive Quests: " .. tostring(quest.active or 0),
    "Ausrüstung: Ø " .. tostring(math.floor(gear.average or 0)) .. " · " .. tostring(gear.state or "unbekannt"),
    "Gear-Profil: " .. tostring(self.GetGearRole and self:GetGearRole() or "Auto"),
    "Reward-API: " .. tostring(self.GetRewardApiStatus and self:GetRewardApiStatus() or "unbekannt"),
    "Session: " .. session,
    "Daten: " .. tostring(self.GetForeverDBOverview and self:GetForeverDBOverview() or "unbekannt"),
    "Hotfixes: " .. tostring(self.GetForeverDBHotfixSummary and self:GetForeverDBHotfixSummary() or "nicht importiert"),
    "Telemetry: " .. tostring(self.GetTelemetrySummary and self:GetTelemetrySummary() or "nicht verfügbar"),
    "Quest-Ruf: " .. tostring(self.db and self.db.questReputation and "lokal erfasst" or "keine Daten"),
    "Quelle: https://foreverdb.net",
  }
  return table.concat(lines, "\n")
end

function NS:CreateDiagnostics()
  if self.diagnosticsFrame then return end
  local f = CreateFrame("Frame", "ForeverPathDiagnostics", UIParent, "BackdropTemplate")
  f:SetSize(570, 430); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG"); f:EnableMouse(true); f:SetMovable(true)
  f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", edgeSize=24, insets={left=8,right=8,top=8,bottom=8}})
  f:SetBackdropColor(0.035, 0.045, 0.07, 0.98)
  local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); title:SetPoint("TOPLEFT", 20, -20); title:SetTextColor(0.84, 0.66, 0.29); title:SetText("FEHLERBERICHT EXPORT")
  local hint = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); hint:SetPoint("TOPLEFT", 20, -48); hint:SetWidth(520); hint:SetJustifyH("LEFT"); hint:SetTextColor(0.60, 0.66, 0.76); hint:SetText("Markieren klicken, danach Strg+C drücken und den Text im Discord-Ticket einfügen.")
  local edit = CreateFrame("EditBox", nil, f, "InputBoxTemplate"); edit:SetPoint("TOPLEFT", 20, -86); edit:SetSize(530, 275); edit:SetMultiLine(true); edit:SetAutoFocus(false); edit:SetFontObject(GameFontHighlightSmall); edit:SetJustifyH("LEFT"); edit:SetJustifyV("TOP"); edit:SetTextInsets(8, 8, 8, 8); edit:SetScript("OnEscapePressed", function() f:Hide() end); f.edit = edit
  local selectButton = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); selectButton:SetSize(120, 28); selectButton:SetPoint("BOTTOMLEFT", 20, 18); selectButton:SetText("Markieren"); selectButton:SetScript("OnClick", function() edit:SetFocus(); edit:HighlightText() end)
  local close = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); close:SetSize(90, 28); close:SetPoint("BOTTOMRIGHT", -20, 18); close:SetText("Schließen"); close:SetScript("OnClick", function() f:Hide() end)
  f:SetScript("OnMouseDown", function(_, button) if button == "LeftButton" and not (NS.db and NS.db.ui and NS.db.ui.lockFrames) then f:StartMoving() end end)
  f:SetScript("OnMouseUp", function() f:StopMovingOrSizing() end)
  self.diagnosticsFrame = f
end

function NS:ShowDiagnostics()
  self:CreateDiagnostics(); self.diagnosticsFrame.edit:SetText(self:GetDiagnosticsText()); self.diagnosticsFrame:Show()
end
