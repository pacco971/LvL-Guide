local NS = ForeverPath

local function pointTexture(parent, size, color)
  local texture = parent:CreateTexture(nil, "OVERLAY")
  texture:SetTexture("Interface\\Buttons\\WHITE8X8")
  texture:SetVertexColor(unpack(color))
  texture:SetSize(size, size)
  texture:Hide()
  return texture
end

function NS:GetUpcomingWaypoints(limit)
  local cacheKey=tostring(self.db and self.db.step or 1)..":"..tostring(self.questPlanSignature or "")..":"..tostring(limit or 3)
  if self.upcomingWaypointsCache and self.upcomingWaypointsCache.key==cacheKey then return self.upcomingWaypointsCache.value end
  local result, seen = {}, {}
  local steps = self.GetSteps and self:GetSteps() or {}
  local current = self.db and self.db.step or 1
  for index = current, math.min(#steps, current + (limit or 3) + 5) do
    local target = self.GetBestWaypoint and self:GetBestWaypoint(steps[index])
    if target and target.mapID and target.x and target.y then
      local key = string.format("%s:%.2f:%.2f", target.mapID, target.x, target.y)
      if not seen[key] then
        seen[key] = true; result[#result + 1] = { target=target, index=index, step=steps[index] }
        if #result >= (limit or 3) then break end
      end
    end
  end
  self.upcomingWaypointsCache={key=cacheKey,value=result}; return result
end

function NS:CreateWorldMapOverlay()
  if self.worldMapOverlay or not WorldMapFrame then return end
  local parent = WorldMapFrame.ScrollContainer or WorldMapFrame
  local frame = CreateFrame("Frame", "ForeverPathWorldMapOverlay", parent)
  frame:SetAllPoints(parent); frame:SetFrameLevel(parent:GetFrameLevel() + 5)
  frame.line = frame:CreateTexture(nil, "OVERLAY")
  frame.line:SetTexture("Interface\\Buttons\\WHITE8X8"); frame.line:SetVertexColor(0.30, 0.62, 0.88, 0.92); frame.line:SetHeight(4); frame.line:Hide()
  frame.target = pointTexture(frame, 12, {0.84, 0.66, 0.29, 1})
  frame.dots = {}
  for index = 1, 3 do frame.dots[index] = pointTexture(frame, 8, {0.48, 0.83, 0.61, 0.85}) end
  frame:SetScript("OnUpdate", function(_, elapsed)
    frame.elapsed = (frame.elapsed or 0) + elapsed
    if frame.elapsed >= 0.35 then frame.elapsed = 0; NS:RefreshWorldMapOverlay() end
  end)
  self.worldMapOverlay = frame
  if WorldMapFrame.HookScript then WorldMapFrame:HookScript("OnShow", function() NS:RefreshWorldMapOverlay() end) end
  self:RefreshWorldMapOverlay()
end

function NS:RefreshWorldMapOverlay()
  local frame = self.worldMapOverlay
  if not frame or not WorldMapFrame then return end
  if not WorldMapFrame:IsShown() then
    frame.line:Hide(); frame.target:Hide()
    for _, dot in ipairs(frame.dots) do dot:Hide() end
    return
  end
  local mapID = WorldMapFrame.GetMapID and WorldMapFrame:GetMapID()
  if not mapID and C_Map and C_Map.GetBestMapForUnit then
    local okMap, playerMap = pcall(C_Map.GetBestMapForUnit, "player")
    if okMap then mapID = playerMap end
  end
  local width, height = frame:GetWidth(), frame:GetHeight()
  if not mapID or width <= 0 or height <= 0 then frame.line:Hide(); frame.target:Hide(); return end
  local points = self:GetUpcomingWaypoints(3)
  local current = points[1] and points[1].target
  if not current or current.mapID ~= mapID then frame.line:Hide(); frame.target:Hide(); for _, dot in ipairs(frame.dots) do dot:Hide() end; return end

  local function place(texture, point)
    texture:ClearAllPoints(); texture:SetPoint("CENTER", frame, "TOPLEFT", point.x / 100 * width, -point.y / 100 * height); texture:Show()
  end
  place(frame.target, current)
  for index, dot in ipairs(frame.dots) do
    local point = points[index + 1] and points[index + 1].target
    if point and point.mapID == mapID then place(dot, point) else dot:Hide() end
  end

  if C_Map and C_Map.GetPlayerMapPosition then
    local px, py = self.GetSafeMapPosition and self:GetSafeMapPosition(mapID, "player") or nil
    if px and py then
      local okCalculation, calculation = pcall(function()
        local x1, y1 = px * width, py * height; local x2, y2 = current.x / 100 * width, current.y / 100 * height
        local dx, dy, length = x2 - x1, y2 - y1, math.sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
        return {x1, y1, x2, y2, dx, dy, length}
      end)
      if okCalculation and calculation then
        local x1, y1 = calculation[1], calculation[2]
        local x2, y2 = calculation[3], calculation[4]
        local dx, dy, length = calculation[5], calculation[6], calculation[7]
        if length > 2 then frame.line:ClearAllPoints(); frame.line:SetPoint("CENTER", frame, "TOPLEFT", (x1 + x2) / 2, -(y1 + y2) / 2); frame.line:SetSize(length, 4); frame.line:SetRotation(math.atan2(-dy, dx)); frame.line:Show() else frame.line:Hide() end
      else
        frame.line:Hide()
      end
    else
      frame.line:Hide()
    end
  end
end
