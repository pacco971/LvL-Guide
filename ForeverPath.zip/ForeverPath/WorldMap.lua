local NS = ForeverPath

local function pointTexture(parent, size, color, texturePath)
  local texture = parent:CreateTexture(nil, "OVERLAY")
  texture:SetTexture(texturePath or "Interface\\Buttons\\WHITE8X8")
  texture:SetVertexColor(unpack(color))
  texture:SetSize(size, size)
  texture:Hide()
  return texture
end

local function markerText(parent, text, size, color)
  local marker = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  if STANDARD_TEXT_FONT then marker:SetFont(STANDARD_TEXT_FONT, size, "OUTLINE") end
  marker:SetText(text); marker:SetTextColor(unpack(color)); marker:SetJustifyH("CENTER"); marker:SetJustifyV("MIDDLE"); marker:SetSize(size + 8, size + 8); marker:Hide()
  return marker
end

function NS:GetUpcomingWaypoints(limit)
  local cacheKey=tostring(self.db and self.db.step or 1)..":"..tostring(self.questPlanSignature or "")..":"..tostring(limit or 3)
  if self.upcomingWaypointsCache and self.upcomingWaypointsCache.key==cacheKey then return self.upcomingWaypointsCache.value end
  local result, seen = {}, {}
  local steps = self.GetSteps and self:GetSteps() or {}
  local current = self.db and self.db.step or 1
  for index = current, math.min(#steps, current + (limit or 3) + 5) do
    local target = self.GetBestWaypoint and self:GetBestWaypoint(steps[index])
    if target and target.mapID and target.x and target.y then
      local key = string.format("%s:%.2f:%.2f", target.mapID, target.x, target.y)
      if not seen[key] then
        seen[key] = true; result[#result + 1] = { target=target, index=index, step=steps[index] }
        if #result >= (limit or 3) then break end
      end
    end
  end
  self.upcomingWaypointsCache={key=cacheKey,value=result}; return result
end

function NS:CreateWorldMapOverlay()
  if self.worldMapOverlay or not WorldMapFrame then return end
  local parent = WorldMapFrame.ScrollContainer or WorldMapFrame
  local frame = CreateFrame("Frame", "ForeverPathWorldMapOverlay", parent)
  frame:SetAllPoints(parent); frame:SetFrameLevel(parent:GetFrameLevel() + 5)

  -- A subtle glow plus a thin core keeps the route readable at every map scale.
  frame.lineGlow = frame:CreateTexture(nil, "OVERLAY")
  frame.lineGlow:SetTexture("Interface\\Buttons\\WHITE8X8"); frame.lineGlow:SetVertexColor(0.18, 0.45, 0.82, 0.22); frame.lineGlow:SetHeight(8); frame.lineGlow:Hide()
  frame.line = frame:CreateTexture(nil, "OVERLAY")
  frame.line:SetTexture("Interface\\Buttons\\WHITE8X8"); frame.line:SetVertexColor(0.34, 0.72, 1.00, 0.94); frame.line:SetHeight(2); frame.line:Hide()

  -- Only the active target is rendered. Upcoming dots were visually noisy.
  frame.target = pointTexture(frame, 26, {0.84, 0.66, 0.29, 1}, "Interface\\Minimap\\MiniMap-TrackingBorder")
  frame.targetCore = markerText(frame, "•", 12, {1.00, 0.92, 0.52, 1})
  frame.targetLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  frame.targetLabel:SetTextColor(0.98, 0.84, 0.40, 1); frame.targetLabel:SetJustifyH("CENTER"); frame.targetLabel:SetWordWrap(false); frame.targetLabel:SetWidth(210); frame.targetLabel:SetHeight(16); frame.targetLabel:Hide()
  frame.dots = {}

  frame:SetScript("OnUpdate", function(_, elapsed)
    frame.elapsed = (frame.elapsed or 0) + elapsed
    if frame.elapsed >= 0.35 then frame.elapsed = 0; NS:RefreshWorldMapOverlay() end
  end)
  self.worldMapOverlay = frame
  if WorldMapFrame.HookScript then WorldMapFrame:HookScript("OnShow", function() NS:RefreshWorldMapOverlay() end) end
  self:RefreshWorldMapOverlay()
end

function NS:RefreshWorldMapOverlay()
  local frame = self.worldMapOverlay
  if not frame or not WorldMapFrame then return end
  local function hideOverlay()
    frame.line:Hide(); frame.lineGlow:Hide(); frame.target:Hide(); frame.targetCore:Hide(); frame.targetLabel:Hide()
  end
  if not WorldMapFrame:IsShown() then hideOverlay(); return end

  local mapID = WorldMapFrame.GetMapID and WorldMapFrame:GetMapID()
  if not mapID and C_Map and C_Map.GetBestMapForUnit then
    local okMap, playerMap = pcall(C_Map.GetBestMapForUnit, "player")
    if okMap then mapID = playerMap end
  end
  local width, height = frame:GetWidth(), frame:GetHeight()
  if not mapID or width <= 0 or height <= 0 then hideOverlay(); return end
  local points = self:GetUpcomingWaypoints(1)
  local current = points[1] and points[1].target
  if not current or current.mapID ~= mapID then hideOverlay(); return end

  local function place(texture, point)
    texture:ClearAllPoints(); texture:SetPoint("CENTER", frame, "TOPLEFT", point.x / 100 * width, -point.y / 100 * height); texture:Show()
  end
  place(frame.target, current)
  frame.targetCore:ClearAllPoints(); frame.targetCore:SetPoint("CENTER", frame.target); frame.targetCore:Show()
  local targetName = current.hint or current.title or (self.L and self:L("Questziel") or "Questziel")
  frame.targetLabel:ClearAllPoints(); frame.targetLabel:SetPoint("BOTTOM", frame.target, "TOP", 0, 4); frame.targetLabel:SetText(targetName); frame.targetLabel:Show()

  local px, py = self.GetSafeMapPosition and self:GetSafeMapPosition(mapID, "player") or nil
  if not px or not py then frame.line:Hide(); frame.lineGlow:Hide(); return end
  local x1, y1 = px * width, py * height
  local x2, y2 = current.x / 100 * width, current.y / 100 * height
  local dx, dy = x2 - x1, y2 - y1
  local length = math.sqrt(dx * dx + dy * dy)
  if length <= 2 then frame.line:Hide(); frame.lineGlow:Hide(); return end

  local angle = math.atan2(-dy, dx)
  for _, layer in ipairs({frame.lineGlow, frame.line}) do
    layer:ClearAllPoints(); layer:SetPoint("CENTER", frame, "TOPLEFT", (x1 + x2) / 2, -(y1 + y2) / 2); layer:SetSize(length, layer == frame.lineGlow and 8 or 2); layer:SetRotation(angle); layer:Show()
  end
end
