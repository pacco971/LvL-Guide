local NS = ForeverPath

NS.questDB = NS.questDB or {}

-- Import der mitgelieferten, GPL-lizenzierten QuestieDB-Forever-Daten.
-- Die Quelle bleibt im Paket unter ExternalData dokumentiert.
if NS.Quests then
  for questID, source in pairs(NS.Quests) do
    local zoneName
    if source.mapID and C_Map and C_Map.GetMapInfo then local ok, info = pcall(C_Map.GetMapInfo, source.mapID); if ok and info then zoneName = info.name end end
    NS.questDB[questID] = {
      id=questID, title=source.title, mapID=source.mapID, x=source.x, y=source.y, qg=source.qg,
      turnIns=source.turnIns, sourceQuestSingle=source.sourceQuestSingle, faction=source.faction,
      minLevel=source.minLevel, races=source.races, classes=source.classes, repeatable=source.repeatable,
      isInstanceQuest=source.isInstanceQuest, zone=zoneName
    }
  end
end

local function foreverDBPoint(endpoint)
  local location = endpoint and endpoint.location
  if not location or not location.mapID or not location.x or not location.y then return nil end
  return { id=endpoint.id, name=endpoint.name, mapID=location.mapID, x=location.x, y=location.y, source=location.source or endpoint.source }
end

-- ForeverDB-Daten ergänzen die Questie-Marker um Forever-Status, Abgabeorte
-- und Ketten. Der API-Schlüssel selbst ist niemals Bestandteil des Addons.
if NS.ForeverDBQuests then
  for questID, source in pairs(NS.ForeverDBQuests) do
    local record = NS.questDB[questID] or { id=questID }
    record.id = questID
    record.title = source.name or record.title
    record.level = source.level or record.level
    record.requiredLevel = source.requiredLevel or record.requiredLevel
    record.zone = source.zone and source.zone.name or record.zone
    record.mapID = record.mapID or (source.zone and source.zone.mapID)
    record.faction = source.side == "a" and "Alliance" or source.side == "h" and "Horde" or source.side or record.faction
    record.startPoint = foreverDBPoint(source.start)
    record.turnInPoint = foreverDBPoint(source.turnIn)
    record.chainPrevious = source.previous
    record.chainNext = source.next
    record.foreverSource = source.source
    record.foreverDB = true
    NS.questDB[questID] = record
  end
end

-- Evergreen liefert zusätzliche Routenhinweise (Questgeber/Ziel/Abgabe),
-- auch für Schritte, bei denen die Forever-Questdaten keine Koordinaten haben.
NS.externalRoutesByQuest = {}
NS.externalRoutesByTitle = {}
if NS.externalRoutes then
  for _, route in ipairs(NS.externalRoutes) do
    if route.questID and route.questID > 0 then
      NS.externalRoutesByQuest[route.questID] = NS.externalRoutesByQuest[route.questID] or {}
      table.insert(NS.externalRoutesByQuest[route.questID], route)
    end
    if route.title and route.title ~= "" and route.title ~= "Quest Name" then
      NS.externalRoutesByTitle[route.title] = NS.externalRoutesByTitle[route.title] or {}
      table.insert(NS.externalRoutesByTitle[route.title], route)
    end
  end
end

function NS:RegisterQuest(record)
  if not record or not record.id then return end
  self.questDB[record.id] = record
end

local function readObjectives(questID)
  if not C_QuestLog or not C_QuestLog.GetQuestObjectives then return {} end
  local ok, data = pcall(C_QuestLog.GetQuestObjectives, questID)
  return ok and type(data) == "table" and data or {}
end

function NS:RefreshQuestState()
  local live = { active=0, quests={}, byTitle={} }
  if C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo then
    local count = C_QuestLog.GetNumQuestLogEntries() or 0
    for index = 1, count do
      local ok, info = pcall(C_QuestLog.GetInfo, index)
      if ok and info and not info.isHeader and info.questID and info.questID > 0 then
        local quest = self.questDB[info.questID] or {}
        local item = { id=info.questID, title=info.title or quest.title or ("Quest " .. info.questID), level=info.level or quest.level, zone=quest.zone or (self.GetPlayerZone and self:GetPlayerZone()), objectives=readObjectives(info.questID), faction=quest.faction, class=quest.class, index=index }
        live.quests[item.id] = item; live.byTitle[item.title] = item; live.active = live.active + 1
        if self.db and self.db.observedQuests then self.db.observedQuests[item.id] = { title=item.title, level=item.level, zone=item.zone, lastSeen=time() } end
      end
    end
  end
  self.questState = live; return live
end

function NS:GetLiveQuest(questID)
  local state = self.questState or self:RefreshQuestState()
  return state.quests[questID]
end

function NS:IsQuestComplete(questID)
  local live = self:GetLiveQuest(questID)
  if live and live.objectives and #live.objectives > 0 then
    local allDone = true
    for _, objective in ipairs(live.objectives) do
      local required = objective.numRequired or objective.required or 0
      local done = objective.numFulfilled or objective.fulfilled or 0
      if required > 0 and done < required then allDone = false end
    end
    if allDone then return true end
  end
  if not questID or not C_QuestLog or not C_QuestLog.IsQuestFlaggedCompleted then return false end
  local ok, complete = pcall(C_QuestLog.IsQuestFlaggedCompleted, questID)
  return ok and complete == true
end

function NS:IsStepComplete(step)
  if not step then return false end
  if step.questIDs and #step.questIDs > 0 then
    for _, questID in ipairs(step.questIDs) do if not self:IsQuestComplete(questID) then return false end end
    return true
  end
  local objective = self:GetTrackedObjective(step)
  if objective and objective.required and objective.required > 0 and objective.done >= objective.required then return true end
  return false
end

function NS:AutoAdvanceQuestSteps()
  local current = self:GetCurrentStep()
  if current and self:IsStepComplete(current) then self:CompleteCurrent(true); return true end
  return false
end

function NS:GetTrackedObjective(step)
  if not step then return nil end
  local ids = step.questIDs or {}
  if #ids == 0 then
    local state = self.questState or self:RefreshQuestState()
    for questID, quest in pairs(state.quests or {}) do
      if quest.zone and step.zone and string.find(step.zone, quest.zone, 1, true) then ids[#ids + 1] = questID; break end
    end
  end
  for _, questID in ipairs(ids) do
    local quest = self:GetLiveQuest(questID)
    if quest then
      local routeCandidates = self.externalRoutesByQuest[questID] or self.externalRoutesByTitle[quest.title]
      local route = routeCandidates and routeCandidates[1]
      for _, objective in ipairs(quest.objectives or {}) do
        local required = objective.numRequired or objective.required or 0
        local done = objective.numFulfilled or objective.fulfilled or 0
        return { text=objective.text or quest.title, done=done, required=required, quest=quest, route=route }
      end
      return { text=quest.title, done=0, required=0, quest=quest, route=route }
    end
  end
  return nil
end

function NS:GetBestWaypoint(step)
  local objective = step and self:GetTrackedObjective(step)
  local route = objective and objective.route
  if route then
    local point
    if objective.done and objective.required and objective.done >= objective.required then
      point = route.turnin or route.giver
    else
      point = route.objective or route.giver
    end
    if point and point.mapID and point.x and point.y then
      return { mapID=point.mapID, x=point.x, y=point.y, title=route.title, hint=point.name }
    end
  end
  local record = step and step.questIDs and self.questDB[step.questIDs[1]]
  if not record and objective then
    record = objective.quest and self.questDB[objective.quest.id]
  end
  if record then
    local point = objective and objective.done and objective.required and objective.done >= objective.required and record.turnInPoint or record.startPoint
    if point then return point end
  end
  if record and record.mapID and record.x and record.y then return record end
  if step and step.mapID and step.x and step.y then return step end
  return nil
end

function NS:SetBestWaypoint(step)
  return self:SetWaypoint(self:GetBestWaypoint(step))
end

function NS:GetWaypointDistance(step)
  local target = self:GetBestWaypoint(step)
  if not target or not C_Map or not C_Map.GetBestMapForUnit or not C_Map.GetPlayerMapPosition then return nil end
  local mapID = C_Map.GetBestMapForUnit("player"); if not mapID or mapID ~= target.mapID then return nil end
  local ok, pos = pcall(C_Map.GetPlayerMapPosition, mapID, "player"); if not ok or not pos or not pos.GetXY then return nil end
  local px, py = pos:GetXY(); local dx, dy = (target.x or px) - px, (target.y or py) - py
  return math.floor(math.sqrt(dx * dx + dy * dy) * 1000) .. " m (Kartenentfernung)"
end

function NS:GetQuestTrackerText(step)
  local objective = self:GetTrackedObjective(step)
  if objective then
    local text = objective.text
    if objective.required and objective.required > 0 then text = string.format("%s (%d/%d)", text, objective.done, objective.required) end
    local route = objective.route
    if route then
      local point = objective.done and objective.required and objective.done >= objective.required and route.turnin or route.objective or route.giver
      if point and point.name then text = text .. "\n" .. point.name end
    end
    local sourceRecord = objective.quest and self.questDB[objective.quest.id]
    if sourceRecord and sourceRecord.foreverDB then text = text .. "\nQuelle: ForeverDB.net" end
    return text
  end
  return step and step.body or "Keine Questdetails im aktuellen Client gefunden."
end

function NS:GetOpenDataSummary()
  local questCount, routeCount = 0, 0
  for questID in pairs(self.questDB or {}) do
    if type(questID) == "number" then questCount = questCount + 1 end
  end
  for _ in ipairs(self.externalRoutes or {}) do routeCount = routeCount + 1 end
  local sourceCount = self.Metadata and self.Metadata.questCount or questCount
  local foreverCount = self.ForeverDBMetadata and self.ForeverDBMetadata.imported or 0
  return string.format("Offene Daten: %d Questmarker · %d ForeverDB-Quests · %d Routenschritte · QuestieDB-Forever + Evergreen", sourceCount, foreverCount, routeCount)
end
