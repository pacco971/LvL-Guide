local NS = ForeverPath

NS.questDB = NS.questDB or {}

-- Import der mitgelieferten, GPL-lizenzierten QuestieDB-Forever-Daten.
-- Die Quelle bleibt im Paket unter ExternalData dokumentiert.
if NS.Quests then
  for questID, source in pairs(NS.Quests) do
    local zoneName
    if source.mapID and C_Map and C_Map.GetMapInfo then local ok, info = pcall(C_Map.GetMapInfo, source.mapID); if ok and info then zoneName = info.name end end
    NS.questDB[questID] = {
      id=questID, title=source.title, mapID=source.mapID, x=source.x, y=source.y, qg=source.qg,
      turnIns=source.turnIns, sourceQuestSingle=source.sourceQuestSingle, sourceQuestGroup=source.sourceQuestGroup,
      sourceQuestNumRequired=source.sourceQuestNumRequired, faction=source.faction,
      minLevel=source.minLevel, races=source.races, classes=source.classes, repeatable=source.repeatable,
      isInstanceQuest=source.isInstanceQuest, zone=zoneName
    }
  end
end

local function foreverDBPoint(endpoint, kind)
  local location = endpoint and endpoint.location
  if not location or not location.mapID or not location.x or not location.y then return nil end
  return { id=endpoint.id, name=endpoint.name, kind=kind, mapID=location.mapID, x=location.x, y=location.y, source=location.source or endpoint.source }
end

-- ForeverDB-Daten ergänzen die Questie-Marker um Forever-Status, Abgabeorte
-- und Ketten. Der API-Schlüssel selbst ist niemals Bestandteil des Addons.
if NS.ForeverDBQuests then
  for questID, source in pairs(NS.ForeverDBQuests) do
    local record = NS.questDB[questID] or { id=questID }
    record.id = questID
    record.title = source.name or record.title
    record.level = source.level or record.level
    record.requiredLevel = source.requiredLevel or record.requiredLevel
    record.zone = source.zone and source.zone.name or record.zone
    record.mapID = record.mapID or (source.zone and source.zone.mapID)
    record.faction = source.side == "a" and "Alliance" or source.side == "h" and "Horde" or source.side or record.faction
    record.startPoint = foreverDBPoint(source.start, "giver")
    record.turnInPoint = foreverDBPoint(source.turnIn, "turnin")
    record.chainPrevious = source.previous
    record.chainNext = source.next
    record.foreverSource = source.source
    record.foreverDB = true
    NS.questDB[questID] = record
  end
end

-- Die ergänzenden ForeverDB-Endpunkte liefern Dungeons, Klassen, Berufe und
-- Zonen. Sie werden lokal zusammengeführt; der API-Key bleibt außerhalb des
-- Addons und die Quelle bleibt im UI sichtbar.
NS.foreverDBSupplemental = NS.ForeverDBSupplemental or {}
NS.foreverDungeons = NS.foreverDungeons or {}
if NS.foreverDBSupplemental.dungeons and NS.foreverDBSupplemental.dungeons.data then
  for _, dungeon in ipairs(NS.foreverDBSupplemental.dungeons.data) do
    local range = dungeon.levelRange or {}
    local minLevel, maxLevel = range[1] or 1, range[2] or 60
    local exists = false
    for _, known in ipairs(NS.dungeonDB or {}) do
      if string.lower(known.name or "") == string.lower(dungeon.name or "") then exists = true; break end
    end
    if not exists and dungeon.name then
      local record = { id=dungeon.id, name=dungeon.name, min=minLevel, max=maxLevel, kind=dungeon.kind, players=dungeon.players, foreverDB=true, url=dungeon.url }
      NS.dungeonDB[#NS.dungeonDB + 1] = record
      NS.foreverDungeons[#NS.foreverDungeons + 1] = record
    end
  end
end

-- Evergreen liefert zusätzliche Routenhinweise (Questgeber/Ziel/Abgabe),
-- auch für Schritte, bei denen die Forever-Questdaten keine Koordinaten haben.
NS.externalRoutesByQuest = {}
NS.externalRoutesByTitle = {}
if NS.externalRoutes then
  for _, route in ipairs(NS.externalRoutes) do
    if route.questID and route.questID > 0 then
      NS.externalRoutesByQuest[route.questID] = NS.externalRoutesByQuest[route.questID] or {}
      table.insert(NS.externalRoutesByQuest[route.questID], route)
    end
    if route.title and route.title ~= "" and route.title ~= "Quest Name" then
      NS.externalRoutesByTitle[route.title] = NS.externalRoutesByTitle[route.title] or {}
      table.insert(NS.externalRoutesByTitle[route.title], route)
    end
  end
end

local function zoneMatches(a, b)
  if not a or not b then return false end
  a, b = string.lower(a), string.lower(b)
  return a == b or string.find(a, b, 1, true) or string.find(b, a, 1, true)
end

-- Indexiert die importierten Questdatensätze nach Zonen, damit ein allgemeiner
-- Routenabschnitt trotzdem echte Quest-IDs, NPCs und Ketten vorschlagen kann.
function NS:GetQuestRecordsForStep(step, limit)
  if not step then return {} end
  self.questRecordCache = self.questRecordCache or {}
  local key = tostring(step.id or step.title or step.zone) .. ":" .. tostring(self.GetPlayerLevel and self:GetPlayerLevel() or 1)
  if self.questRecordCache[key] then return self.questRecordCache[key] end
  local matches = {}
  for questID, record in pairs(self.questDB or {}) do
    if type(questID) == "number" and record and zoneMatches(record.zone, step.zone) then
      local level = record.level or record.minLevel or step.level or 1
      local lower = (step.level or level) - 8; local upper = (step.level or level) + 8
      if level >= lower and level <= upper and not record.repeatable then
        matches[#matches + 1] = record
      end
    end
  end
  table.sort(matches, function(a, b)
    local af = a.foreverDB and 1 or 0; local bf = b.foreverDB and 1 or 0
    if af ~= bf then return af > bf end
    return (a.level or 0) < (b.level or 0)
  end)
  local result = {}; for i = 1, math.min(limit or 6, #matches) do result[#result + 1] = matches[i] end
  self.questRecordCache[key] = result; return result
end

function NS:GetQuestStepSummary(step)
  local records = self:GetQuestRecordsForStep(step, 8); local active = {}
  local state = self.questState or self:RefreshQuestState()
  for questID, quest in pairs(state.quests or {}) do
    if zoneMatches(quest.zone, step and step.zone) then active[#active + 1] = quest end
  end
  return { known=#records, active=active, records=records }
end

function NS:RegisterQuest(record)
  if not record or not record.id then return end
  self.questDB[record.id] = record
end

local function readObjectives(questID)
  if not C_QuestLog or not C_QuestLog.GetQuestObjectives then return {} end
  local ok, data = pcall(C_QuestLog.GetQuestObjectives, questID)
  return ok and type(data) == "table" and data or {}
end

function NS:RefreshQuestState()
  local live = { active=0, quests={}, byTitle={}, ids={}, titles={} }
  if C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo then
    local count = C_QuestLog.GetNumQuestLogEntries() or 0
    for index = 1, count do
      local ok, info = pcall(C_QuestLog.GetInfo, index)
      if ok and info and not info.isHeader and info.questID and info.questID > 0 then
        local quest = self.questDB[info.questID] or {}
        local item = { id=info.questID, title=info.title or quest.title or ("Quest " .. info.questID), level=info.level or quest.level, zone=quest.zone or (self.GetPlayerZone and self:GetPlayerZone()), objectives=readObjectives(info.questID), faction=quest.faction, class=quest.class, index=index }
        item.isComplete = info.isComplete == true
        live.quests[item.id] = item; live.byTitle[item.title] = item; live.active = live.active + 1; live.ids[item.id]=true; live.titles[#live.titles+1]=item.title
        if self.db and self.db.observedQuests then self.db.observedQuests[item.id] = { title=item.title, level=item.level, zone=item.zone, lastSeen=time() } end
      end
    end
  end
  if live.active==0 and GetNumQuestLogEntries and GetQuestLogTitle then
    for i=1,GetNumQuestLogEntries() do
      local title,level,_,_,isHeader,_,complete,_,id=GetQuestLogTitle(i)
      if id and id>0 and not isHeader then
        local r=self.questDB[id] or {}; local objectives=readObjectives(id)
        if #objectives==0 and GetNumQuestLeaderBoards and GetQuestLogLeaderBoard then
          for j=1,GetNumQuestLeaderBoards(i) do
            local text,kind,finished=GetQuestLogLeaderBoard(j,i)
            objectives[#objectives+1]={text=text,type=kind,finished=finished,numRequired=1,numFulfilled=finished and 1 or 0}
          end
        end
        live.quests[id]={id=id,title=title,level=level,index=i,zone=r.zone,objectives=objectives,isComplete=complete==1}
        live.ids[id]=true; live.titles[#live.titles+1]=title; live.active=live.active+1
      end
    end
  end
  self.questState = live; return live
end

function NS:GetLiveQuest(questID)
  local state = self.questState or self:RefreshQuestState()
  return state.quests[questID]
end

function NS:IsQuestComplete(questID)
  local live = self:GetLiveQuest(questID)
  if live and live.objectives and #live.objectives > 0 then
    local allDone = true
    for _, objective in ipairs(live.objectives) do
      local required = objective.numRequired or objective.required or 0
      local done = objective.numFulfilled or objective.fulfilled or 0
      if required > 0 and done < required then allDone = false end
    end
    if allDone then return true end
  end
  if not questID or not C_QuestLog or not C_QuestLog.IsQuestFlaggedCompleted then return false end
  local ok, complete = pcall(C_QuestLog.IsQuestFlaggedCompleted, questID)
  return ok and complete == true
end

function NS:IsStepComplete(step)
  if not step then return false end
  if step.questIDs and #step.questIDs > 0 then
    for _, questID in ipairs(step.questIDs) do if not self:IsQuestComplete(questID) then return false end end
    return true
  end
  local objective = self:GetTrackedObjective(step)
  if objective and objective.required and objective.required > 0 and objective.done >= objective.required then return true end
  return false
end

function NS:AutoAdvanceQuestSteps()
  local moved, guard = false, 0
  while self:GetCurrentStep() and guard < 12 do
    local current = self:GetCurrentStep(); guard = guard + 1
    if not self:IsStepComplete(current) then break end
    self:CompleteCurrent(true); moved = true
  end
  return moved
end

function NS:GetTrackedObjective(step)
  if not step then return nil end
  local ids = step.questIDs or {}
  if #ids == 0 then
    local state = self.questState or self:RefreshQuestState()
    for questID, quest in pairs(state.quests or {}) do
      if quest.zone and step.zone and string.find(step.zone, quest.zone, 1, true) then ids[#ids + 1] = questID; break end
    end
  end
  for _, questID in ipairs(ids) do
    local quest = self:GetLiveQuest(questID)
    if quest then
      local routeCandidates = self.externalRoutesByQuest[questID] or self.externalRoutesByTitle[quest.title]
      local route = routeCandidates and routeCandidates[1]
      for _, objective in ipairs(quest.objectives or {}) do
        local required = objective.numRequired or objective.required or 0
        local done = objective.numFulfilled or objective.fulfilled or 0
        return { text=objective.text or quest.title, done=done, required=required, quest=quest, route=route }
      end
      return { text=quest.title, done=0, required=0, quest=quest, route=route }
    end
  end
  return nil
end

function NS:GetBestWaypoint(step)
  local objective = step and self:GetTrackedObjective(step)
  local route = objective and objective.route
  if route then
    local point
    if objective.done and objective.required and objective.done >= objective.required then
      point = route.turnin or route.giver
    else
      point = route.objective or route.giver
    end
    if point and point.mapID and point.x and point.y then
      local kind = point == route.turnin and "turnin" or point == route.objective and "objective" or "giver"
      return { mapID=point.mapID, x=point.x, y=point.y, title=route.title, hint=point.name, kind=kind }
    end
  end
  local record = step and step.questIDs and self.questDB[step.questIDs[1]]
  if not record and objective then
    record = objective.quest and self.questDB[objective.quest.id]
  end
  if record then
    local point = objective and objective.done and objective.required and objective.done >= objective.required and record.turnInPoint or record.startPoint
    if point then return point end
  end
  if record and record.mapID and record.x and record.y then return record end
  local candidates = self:GetQuestRecordsForStep(step, 1)
  if candidates[1] then
    local candidate = candidates[1]
    if candidate.startPoint then return candidate.startPoint end
    if candidate.turnInPoint then return candidate.turnInPoint end
    if candidate.mapID and candidate.x and candidate.y then return candidate end
  end
  if step and step.mapID and step.x and step.y then return step end
  if step and self.GetExternalRouteWaypoint then
    local fallback = self:GetExternalRouteWaypoint(step)
    if fallback then return fallback end
  end
  return nil
end

function NS:GetExternalRouteWaypoint(step)
  if not step or not step.zone or not self.externalRoutes then return nil end
  local wanted = string.lower(step.zone)
  local classToken = self.GetClassToken and self:GetClassToken() or "UNKNOWN"
  self.externalWaypointCache = self.externalWaypointCache or {}
  local cacheKey = tostring(step.id or step.title or step.zone) .. ":" .. classToken
  if self.externalWaypointCache[cacheKey] ~= nil then return self.externalWaypointCache[cacheKey] or nil end
  local best, bestRank = nil, -1
  for _, route in ipairs(self.externalRoutes) do
    local rank = route.class and route.class == classToken and 3 or (not route.class and 2 or 0)
    if rank > 0 then
      local points = {route.giver, route.objective, route.turnin}
      for _, point in ipairs(points) do
        if point and point.mapID and point.x and point.y and C_Map and C_Map.GetMapInfo then
          local ok, info = pcall(C_Map.GetMapInfo, point.mapID)
          local zoneName = ok and info and info.name and string.lower(info.name) or ""
          if zoneName ~= "" and (string.find(wanted, zoneName, 1, true) or string.find(zoneName, wanted, 1, true)) then
            if rank > bestRank then
              bestRank = rank
              best = { mapID=point.mapID, x=point.x, y=point.y, title=route.title, hint=point.name, kind=route.objective == point and "objective" or route.turnin == point and "turnin" or "giver" }
            end
            break
          end
        end
      end
    end
  end
  self.externalWaypointCache[cacheKey] = best or false
  return best
end

function NS:SetBestWaypoint(step)
  return self:SetWaypoint(self:GetBestWaypoint(step))
end

function NS:GetWaypointDistance(step)
  local target = self:GetBestWaypoint(step)
  if not target or not C_Map or not C_Map.GetBestMapForUnit or not C_Map.GetPlayerMapPosition then return nil end
  local mapID = C_Map.GetBestMapForUnit("player"); if not mapID or mapID ~= target.mapID then return nil end
  local ok, pos = pcall(C_Map.GetPlayerMapPosition, mapID, "player"); if not ok or not pos or not pos.GetXY then return nil end
  local px, py = pos:GetXY(); local dx, dy = (target.x or px * 100) / 100 - px, (target.y or py * 100) / 100 - py
  return math.floor(math.sqrt(dx * dx + dy * dy) * 1000) .. " m (Kartenentfernung)"
end

function NS:GetQuestTrackerText(step)
  local objective = self:GetTrackedObjective(step)
  if objective then
    local text = objective.text
    if objective.required and objective.required > 0 then text = string.format("%s (%d/%d)", text, objective.done, objective.required) end
    local route = objective.route
    if route then
      local point = objective.done and objective.required and objective.done >= objective.required and route.turnin or route.objective or route.giver
      if point and point.name then text = text .. "\n" .. point.name end
    end
    local sourceRecord = objective.quest and self.questDB[objective.quest.id]
    if sourceRecord and sourceRecord.foreverDB then text = text .. "\nQuelle: ForeverDB.net" end
    return text
  end
  local summary = self:GetQuestStepSummary(step)
  if summary.records and summary.records[1] then
    local record = summary.records[1]
    local text = string.format("Questdaten: %s (ID %d)", record.title or "Unbekannte Quest", record.id or 0)
    if record.startPoint and record.startPoint.name then text = text .. "\nNPC: " .. record.startPoint.name end
    if record.chainNext and #record.chainNext > 0 then text = text .. "\nFolgequest verfügbar" end
    if record.foreverDB then text = text .. "\nQuelle: ForeverDB.net" end
    return text
  end
  return step and step.body or "Keine Questdetails im aktuellen Client gefunden."
end

function NS:GetOpenDataSummary()
  local questCount, routeCount = 0, 0
  for questID in pairs(self.questDB or {}) do
    if type(questID) == "number" then questCount = questCount + 1 end
  end
  for _ in ipairs(self.externalRoutes or {}) do routeCount = routeCount + 1 end
  local sourceCount = self.Metadata and self.Metadata.questCount or questCount
  local foreverCount = self.ForeverDBMetadata and self.ForeverDBMetadata.imported or 0
  local extra = self.foreverDBSupplemental or {}
  local function dataCount(key)
    return extra[key] and extra[key].meta and extra[key].meta.total or 0
  end
  return string.format("Offene Daten: %d Questmarker · %d ForeverDB-Quests · %d Routenschritte · %d Dungeons · %d Zonen · QuestieDB-Forever + Evergreen", sourceCount, foreverCount, routeCount, dataCount("dungeons"), dataCount("zones"))
end

function NS:GetForeverDBOverview()
  local extra = self.foreverDBSupplemental or {}
  local function dataCount(key)
    return extra[key] and extra[key].meta and extra[key].meta.total or 0
  end
  local build = (extra.dungeons and extra.dungeons.meta and extra.dungeons.meta.build) or (extra.changesSeen and extra.changesSeen.meta and extra.changesSeen.meta.build) or "lokal"
  return string.format("ForeverDB-Build %s · %d Dungeons · %d Klassen · %d Berufe · %d Zonen · %d bestätigte Änderungen", build, dataCount("dungeons"), dataCount("classes"), dataCount("professions"), dataCount("zones"), dataCount("changesSeen"))
end

function NS:GetDataStatus()
  local extra = self.foreverDBSupplemental or {}; local questMeta = self.ForeverDBMetadata or {}
  local build = questMeta.build or (extra.dungeons and extra.dungeons.meta and extra.dungeons.meta.build) or "lokaler Build"
  local quests = questMeta.imported or questMeta.total or 0
  local changes = extra.changesSeen and extra.changesSeen.meta and extra.changesSeen.meta.total or 0
  return string.format("Datenstatus: ForeverDB %s · %d Quests · %d bestätigte Änderungen · statischer Import · Live-Abfrage im WoW-Client deaktiviert", build, quests, changes)
end

function NS:PrintDataStatus()
  self:Print(self.GetDataStatus and self:GetDataStatus() or "Datenstatus nicht verfügbar.")
  self:Print("Für neue Daten außerhalb des Spiels den Importer aus DATA-UPDATE.md verwenden.")
end
