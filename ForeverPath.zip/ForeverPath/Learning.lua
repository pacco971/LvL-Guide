local NS = ForeverPath

function NS:InitLearning()
  self.db.metrics = self.db.metrics or { deaths=0, xpEvents=0, steps={} }
  self.db.observedQuests = self.db.observedQuests or {}
  if self.InitSession then self:InitSession() end
  self.learningStarted = self.learningStarted or GetTime()
end

function NS:RecordStepEvent(kind, step)
  if not self.db or not step then return end
  self:InitLearning(); local data = self.db.metrics.steps[step.id] or { visits=0, completions=0, seconds=0 }
  if kind == "start" then data.visits = data.visits + 1; data.started = GetTime()
  elseif kind == "complete" then data.completions = data.completions + 1; if data.started then data.seconds = data.seconds + (GetTime() - data.started); data.started = nil end end
  self.db.metrics.steps[step.id] = data
end

function NS:OnGameEvent(event, ...)
  if not self.db then return end
  self:InitLearning()
  if event == "PLAYER_DEAD" then self.db.metrics.deaths = self.db.metrics.deaths + 1; if self.RecordSessionDeath then self:RecordSessionDeath() end
  elseif (event == "UNIT_XP" and (...) == "player") or event == "PLAYER_XP_UPDATE" or event == "PLAYER_LEVEL_CHANGED" then self.db.metrics.xpEvents = self.db.metrics.xpEvents + 1; if self.RecordSessionXP then self:RecordSessionXP() end
  elseif event == "ZONE_CHANGED_NEW_AREA" then if self.UpdateSessionContext then self:UpdateSessionContext() end
  elseif event == "QUEST_ACCEPTED" or event == "QUEST_TURNED_IN" or event == "QUEST_REMOVED" or event == "QUEST_LOG_UPDATE" then
    self:RefreshQuestState(); self:AutoAdvanceQuestSteps()
  elseif event == "PLAYER_ENTERING_WORLD" then self:RefreshQuestState(); self:RecordStepEvent("start", self:GetCurrentStep()) end
end

function NS:GetLearningSummary()
  self:InitLearning(); local count = 0; for _ in pairs(self.db.observedQuests or {}) do count = count + 1 end
  return string.format("Tode: %d · XP-Ereignisse: %d · beobachtete Quests: %d · %s", self.db.metrics.deaths or 0, self.db.metrics.xpEvents or 0, count, self.GetSessionText and self:GetSessionText() or "Sessiondaten nicht verfügbar")
end
