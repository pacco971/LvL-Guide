local NS=ForeverPath
function NS:InitLearning()
  self.db.metrics=self.db.metrics or {deaths=0,xpEvents=0,steps={}}
  self.db.observedQuests=self.db.observedQuests or {}; self:InitSession()
end
function NS:RecordStepEvent(kind,s)
  if not s then return end
  local row=self.db.metrics.steps[s.id] or {seconds=0,visits=0}; self.db.metrics.steps[s.id]=row
  if kind=="start" then row.started=GetTime(); row.visits=row.visits+1
  elseif row.started then row.seconds=row.seconds+GetTime()-row.started; row.started=nil end
end
function NS:OnGameEvent(event,...)
  self:InitLearning(); local a,b=...
  if event=="QUEST_COMPLETE" then self.rewardWindow=true; self:InvalidateGearCache()
  elseif event=="QUEST_FINISHED" then self.rewardWindow=false; self:InvalidateGearCache()
  elseif event=="GET_ITEM_INFO_RECEIVED" or event=="ITEM_DATA_LOAD_RESULT" or event=="UNIT_INVENTORY_CHANGED" then self:InvalidateGearCache()
  elseif event=="PLAYER_XP_UPDATE" or event=="PLAYER_LEVEL_UP" or event=="PLAYER_LEVEL_CHANGED" then self:RecordSessionXP(); self:InvalidateQuestPlan()
  elseif event=="PLAYER_DEAD" then self:RecordSessionDeath()
  elseif event=="ZONE_CHANGED_NEW_AREA" or event=="ZONE_CHANGED" or event=="PLAYER_ENTERING_WORLD" then self:UpdateSessionContext(); self:InvalidateQuestPlan(); self:UpdateGroup(); if self.RecordLayerPressure then self:RecordLayerPressure("seen") end
  elseif event=="GROUP_ROSTER_UPDATE" or event=="PLAYER_ROLES_ASSIGNED" then self:UpdateGroup(); self:InvalidateGearCache()
  elseif event=="LFG_PROPOSAL_SUCCEEDED" then self:EndGroupWait()
  elseif event=="TRAINER_SHOW" or event=="TRAINER_UPDATE" then self:ObserveStop("trainer")
  elseif event=="MERCHANT_SHOW" then self:ObserveStop("merchant")
  elseif event=="TAXIMAP_OPENED" then self:ObserveStop("flight")
  elseif event=="HEARTHSTONE_BOUND" then self:ObserveStop("inn"); self.db.bindLocation=GetBindLocation and GetBindLocation()
  elseif event=="SPELLS_CHANGED" then self.db.spellsChangedAt=time()
  elseif event=="QUEST_TURNED_IN" then self.session.lastQuestXPAt=GetTime()
  elseif event=="PLAYER_TARGET_CHANGED" or event=="UPDATE_MOUSEOVER_UNIT" then
    if self.RecordLayerPressure and not UnitExists("target") then self:RecordLayerPressure("empty") end
  elseif event=="UNIT_AURA" then self:RefreshXPProjection()
  end
  if event=="QUEST_ACCEPTED" or event=="QUEST_REMOVED" or event=="QUEST_TURNED_IN" or event=="QUEST_LOG_UPDATE" then
    if event=="QUEST_TURNED_IN" then
      self.session.lastQuestXPAt=GetTime()
      self.db.turnedIn[a]=true
      local q=self.db.questMetrics[a] or {}; q.seconds=q.acceptedAt and math.max(0,time()-q.acceptedAt) or nil; q.xp=b; q.turnedInAt=time(); self.db.questMetrics[a]=q
    elseif event=="QUEST_ACCEPTED" then
      local id=b or a; self.db.questMetrics[id]={acceptedAt=time()}
    end
    self:RefreshQuestState(); self:InvalidateQuestPlan()
  end
  if event=="PLAYER_LOGOUT" then self:UpdateSessionContext() end
end
function NS:GetLearningSummary() return self:GetLearningDetails() end
